<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$user_id = $_SESSION["user_id"];

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $current_password = $_POST["current_password"] ?? "";
    $new_password = $_POST["new_password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";

    if ($current_password === "" || $new_password === "" || $confirm_password === "") {

        $error = "Please fill in all fields.";

    } elseif ($new_password !== $confirm_password) {

        $error = "New passwords do not match.";

    } elseif (strlen($new_password) < 6) {

        $error = "New password must be at least 6 characters.";

    } else {

        $stmt = $conn->prepare(
            "SELECT password
             FROM users
             WHERE id = ?"
        );

        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if (!$user) {

            $error = "User account not found.";

        } elseif (!password_verify($current_password, $user["password"])) {

            $error = "Current password is incorrect.";

        } else {

            $new_hash = password_hash(
                $new_password,
                PASSWORD_DEFAULT
            );

            $update = $conn->prepare(
                "UPDATE users
                 SET password = ?
                 WHERE id = ?"
            );

            $update->bind_param(
                "si",
                $new_hash,
                $user_id
            );

            if ($update->execute()) {

                $message = "Password changed successfully!";

            } else {

                $error = "Unable to change password.";
            }

            $update->close();
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Change Password - TransCalltation</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 20px;

    font-family: Arial, Helvetica, sans-serif;

    color: white;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #071a3d,
            #123b72,
            #0b6fa4
        );
}

.container {
    max-width: 600px;
    margin: auto;
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

.card {
    padding: 22px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);
}

label {
    display: block;

    margin-top: 15px;
    margin-bottom: 6px;

    font-weight: bold;
}

input {
    width: 100%;

    padding: 13px;

    border: none;
    border-radius: 12px;

    font-size: 15px;
}

input:focus {
    outline: 2px solid rgba(255,255,255,.5);
}

button {
    width: 100%;

    margin-top: 20px;

    padding: 14px;

    border: none;
    border-radius: 12px;

    color: white;

    font-size: 15px;
    font-weight: bold;

    cursor: pointer;

    background:
        linear-gradient(
            135deg,
            #1769d1,
            #6a35c9
        );
}

.message,
.error {
    padding: 12px;

    margin-bottom: 15px;

    text-align: center;

    border-radius: 10px;
}

.message {
    background: rgba(0,180,100,.3);
}

.error {
    background: rgba(220,50,50,.3);
}

.back {
    display: block;

    margin-top: 20px;

    text-align: center;

    color: white;

    text-decoration: none;
}
.password-box {
    position: relative;
    width: 100%;
}

.password-box input {
    width: 100%;
    padding-right: 50px;
}

.eye-button {
    position: absolute;

    right: 8px;
    top: 50%;
    transform: translateY(-50%);

    width: 38px;
    height: 38px;

    margin: 0;
    padding: 0;

    border: none;
    border-radius: 10px;

    background: transparent;

    color: white;

    font-size: 18px;

    cursor: pointer;
}
</style>

</head>

<body>

<div class="container">

<h1>🔐 CHANGE PASSWORD</h1>

<div class="card">

<?php if ($message !== ""): ?>

<div class="message">
    ✅ <?php echo htmlspecialchars($message); ?>
</div>

<?php endif; ?>


<?php if ($error !== ""): ?>

<div class="error">
    ❌ <?php echo htmlspecialchars($error); ?>
</div>

<?php endif; ?>


<form method="POST">

<label>Current Password</label>

<div class="password-box">

    <input
        type="password"
        name="current_password"
        id="current_password"
        required
    >

    <button
        type="button"
        class="eye-button"
        onclick="togglePassword('current_password', this)"
    >
        👁️
    </button>

</div>


<label>New Password</label>

<div class="password-box">

    <input
        type="password"
        name="new_password"
        id="new_password"
        required
    >

    <button
        type="button"
        class="eye-button"
        onclick="togglePassword('new_password', this)"
    >
        👁️
    </button>

</div>


<label>Confirm New Password</label>

<div class="password-box">

    <input
        type="password"
        name="confirm_password"
        id="confirm_password"
        required
    >

    <button
        type="button"
        class="eye-button"
        onclick="togglePassword('confirm_password', this)"
    >
        👁️
    </button>

</div>


<button type="submit">
    🔐 CHANGE PASSWORD
</button>

</form>

</div>


<a href="settings.php" class="back">
    ← Back to Settings
</a>

</div>
<script>
function togglePassword(id, button) {

    const input = document.getElementById(id);

    if (input.type === "password") {
        input.type = "text";
        button.textContent = "🗝️";
    } else {
        input.type = "password";
        button.textContent = "👁️";
    }
}
</script>
</body>

</html>

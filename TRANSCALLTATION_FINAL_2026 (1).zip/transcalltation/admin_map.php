<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>TransCalltation 2.0 - Admin Map</title>

<style>

* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100%;
    font-family: Arial, Helvetica, sans-serif;
}

body {
    min-height: 100vh;
    overflow: auto;

    background:
        linear-gradient(
            rgba(3, 8, 25, .72),
            rgba(3, 8, 25, .90)
        ),
        url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
        center center / cover no-repeat fixed;

    color: white;
}

.map-page {
    width: 100vw;
    height: 100vh;

    display: flex;
    flex-direction: column;

    padding: 12px;
}

.map-header {
    flex-shrink: 0;

    text-align: center;

    padding: 8px 10px 12px;
}

.map-header h1 {
    margin: 0;

    font-size: clamp(24px, 4vw, 36px);
    font-weight: 900;

    text-shadow:
        0 0 10px rgba(0,234,255,.9),
        0 0 25px rgba(123,44,255,.8);
}

.map-header p {
    margin: 5px 0 0;

    color: rgba(255,255,255,.80);
    font-size: 14px;
}

/* =====================================================
   FULL SCREEN MAP AREA
===================================================== */

.map-panel {
    position: relative;

    width: 100%;
    height: calc(100vh - 235px);
    min-height: 420px;

    border-radius: 24px;

    overflow: hidden;

    border: 1px solid rgba(255,255,255,.35);

    background:
        linear-gradient(
            145deg,
            rgba(0,234,255,.14),
            rgba(123,44,255,.18)
        );

    box-shadow:
        0 10px 35px rgba(0,0,0,.45),
        0 0 30px rgba(0,234,255,.20),
        0 0 60px rgba(123,44,255,.18);
}

.map-placeholder {
    width: 100%;
    height: 100%;

    display: flex;
    flex-direction: column;

    align-items: center;
    justify-content: center;

    text-align: center;

    padding: 25px;

    background:
        radial-gradient(
            circle at center,
            rgba(0,234,255,.13),
            rgba(123,44,255,.10) 45%,
            rgba(0,0,0,.40) 100%
        );
}

.map-icon {
    font-size: clamp(55px, 10vw, 90px);

    margin-bottom: 15px;

    filter:
        drop-shadow(0 0 12px rgba(0,234,255,.85))
        drop-shadow(0 0 25px rgba(123,44,255,.75));
}

.map-placeholder h2 {
    margin: 0 0 8px;

    font-size: clamp(22px, 4vw, 32px);
    font-weight: 900;
}

.map-placeholder p {
    max-width: 650px;

    margin: 0;

    line-height: 1.6;

    color: rgba(255,255,255,.78);
}

.location-status {
    display: inline-flex;

    align-items: center;
    gap: 8px;

    margin-top: 16px;

    padding: 10px 18px;

    border-radius: 30px;

    background: rgba(0,0,0,.30);

    border: 1px solid rgba(255,255,255,.25);

    font-weight: 800;
}

.status-dot {
    width: 10px;
    height: 10px;

    border-radius: 50%;

    background: #00eaff;

    box-shadow:
        0 0 8px #00eaff,
        0 0 18px #00eaff;
}

/* =====================================================
   BOTTOM CONTROLS
===================================================== */

.map-bottom {
    flex-shrink: 0;

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 10px;

    margin-top: 10px;
}

.map-control {
    padding: 10px;

    border-radius: 16px;

    text-align: center;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.14),
            rgba(255,255,255,.06)
        );

    border: 1px solid rgba(255,255,255,.22);

    box-shadow:
        0 5px 15px rgba(0,0,0,.25);
}

.map-control strong {
    display: block;

    font-size: 14px;

    margin-bottom: 3px;
}

.map-control span {
    font-size: 11px;

    color: rgba(255,255,255,.68);
}

/* =====================================================
   BACK BUTTON
===================================================== */

.back-dashboard-btn {
    position: relative;

    display: flex;

    align-items: center;
    justify-content: center;

    width: 100%;

    min-height: 48px;

    margin-top: 10px;

    padding: 12px 18px;

    border-radius: 17px;

    text-decoration: none;

    color: white;

    font-size: 15px;
    font-weight: 900;

    letter-spacing: .5px;

    background:
        linear-gradient(
            145deg,
            rgba(123,44,255,.98),
            rgba(0,140,255,.94) 48%,
            rgba(0,234,255,.96)
        );

    border: 1px solid rgba(255,255,255,.45);

    box-shadow:
        0 7px 18px rgba(0,0,0,.30),
        0 0 20px rgba(123,44,255,.45),
        0 0 40px rgba(0,234,255,.30);

    overflow: hidden;

    transition:
        transform .25s ease,
        box-shadow .25s ease;
}

.back-dashboard-btn::before {
    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 48%;

    background:
        linear-gradient(
            180deg,
            rgba(255,255,255,.48),
            rgba(255,255,255,.08),
            transparent
        );

    pointer-events: none;
}

.back-dashboard-btn:hover {
    transform: translateY(-3px);

    box-shadow:
        0 10px 24px rgba(0,0,0,.35),
        0 0 28px rgba(123,44,255,.70),
        0 0 55px rgba(0,234,255,.55);
}

.back-dashboard-btn:active {
    transform: translateY(1px);
}

/* =====================================================
   MOBILE
===================================================== */

@media (max-width: 650px) {

    body {
        overflow: auto;
    }

    .map-page {
        min-height: 100vh;
        height: auto;
        padding: 8px;
    }

    .map-panel {
        height: 65vh;
        min-height: 420px;
        flex: none;
    }

    .map-bottom {
        grid-template-columns: 1fr;
    }

    .map-control {
        padding: 9px;
    }
}


        #adminMap {
            width: 100%;
            height: 100%;
            min-height: 100%;
            z-index: 1;
        }

        .leaflet-control-zoom {
            box-shadow: 0 0 15px rgba(0,234,255,.35) !important;
        }

        .leaflet-popup-content-wrapper,
        .leaflet-popup-tip {
            background: rgba(3,8,25,.94);
            color: white;
        }

        .leaflet-popup-content {
            font-weight: 700;
        }


        .map-control {
            width: 100%;
            border: 1px solid rgba(255,255,255,.25);
            cursor: pointer;
            color: #ffffff;
            font-family: Arial, Helvetica, sans-serif;
            transition:
                transform .2s ease,
                box-shadow .2s ease,
                background .2s ease;
        }

        .map-control:hover {
            transform: translateY(-3px);
            box-shadow:
                0 0 18px rgba(0,234,255,.35),
                0 8px 18px rgba(0,0,0,.30);
        }

        .map-control.active {
            background:
                linear-gradient(
                    145deg,
                    rgba(0,234,255,.30),
                    rgba(123,44,255,.35)
                );

            border-color: rgba(0,234,255,.70);

            box-shadow:
                0 0 18px rgba(0,234,255,.35),
                0 0 30px rgba(123,44,255,.25);
        }

        .map-control:active {
            transform: scale(.98);
        }

</style>

<link
    rel="stylesheet"
    href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
/>

<script
    src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js">
</script>

</head>

<body>

<div class="map-page">

    <div class="map-header">
        <h1>🗺️ ADMIN MAP</h1>
        <p>TransCalltation 2.0 • Location Monitoring</p>
    </div>

    <div class="map-panel">
        <div id="adminMap"></div>
    </div>

    <div class="map-bottom">

        <button type="button" class="map-control active" id="driversControl">
            <strong>🛵 DRIVERS</strong>
            <span>Show authorized drivers</span>
        </button>

        <button type="button" class="map-control" id="usersControl">
            <strong>👨‍🎓 USERS</strong>
            <span>Show shared user locations</span>
        </button>

        <button type="button" class="map-control" id="privacyControl">
            <strong>🔒 PRIVACY</strong>
            <span>Location permission</span>
        </button>

    </div>

    <a href="admin_dashboard.php" class="back-dashboard-btn">
        ⬅️ BACK TO ADMIN DASHBOARD
    </a>

</div>


<script>
document.addEventListener("DOMContentLoaded", function () {

    const map = L.map("adminMap", {
        zoomControl: true
    }).setView([12.8797, 121.7740], 6);

    L.tileLayer(
        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        {
            maxZoom: 19,
            attribution:
                '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }
    ).addTo(map);

});
</script>


<script>
document.addEventListener("DOMContentLoaded", function () {

    const controls = document.querySelectorAll(".map-control");

    controls.forEach(function (control) {

        control.addEventListener("click", function () {

            controls.forEach(function (item) {
                item.classList.remove("active");
            });

            control.classList.add("active");

        });

    });

});
</script>

</body>
</html>

<?php
session_start();
include "config.php";

/* Protect page */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = (int) $_SESSION["user_id"];

/* Get logged-in user */
$stmt = $conn->prepare(
    "SELECT id, full_name, email, role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$stmt->close();

/* Only admin */
if (!$admin || strtolower($admin["role"]) !== "admin") {
    header("Location: dashboard.php");
    exit();
}

/* Get all drivers */
$drivers = [];

$result = $conn->query(
    "SELECT
        id,
        full_name,
        email,
        phone,
        vehicle,
        plate,
        status,
        driver_verified,
        driver_license_photo,
        government_id_photo,
        profile_photo,
        vehicle_photo,
        created_at
     FROM users
     WHERE role = 'driver'
     ORDER BY id DESC"
);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Total Drivers | TransCalltation</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    min-height: 100vh;
    padding: 15px;
    font-family: Arial, sans-serif;
    color: white;

    background:
        radial-gradient(
            circle at 10% 10%,
            #00e5ff,
            transparent 30%
        ),
        radial-gradient(
            circle at 90% 90%,
            #e100ff,
            transparent 35%
        ),
        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );
}

.container {
    width: 100%;
    max-width: 1000px;
    margin: auto;
}

.header {
    padding: 20px;
    margin-bottom: 18px;
    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.9),
            rgba(142,45,226,.9)
        );

    box-shadow:
        0 15px 35px rgba(0,0,0,.3);
}

.header h1 {
    font-size: 22px;
}

.header p {
    margin-top: 5px;
    font-size: 12px;
    opacity: .8;
}

.back {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 14px;

    color: white;
    text-decoration: none;
    font-size: 12px;
    font-weight: bold;

    border-radius: 10px;
    background: rgba(0,0,0,.25);
}

.card {
    padding: 18px;
    margin-bottom: 12px;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.07)
        );

    border:
        1px solid rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px rgba(0,0,0,.25);
}

.name {
    font-size: 17px;
    font-weight: 900;
    margin-bottom: 8px;
}

.info {
    font-size: 12px;
    line-height: 1.9;
}

.verified {
    display: inline-block;
    margin-top: 8px;
    padding: 6px 10px;

    border-radius: 20px;

    background: rgba(0,255,120,.18);
    color: #7cffb2;

    font-size: 10px;
    font-weight: bold;
}

.not-verified {
    display: inline-block;
    margin-top: 8px;
    padding: 6px 10px;

    border-radius: 20px;

    background: rgba(255,70,70,.2);
    color: #ff9999;

    font-size: 10px;
    font-weight: bold;
}

.empty {
    padding: 30px;
    text-align: center;
    opacity: .7;
}

.count {
    margin-bottom: 15px;
    font-size: 13px;
    font-weight: bold;
}

</style>


<style>

/* =========================================
   POLISHED DRIVER INFORMATION BUTTON
========================================= */

.show-info-btn {
    display: block;
    width: 100%;

    margin-top: 15px;
    padding: 13px 16px;

    border: 1px solid rgba(255,255,255,.25);
    border-radius: 14px;

    background:
        linear-gradient(
            135deg,
            #0072ff 0%,
            #2457ff 45%,
            #7b2cff 100%
        );

    color: white;

    font-size: 13px;
    font-weight: 800;

    letter-spacing: .5px;

    cursor: pointer;

    box-shadow:
        0 8px 20px rgba(0, 55, 180, .35),
        inset 0 1px 0 rgba(255,255,255,.35);

    transition:
        transform .2s ease,
        box-shadow .2s ease,
        filter .2s ease;
}

.show-info-btn:hover {
    transform: translateY(-2px);

    filter: brightness(1.08);

    box-shadow:
        0 12px 28px rgba(0, 90, 255, .45),
        inset 0 1px 0 rgba(255,255,255,.4);
}

.show-info-btn:active {
    transform: scale(.97);
}


/* =========================================
   DRIVER INFORMATION MODAL
========================================= */

.driver-modal {
    display: none;

    position: fixed;
    inset: 0;

    z-index: 99999;

    width: 100%;
    height: 100%;

    padding: 20px;

    background:
        radial-gradient(
            circle at top,
            rgba(0, 100, 255, .20),
            transparent 45%
        ),
        rgba(0, 0, 15, .82);

    backdrop-filter: blur(8px);

    align-items: center;
    justify-content: center;

    overflow-y: auto;
}

.driver-modal-box {
    position: relative;

    width: min(900px, 100%);
    max-height: 92vh;

    overflow-y: auto;

    padding: 0;

    border-radius: 26px;

    background:
        linear-gradient(
            145deg,
            #071a4b,
            #102b75 45%,
            #35107d 100%
        );

    color: white;

    border: 2px solid rgba(72, 185, 255, .65);

    box-shadow:
        0 30px 90px rgba(0,0,0,.65),
        0 0 45px rgba(0, 105, 255, .25);

    animation: driverModalIn .25s ease-out;
}

@keyframes driverModalIn {

    from {
        opacity: 0;
        transform: translateY(25px) scale(.96);
    }

    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }

}


/* =========================================
   MODAL HEADER
========================================= */

.driver-modal-header {
    display: flex;
    align-items: center;
    gap: 15px;

    padding: 24px;

    background:
        linear-gradient(
            135deg,
            #006eff,
            #303de8 55%,
            #7b20ed
        );

    border-bottom: 1px solid rgba(255,255,255,.2);
}

.driver-modal-icon {
    width: 58px;
    height: 58px;

    display: flex;
    align-items: center;
    justify-content: center;

    flex-shrink: 0;

    border-radius: 50%;

    background: rgba(255,255,255,.18);

    border: 1px solid rgba(255,255,255,.35);

    font-size: 29px;

    box-shadow:
        inset 0 1px 0 rgba(255,255,255,.4);
}

.driver-modal-header h2 {
    margin: 0;

    font-size: 20px;

    letter-spacing: .5px;
}

.driver-modal-name {
    margin-top: 5px;

    font-size: 14px;
    font-weight: 600;

    opacity: .9;
}


/* =========================================
   CLOSE BUTTON
========================================= */

.driver-modal-close {
    position: absolute;

    top: 14px;
    right: 14px;

    z-index: 5;

    width: 40px;
    height: 40px;

    border: 1px solid rgba(255,255,255,.3);
    border-radius: 50%;

    background: rgba(0,0,0,.25);

    color: white;

    font-size: 20px;
    font-weight: bold;

    cursor: pointer;

    transition: .2s ease;
}

.driver-modal-close:hover {
    background: rgba(255,255,255,.2);
    transform: rotate(90deg);
}


/* =========================================
   ACCOUNT INFORMATION
========================================= */

.driver-info-content {
    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 12px;

    padding: 22px;
}

.driver-info-content > div {
    padding: 15px;

    border-radius: 15px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.10),
            rgba(255,255,255,.045)
        );

    border: 1px solid rgba(255,255,255,.12);

    box-shadow:
        inset 0 1px 0 rgba(255,255,255,.06);
}

.driver-info-content strong {
    display: block;

    margin-bottom: 7px;

    font-size: 11px;

    letter-spacing: .5px;

    opacity: .7;
}

.driver-info-content span {
    display: block;

    font-size: 14px;

    font-weight: 700;

    word-break: break-word;
}


/* =========================================
   REQUIREMENTS TITLE
========================================= */

.driver-modal-box h3 {
    margin: 0 22px 15px;

    padding: 13px 16px;

    border-radius: 13px;

    background:
        linear-gradient(
            135deg,
            #0072ff,
            #7b2cff
        );

    font-size: 15px;

    letter-spacing: .5px;

    box-shadow:
        0 8px 20px rgba(0, 70, 255, .25);
}


/* =========================================
   REQUIREMENT PHOTOS
========================================= */

.driver-requirements {
    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 15px;

    padding: 0 22px 25px;
}

.requirement-card {
    padding: 14px;

    border-radius: 17px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.10),
            rgba(255,255,255,.045)
        );

    border: 1px solid rgba(255,255,255,.13);

    text-align: center;
}

.requirement-card strong {
    display: block;

    margin-bottom: 12px;

    font-size: 13px;
}

.requirement-card img {
    display: block;

    width: 100%;
    height: 210px;

    object-fit: contain;

    border-radius: 12px;

    background: rgba(0,0,0,.3);

    border: 1px solid rgba(255,255,255,.12);
}


/* =========================================
   MOBILE
========================================= */

@media (max-width: 600px) {

    .driver-modal {
        padding: 10px;
    }

    .driver-modal-box {
        max-height: 94vh;

        border-radius: 20px;
    }

    .driver-modal-header {
        padding: 20px 16px;
        padding-right: 55px;
    }

    .driver-modal-header h2 {
        font-size: 17px;
    }

    .driver-modal-icon {
        width: 48px;
        height: 48px;

        font-size: 23px;
    }

    .driver-info-content {
        grid-template-columns: 1fr;

        padding: 16px;
    }

    .driver-modal-box h3 {
        margin-left: 16px;
        margin-right: 16px;
    }

    .driver-requirements {
        grid-template-columns: 1fr;

        padding-left: 16px;
        padding-right: 16px;
    }

    .requirement-card img {
        height: 220px;
    }

}

body.modal-open {
    overflow: hidden;
}

</style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>🛵 Total Drivers</h1>

        <p>
            All registered driver accounts
        </p>

        <a href="admin_dashboard.php" class="back">
            ← Back to Admin Dashboard
        </a>

    </div>

    <div class="count">
        TOTAL REGISTERED DRIVERS:
        <?php echo count($drivers); ?>
    </div>

    <?php if (count($drivers) > 0): ?>

        <?php foreach ($drivers as $driver): ?>

            <div
                class="card"
                data-driver-id="<?php echo (int) $driver['id']; ?>"
                data-full-name="<?php echo htmlspecialchars($driver['full_name'], ENT_QUOTES); ?>"
                data-email="<?php echo htmlspecialchars($driver['email'], ENT_QUOTES); ?>"
                data-phone="<?php echo htmlspecialchars($driver['phone'] ?? 'N/A', ENT_QUOTES); ?>"
                data-vehicle="<?php echo htmlspecialchars($driver['vehicle'] ?? 'N/A', ENT_QUOTES); ?>"
                data-plate="<?php echo htmlspecialchars($driver['plate'] ?? 'N/A', ENT_QUOTES); ?>"
                data-status="<?php echo htmlspecialchars($driver['status'] ?? 'N/A', ENT_QUOTES); ?>"
                data-verification="<?php echo $driver['driver_verified'] ? 'VERIFIED DRIVER' : 'NOT VERIFIED'; ?>"
                data-license="<?php echo htmlspecialchars($driver['driver_license_photo'] ?? '', ENT_QUOTES); ?>"
                data-government-id="<?php echo htmlspecialchars($driver['government_id_photo'] ?? '', ENT_QUOTES); ?>"
                data-profile="<?php echo htmlspecialchars($driver['profile_photo'] ?? '', ENT_QUOTES); ?>"
                data-vehicle-photo="<?php echo htmlspecialchars($driver['vehicle_photo'] ?? '', ENT_QUOTES); ?>"
            >

                <div class="name">
                    👤
                    <?php
                    echo htmlspecialchars(
                        $driver["full_name"]
                    );
                    ?>
                </div>

                <div class="info">

                    📧 Email:
                    <?php
                    echo htmlspecialchars(
                        $driver["email"]
                    );
                    ?>

                    <br>

                    🛵 Vehicle:
                    <?php
                    echo htmlspecialchars(
                        $driver["vehicle"] ?? "N/A"
                    );
                    ?>

                    <br>

                    🔢 Plate:
                    <?php
                    echo htmlspecialchars(
                        $driver["plate"] ?? "N/A"
                    );
                    ?>

                    <br>

                    🟢 Availability:
                    <?php
                    echo htmlspecialchars(
                        $driver["status"] ?? "N/A"
                    );
                    ?>

                </div>

                <?php if ($driver["driver_verified"]): ?>

                    <span class="verified">
                        🛡️ VERIFIED DRIVER
                    </span>

                <?php else: ?>

                    <span class="not-verified">
                        ⚠️ NOT VERIFIED
                    </span>

                <?php endif; ?>

                <button
                    type="button"
                    class="show-info-btn"
                    onclick="showDriverInformation(this)"
                    data-full-name="<?php echo htmlspecialchars($driver['full_name'], ENT_QUOTES); ?>"
                    data-email="<?php echo htmlspecialchars($driver['email'], ENT_QUOTES); ?>"
                    data-phone="<?php echo htmlspecialchars($driver['phone'] ?? 'N/A', ENT_QUOTES); ?>"
                    data-vehicle="<?php echo htmlspecialchars($driver['vehicle'] ?? 'N/A', ENT_QUOTES); ?>"
                    data-plate="<?php echo htmlspecialchars($driver['plate'] ?? 'N/A', ENT_QUOTES); ?>"
                    data-status="<?php echo htmlspecialchars($driver['status'] ?? 'N/A', ENT_QUOTES); ?>"
                    data-verification="<?php echo $driver['driver_verified'] ? 'VERIFIED DRIVER' : 'NOT VERIFIED'; ?>"
                    data-license="<?php echo htmlspecialchars($driver['driver_license_photo'] ?? '', ENT_QUOTES); ?>"
                    data-government-id="<?php echo htmlspecialchars($driver['government_id_photo'] ?? '', ENT_QUOTES); ?>"
                    data-profile="<?php echo htmlspecialchars($driver['profile_photo'] ?? '', ENT_QUOTES); ?>"
                    data-vehicle-photo="<?php echo htmlspecialchars($driver['vehicle_photo'] ?? '', ENT_QUOTES); ?>">
                    📋 SHOW ALL INFORMATION
                </button>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="card empty">

            🛵

            <br><br>

            No drivers registered yet.

        </div>

    <?php endif; ?>

</div>

<!-- DRIVER INFORMATION MODAL -->
<div id="driverInfoModal" class="driver-modal">

    <div class="driver-modal-box">

        <button
            type="button"
            class="driver-modal-close"
            onclick="closeDriverInformation()">
            ✕
        </button>

        <div class="driver-modal-header">
            <div class="driver-modal-icon">👤</div>

            <div>
                <h2>DRIVER ACCOUNT INFORMATION</h2>
                <div id="infoModalName" class="driver-modal-name">
                    -
                </div>
            </div>
        </div>

        <div class="driver-info-content">

            <div>
                <strong>👤 Full Name</strong>
                <span id="infoFullName">-</span>
            </div>

            <div>
                <strong>📧 Email</strong>
                <span id="infoEmail">-</span>
            </div>

            <div>
                <strong>📱 Phone</strong>
                <span id="infoPhone">-</span>
            </div>

            <div>
                <strong>🛵 Vehicle</strong>
                <span id="infoVehicle">-</span>
            </div>

            <div>
                <strong>🔢 Plate Number</strong>
                <span id="infoPlate">-</span>
            </div>

            <div>
                <strong>📊 Status</strong>
                <span id="infoStatus">-</span>
            </div>

            <div>
                <strong>🛡️ Verification</strong>
                <span id="infoVerification">-</span>
            </div>

        </div>

        <h3>📸 DRIVER REQUIREMENTS</h3>

        <div class="driver-requirements">

            <div class="requirement-card">
                <strong>🪪 Driver License</strong>
                <img id="infoLicensePhoto" src="" alt="Driver License">
            </div>

            <div class="requirement-card">
                <strong>🆔 Government ID</strong>
                <img id="infoGovernmentIdPhoto" src="" alt="Government ID">
            </div>

            <div class="requirement-card">
                <strong>👤 Profile Photo</strong>
                <img id="infoProfilePhoto" src="" alt="Profile Photo">
            </div>

            <div class="requirement-card">
                <strong>🛵 Vehicle Photo</strong>
                <img id="infoVehiclePhoto" src="" alt="Vehicle Photo">
            </div>

        </div>

    </div>

</div>

<script>
function showDriverInformation(button) {
    if (!button) {
        return;
    }

    document.getElementById("infoModalName").textContent =
        button.dataset.fullName || "-";

    document.getElementById("infoFullName").textContent =
        button.dataset.fullName || "-";

    document.getElementById("infoEmail").textContent =
        button.dataset.email || "-";

    document.getElementById("infoPhone").textContent =
        button.dataset.phone || "N/A";

    document.getElementById("infoVehicle").textContent =
        button.dataset.vehicle || "N/A";

    document.getElementById("infoPlate").textContent =
        button.dataset.plate || "N/A";

    document.getElementById("infoStatus").textContent =
        button.dataset.status || "N/A";

    document.getElementById("infoVerification").textContent =
        button.dataset.verification || "NOT VERIFIED";

    setDriverPhoto(
        "infoLicensePhoto",
        button.dataset.license
    );

    setDriverPhoto(
        "infoGovernmentIdPhoto",
        button.dataset.governmentId
    );

    setDriverPhoto(
        "infoProfilePhoto",
        button.dataset.profile
    );

    setDriverPhoto(
        "infoVehiclePhoto",
        button.dataset.vehiclePhoto
    );

    const modal =
        document.getElementById("driverInfoModal");

    modal.style.display = "flex";
    document.body.classList.add("modal-open");
}

function setDriverPhoto(elementId, filename) {

    const image = document.getElementById(elementId);

    if (!filename) {
        image.removeAttribute("src");
        image.style.display = "none";
        return;
    }

    image.src =
        "driver_photo.php?file=" +
        encodeURIComponent(filename);

    image.style.display = "block";
}

function closeDriverInformation() {

    const modal = document.getElementById("driverInfoModal");

    modal.style.display = "none";

    document.body.classList.remove("modal-open");
}

window.addEventListener("click", function(event) {

    const modal = document.getElementById("driverInfoModal");

    if (event.target === modal) {
        closeDriverInformation();
    }

});

document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {
        closeDriverInformation();
    }

});
</script>

</body>
</html>

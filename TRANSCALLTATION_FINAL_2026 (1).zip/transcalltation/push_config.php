<?php

require_once __DIR__ . "/vendor/autoload.php";

$env_file = getenv("HOME") . "/transcalltation_private.env";

if (!file_exists($env_file)) {
    die("Push configuration file not found.");
}

$push_env = parse_ini_file($env_file);

if ($push_env === false) {
    die("Unable to read push configuration.");
}

$VAPID_PUBLIC_KEY = $push_env["VAPID_PUBLIC_KEY"] ?? "";
$VAPID_PRIVATE_KEY = $push_env["VAPID_PRIVATE_KEY"] ?? "";
$VAPID_SUBJECT = $push_env["VAPID_SUBJECT"] ?? "";

if (
    $VAPID_PUBLIC_KEY === "" ||
    $VAPID_PRIVATE_KEY === "" ||
    $VAPID_SUBJECT === ""
) {
    die("Incomplete VAPID configuration.");
}
?>

self.addEventListener("install", event => {
    self.skipWaiting();
});

self.addEventListener("activate", event => {
    event.waitUntil(self.clients.claim());
});

self.addEventListener("push", event => {
    let data = {};

    try {
        data = event.data ? event.data.json() : {};
    } catch (e) {
        data = {
            title: "TransCalltation 2.0",
            body: event.data ? event.data.text() : "New notification"
        };
    }

    const title = data.title || "TransCalltation 2.0";

    const options = {
        body: data.body || "You have a new notification.",
        icon: "icon.png",
        badge: "icon.png"
    };

    event.waitUntil(
        self.registration.showNotification(title, options)
    );
});

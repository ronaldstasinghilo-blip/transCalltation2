<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$user_id = $_SESSION["user_id"];
$message = "";

/* Save appearance */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $appearance = $_POST["appearance"] ?? "Gradient";

    $allowed_appearances = [
        "Light",
        "Dark",
        "Gradient"
    ];

    if (in_array($appearance, $allowed_appearances, true)) {

        $stmt = $conn->prepare(
            "UPDATE users
             SET appearance = ?
             WHERE id = ?"
        );

        $stmt->bind_param(
            "si",
            $appearance,
            $user_id
        );

        if ($stmt->execute()) {
            $message = "Appearance saved successfully.";
        }

        $stmt->close();
    }
}

/* Get current appearance */
$stmt = $conn->prepare(
    "SELECT appearance
     FROM users
     WHERE id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();

$current_appearance = $user["appearance"] ?? "Gradient";
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Appearance - TransCalltation</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 20px;

    font-family: Arial, Helvetica, sans-serif;

    color: white;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #071a3d,
            #123b72,
            #6a35c9
        );
}

.container {
    max-width: 600px;
    margin: auto;
}

h1 {
    text-align: center;
}

.card {
    padding: 22px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border: 1px solid rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px rgba(0,0,0,.2);
}

label {
    display: block;

    margin-bottom: 8px;

    font-weight: bold;
}

select {
    width: 100%;

    padding: 14px;

    border: none;

    border-radius: 12px;

    font-size: 15px;

    background: white;

    color: #222;
}

button {
    width: 100%;

    margin-top: 20px;

    padding: 14px;

    border: none;

    border-radius: 12px;

    color: white;

    font-weight: bold;

    background:
        linear-gradient(
            135deg,
            #1769d1,
            #6a35c9
        );

    cursor: pointer;
}

.message {
    margin-bottom: 15px;

    padding: 12px;

    text-align: center;

    border-radius: 10px;

    background: rgba(0,180,100,.3);
}

.back {
    display: block;

    margin-top: 20px;

    text-align: center;

    color: white;

    text-decoration: none;
}

</style>

</head>

<body>

<div class="container">

<h1>🎨 APPEARANCE</h1>

<div class="card">

<?php if ($message !== ""): ?>

<div class="message">
    ✅ <?php echo htmlspecialchars($message); ?>
</div>

<?php endif; ?>

<form method="POST">

<label for="appearance">
    Select Appearance
</label>

<select
    name="appearance"
    id="appearance"
>

<option value="Light"
<?php echo $current_appearance === "Light" ? "selected" : ""; ?>>
☀️ Light Mode
</option>

<option value="Dark"
<?php echo $current_appearance === "Dark" ? "selected" : ""; ?>>
🌙 Dark Mode
</option>

<option value="Gradient"
<?php echo $current_appearance === "Gradient" ? "selected" : ""; ?>>
🌈 Gradient Color
</option>

</select>

<button type="submit">
    💾 SAVE APPEARANCE
</button>

</form>

</div>

<a href="settings.php" class="back">
    ← Back to Settings
</a>

</div>

</body>

</html>

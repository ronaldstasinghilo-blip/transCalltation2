<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

include "config.php";
include "languages.php";

$user_id = $_SESSION["user_id"];

/* Get logged-in user's information */
$stmt = $conn->prepare(
    "SELECT full_name, email, role
     FROM users
     WHERE id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>TransCalltation Settings</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #071a3d,
                    #123b72,
                    #0b6fa4
                );

            color: white;
            min-height: 100vh;
            padding: 20px;
        }

        .settings-container {
            max-width: 600px;
            margin: auto;
        }

        .settings-title {
            text-align: center;
            margin-bottom: 20px;
        }

        .settings-title h1 {
            margin: 0;
            font-size: 28px;
        }

        .settings-title p {
            opacity: .75;
        }

        .setting-card {
            display: block;
            text-decoration: none;
            color: white;

            padding: 18px;
            margin-bottom: 12px;

            border-radius: 18px;

            background:
                linear-gradient(
                    145deg,
                    rgba(255,255,255,.23),
                    rgba(255,255,255,.07)
                );

            border: 1px solid
                rgba(255,255,255,.25);

            box-shadow:
                0 10px 25px
                rgba(0,0,0,.2);
        }

        .setting-card h3 {
            margin: 0 0 5px;
            font-size: 17px;
        }

        .setting-card p {
            margin: 0;
            font-size: 13px;
            opacity: .75;
        }

        .logout {
            text-align: center;
            background:
                linear-gradient(
                    145deg,
                    rgba(255,80,80,.35),
                    rgba(255,80,80,.12)
                );
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: white;
            text-decoration: none;
        }

    </style>

</head>

<body>

<div class="settings-container">

    <div class="settings-title">

        <h1>⚙️ SETTINGS</h1>

        <p>Manage your TransCalltation account</p>

    </div>


    <a href="profile.php" class="setting-card">

        <h3>👤 Profile</h3>

        <p>
            Edit your personal information
        </p>

    </a>


    <a href="change_password.php" class="setting-card">

        <h3>🔐 Change Password</h3>

        <p>
            Update your account password
        </p>

    </a>


    <a href="notifications.php" class="setting-card">

        <h3>🔔 Notifications</h3>

        <p>
            Manage booking notifications
        </p>

    </a>


    
    <a href="language.php" class="setting-card">

    <h3>🌐 Language</h3>

    <p>
        English / Filipino / Cebuano / Waray / Chinese / Korean
    </p>

</a>


    
    <a href="appearance.php" class="setting-card">

    <h3>🎨 Appearance</h3>

    <p>
        Light / Dark Mode / Gradient Color
    </p>

</a>


    <a href="logout.php"
       class="setting-card logout">

        <h3>🚪 Logout</h3>

        <p>
            Sign out of your account
        </p>

    </a>


      <a href="<?php echo $user["role"] === "driver" ? "driver_dashboard.php" : ($user["role"] === "admin" ? "admin_dashboard.php" : "dashboard.php"); ?>" class="back">

          ← Back to Dashboard

      </a>

</div>


<!-- REAL DEVICE PUSH NOTIFICATIONS -->
<section class="settings-card push-notification-card">
    <div class="settings-card-icon">🔔</div>

    <div class="settings-card-content">
        <h3>Real Device Notifications</h3>
        <p>
            Receive TransCalltation alerts on this device for important
            booking and account updates.
        </p>

        <button type="button"
                id="enablePushNotifications"
                class="push-notification-button">
            🔔 ENABLE DEVICE NOTIFICATIONS
        </button>

        <div id="pushNotificationStatus"
             class="push-notification-status">
            Notifications are currently not connected.
        </div>
    </div>
</section>




<script>
if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
        navigator.serviceWorker.register("service-worker.js")
            .then(function (registration) {
                console.log("TransCalltation Service Worker registered.");
            })
            .catch(function (error) {
                console.error("Service Worker registration failed:", error);
            });
    });
}
</script>


<script>
document.addEventListener("DOMContentLoaded", async function () {

    const button = document.getElementById("enablePushNotifications");
    const status = document.getElementById("pushNotificationStatus");

    if (!button || !status) return;

    const VAPID_PUBLIC_KEY = "BLBpZ0PZi7Yhkx1-yJiiAYA02JhM5g_WZ8qet_NROeMVPg5m0q-sJI-jzVeBbLDkDeMApk0--Y3E0yqbbLOiAgU";

    function urlBase64ToUint8Array(base64String) {
        const padding = "=".repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding)
            .replace(/-/g, "+")
            .replace(/_/g, "/");

        const rawData = window.atob(base64);
        return Uint8Array.from(
            [...rawData].map(char => char.charCodeAt(0))
        );
    }

    async function saveSubscription(subscription) {

        const json = subscription.toJSON();

        const response = await fetch("save_push_subscription.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                endpoint: json.endpoint,
                p256dh: json.keys ? json.keys.p256dh : "",
                auth: json.keys ? json.keys.auth : "",
                device_name:
                    navigator.userAgent.substring(0, 100)
            })
        });

        return await response.json();
    }

    async function connectPushNotifications() {

        if (!("serviceWorker" in navigator)) {
            throw new Error("Service Worker is not supported.");
        }

        if (!("PushManager" in window)) {
            throw new Error("Push notifications are not supported.");
        }

        const registration =
            await navigator.serviceWorker.ready;

        let subscription =
            await registration.pushManager.getSubscription();

        if (!subscription) {

            subscription =
                await registration.pushManager.subscribe({
                    userVisibleOnly: true,
                    applicationServerKey:
                        urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
                });
        }

        const result = await saveSubscription(subscription);

        if (!result.success) {
            throw new Error(
                result.message || "Unable to save subscription."
            );
        }

        return result;
    }

    button.addEventListener("click", async function () {

        button.disabled = true;
        status.textContent =
            "Connecting this device to TransCalltation...";

        try {

            if (Notification.permission !== "granted") {
                const permission =
                    await Notification.requestPermission();

                if (permission !== "granted") {
                    throw new Error(
                        "Notification permission was not granted."
                    );
                }
            }

            await connectPushNotifications();

            button.textContent =
                "🔔 DEVICE CONNECTED";

            status.textContent =
                "This device is registered for TransCalltation push notifications.";

        } catch (error) {

            console.error(error);

            button.disabled = false;

            status.textContent =
                "Unable to connect push notifications: " +
                error.message;
        }
    });
});
</script>

</body>
</html>

<style>
/* =====================================================
   REAL DEVICE PUSH NOTIFICATIONS
===================================================== */

.push-notification-card {
    position: relative;
    margin: 20px 0;
    padding: 22px;
    border-radius: 20px;
    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,0.22),
            rgba(255,255,255,0.07)
        );
    border: 1px solid rgba(255,255,255,0.25);
    box-shadow:
        0 10px 30px rgba(0,0,0,0.25),
        inset 0 1px 0 rgba(255,255,255,0.25);
    backdrop-filter: blur(12px);
}

.push-notification-card h3 {
    margin: 0 0 8px;
    font-size: 21px;
    font-weight: 800;
}

.push-notification-card p {
    margin: 0 0 18px;
    line-height: 1.5;
}

.push-notification-button {
    display: inline-block;
    border: none;
    border-radius: 14px;
    padding: 13px 18px;
    font-size: 14px;
    font-weight: 800;
    cursor: pointer;
    color: white;
    background:
        linear-gradient(
            135deg,
            #2563eb,
            #7c3aed
        );
    box-shadow:
        0 6px 18px rgba(37,99,235,0.35),
        inset 0 1px 0 rgba(255,255,255,0.3);
    transition: 0.2s ease;
}

.push-notification-button:hover {
    transform: translateY(-2px);
    box-shadow:
        0 9px 24px rgba(37,99,235,0.45),
        inset 0 1px 0 rgba(255,255,255,0.35);
}

.push-notification-button:active {
    transform: translateY(0);
}

.push-notification-button:disabled {
    opacity: 0.55;
    cursor: not-allowed;
    transform: none;
}

.push-notification-status {
    margin-top: 12px;
    font-size: 13px;
    opacity: 0.85;
}
</style>

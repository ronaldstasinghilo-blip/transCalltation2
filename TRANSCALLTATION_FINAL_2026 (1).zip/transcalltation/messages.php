<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = (int)$_SESSION["user_id"];

/* Get logged-in user */
$stmt = $conn->prepare("
    SELECT id, full_name, role
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

/* Role-based dashboard */
if ($user["role"] === "admin") {
    $back_dashboard = "admin_dashboard.php";
} elseif ($user["role"] === "driver") {
    $back_dashboard = "driver_dashboard.php";
} else {
    $back_dashboard = "dashboard.php";
}

/*
 * Admin inbox mode.
 * This does NOT replace normal 1-to-1 conversations.
 */
$admin_inbox = (
    $user["role"] === "admin"
    && isset($_GET["inbox"])
    && $_GET["inbox"] === "all"
);

$selected_user_id = isset($_GET["user"]) ? (int)$_GET["user"] : 0;

/* Get all other users */
$stmt = $conn->prepare("
    SELECT id, full_name, role
    FROM users
    WHERE id != ?
    ORDER BY
        CASE role
            WHEN 'admin' THEN 1
            WHEN 'driver' THEN 2
            WHEN 'student' THEN 3
            ELSE 4
        END,
        full_name ASC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$users = $stmt->get_result();

/* Validate selected user */
$selected_user = null;

if ($selected_user_id > 0) {
    $stmt = $conn->prepare("
        SELECT id, full_name, role
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $selected_user_id);
    $stmt->execute();
    $selected_user = $stmt->get_result()->fetch_assoc();

    if (!$selected_user || (int)$selected_user["id"] === $user_id) {
        $selected_user = null;
        $selected_user_id = 0;
    }
}

/* Get conversation */
$messages = null;

if ($selected_user_id > 0) {
    $stmt = $conn->prepare("
        SELECT
            m.id,
            m.sender_id,
            m.receiver_id,
            m.message,
            m.photo,
            m.message_type,
        m.complaint_status,
            m.is_read,
            m.created_at,
            u.full_name AS sender_name
        FROM messages m
        INNER JOIN users u ON u.id = m.sender_id
        WHERE
            (m.sender_id = ? AND m.receiver_id = ?)
            OR
            (m.sender_id = ? AND m.receiver_id = ?)
        ORDER BY m.created_at ASC, m.id ASC
    ");

    $stmt->bind_param(
        "iiii",
        $user_id,
        $selected_user_id,
        $selected_user_id,
        $user_id
    );

    $stmt->execute();
    $messages = $stmt->get_result();

    /* Mark received messages as read */
    $stmt = $conn->prepare("
        UPDATE messages
        SET is_read = 1
        WHERE sender_id = ?
          AND receiver_id = ?
          AND is_read = 0
    ");

    $stmt->bind_param(
        "ii",
        $selected_user_id,
        $user_id
    );

    $stmt->execute();
}

/*
 * ADMIN ALL INBOX
 *
 * Shows every message in the messaging system.
 * This is read-only data loading; it does not alter
 * the existing 1-to-1 conversation system.
 */
$all_inbox_messages = null;
$admin_unread_total = 0;

if ($admin_inbox) {
    $stmt = $conn->prepare("
        SELECT
            m.id,
            m.sender_id,
            m.receiver_id,
            m.message,
            m.photo,
            m.message_type,
        m.complaint_status,
            m.is_read,
            m.created_at,
            s.full_name AS sender_name,
            s.role AS sender_role,
            r.full_name AS receiver_name,
            r.role AS receiver_role
        FROM messages m
        INNER JOIN users s ON s.id = m.sender_id
        INNER JOIN users r ON r.id = m.receiver_id
        ORDER BY m.created_at DESC, m.id DESC
    ");

    $stmt->execute();
    $all_inbox_messages = $stmt->get_result();

    /*
     * Admin's own unread messages.
     * These are messages specifically sent TO the Admin.
     */
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS unread_total
        FROM messages
        WHERE receiver_id = ?
          AND is_read = 0
    ");

    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $admin_unread_row = $stmt->get_result()->fetch_assoc();
    $admin_unread_total = (int)($admin_unread_row["unread_total"] ?? 0);
}

/* Count unread messages */
$unread_counts = [];

$stmt = $conn->prepare("
    SELECT sender_id, COUNT(*) AS unread_count
    FROM messages
    WHERE receiver_id = ?
      AND is_read = 0
    GROUP BY sender_id
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $unread_counts[(int)$row["sender_id"]] =
        (int)$row["unread_count"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Messages - TransCalltation 2.0</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    font-family: Arial, Helvetica, sans-serif;

    background:
        linear-gradient(
            rgba(3, 8, 25, 0.82),
            rgba(3, 8, 25, 0.94)
        ),
        url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
        center center / cover no-repeat fixed;

    color: white;
}

.page {
    width: min(1150px, 96%);
    margin: 25px auto;
}

.header {
    padding: 22px 25px;
    border-radius: 24px;

    background: rgba(255,255,255,0.10);
    border: 1px solid rgba(255,255,255,0.18);

    backdrop-filter: blur(12px);

    box-shadow:
        0 15px 40px rgba(0,0,0,.35);
}

.header h1 {
    margin: 0 0 7px;

    font-size: 30px;
    font-weight: 900;

    background:
        linear-gradient(
            90deg,
            #00eaff,
            #ffffff,
            #b86cff,
            #ff4fd8
        );

    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.header p {
    margin: 0;
    color: #dcecff;
}

/* =====================================================
   MESSENGER
===================================================== */

.messenger {
    margin-top: 20px;

    display: grid;
    grid-template-columns: 310px 1fr;

    min-height: 650px;

    overflow: hidden;

    border-radius: 26px;

    background: rgba(7, 13, 35, 0.82);

    border: 1px solid rgba(255,255,255,0.16);

    box-shadow:
        0 20px 55px rgba(0,0,0,.45);

    backdrop-filter: blur(15px);
}

/* =====================================================
   USER LIST
===================================================== */

.user-list {
    border-right: 1px solid rgba(255,255,255,0.12);

    background:
        linear-gradient(
            180deg,
            rgba(0,234,255,.08),
            rgba(123,44,255,.08)
        );

    overflow-y: auto;
}

.user-list-title {
    padding: 20px;

    font-size: 18px;
    font-weight: 900;

    border-bottom:
        1px solid rgba(255,255,255,0.12);
}

.user-card {
    display: flex;
    align-items: center;

    gap: 12px;

    padding: 14px 16px;

    color: white;
    text-decoration: none;

    border-bottom:
        1px solid rgba(255,255,255,0.07);

    transition: .2s;
}

.user-card:hover,
.user-card.active {
    background:
        linear-gradient(
            90deg,
            rgba(0,234,255,.17),
            rgba(123,44,255,.20)
        );
}

.avatar {
    width: 45px;
    height: 45px;

    flex-shrink: 0;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    font-size: 20px;

    background:
        linear-gradient(
            135deg,
            #00a8ff,
            #7b2cff
        );

    box-shadow:
        0 5px 15px rgba(0,0,0,.3);
}

.user-info {
    min-width: 0;
    flex: 1;
}

.user-name {
    font-weight: 800;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.user-role {
    margin-top: 3px;

    font-size: 12px;

    color: #a9c7e8;

    text-transform: uppercase;
}

.unread {
    min-width: 23px;
    height: 23px;

    padding: 0 6px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: #ff3d81;

    font-size: 11px;
    font-weight: 900;
}

/* =====================================================
   CHAT AREA
===================================================== */

.chat {
    display: flex;
    flex-direction: column;

    min-width: 0;
}

.chat-header {
    padding: 17px 20px;

    display: flex;
    align-items: center;

    gap: 12px;

    border-bottom:
        1px solid rgba(255,255,255,0.12);
}

.chat-header-name {
    font-size: 18px;
    font-weight: 900;
}

.chat-header-role {
    margin-top: 3px;

    font-size: 12px;

    color: #9fc4e8;

    text-transform: uppercase;
}

.messages {
    flex: 1;

    padding: 22px;

    overflow-y: auto;

    display: flex;
    flex-direction: column;

    gap: 10px;
}

.empty-chat {
    flex: 1;

    display: flex;
    align-items: center;
    justify-content: center;

    text-align: center;

    padding: 30px;

    color: #a9bdd5;
}

.empty-chat-icon {
    font-size: 60px;
    margin-bottom: 10px;
}

/* =====================================================
   MESSAGE BUBBLES
===================================================== */

.message-row {
    display: flex;
}

.message-row.mine {
    justify-content: flex-end;
}

.message-bubble {
    max-width: min(75%, 520px);

    padding: 11px 14px;

    border-radius: 18px;

    background:
        rgba(255,255,255,0.10);

    border:
        1px solid rgba(255,255,255,0.10);
}

.message-row.mine .message-bubble {
    background:
        linear-gradient(
            135deg,
            #087fbe,
            #6830b5
        );
}

.message-type {
    margin-bottom: 5px;

    font-size: 10px;
    font-weight: 900;

    color: #8ff8ff;

    text-transform: uppercase;
}

.message-text {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
}

.message-photo {
    display: block;

    max-width: 260px;
    max-height: 260px;

    margin-top: 8px;

    border-radius: 12px;

    border:
        1px solid rgba(255,255,255,.2);
}

.message-time {
    margin-top: 5px;

    font-size: 10px;

    color: rgba(255,255,255,.65);

    text-align: right;
}

/* =====================================================
   COMPOSER
===================================================== */

.composer {
    padding: 13px;

    border-top:
        1px solid rgba(255,255,255,0.12);
}

.composer form {
    display: flex;
    gap: 9px;
    align-items: center;
}

.composer textarea {
    flex: 1;

    min-height: 48px;
    max-height: 120px;

    resize: vertical;

    padding: 13px 15px;

    border-radius: 16px;

    border:
        1px solid rgba(255,255,255,.15);

    outline: none;

    color: white;

    background:
        rgba(255,255,255,.08);

    font-family: Arial, Helvetica, sans-serif;
}

.composer textarea::placeholder {
    color: #9bb0c7;
}

.composer textarea:focus {
    border-color: #00eaff;

    box-shadow:
        0 0 0 2px rgba(0,234,255,.12);
}

.send-btn {
    border: 0;

    padding: 13px 18px;

    border-radius: 15px;

    color: white;

    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            135deg,
            #00a8ff,
            #7b2cff
        );

    box-shadow:
        0 7px 18px rgba(0,0,0,.25);
}

.send-btn:hover {
    transform: translateY(-1px);
}

.complaint-btn {
    border: 0;

    padding: 12px 14px;

    border-radius: 14px;

    color: white;

    font-weight: 800;

    cursor: pointer;

    background:
        linear-gradient(
            135deg,
            #ff4f81,
            #b52cff
        );
}

.photo-label {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 46px;
    height: 46px;

    border-radius: 14px;

    cursor: pointer;

    background:
        rgba(255,255,255,.10);

    border:
        1px solid rgba(255,255,255,.15);

    font-size: 20px;
}

.photo-label:hover {
    background:
        rgba(0,234,255,.15);
}

#photo {
    display: none;
}

.selected-file {
    margin-top: 7px;

    font-size: 11px;

    color: #9fc4e8;
}

/* =====================================================
   MOBILE
===================================================== */

@media (max-width: 760px) {

    .page {
        width: 98%;
        margin: 10px auto;
    }

    .header {
        padding: 18px;
    }

    .header h1 {
        font-size: 24px;
    }

    .messenger {
        grid-template-columns: 1fr;
        min-height: 750px;
    }

    .user-list {
        max-height: 260px;

        border-right: 0;

        border-bottom:
            1px solid rgba(255,255,255,.12);
    }

    .user-list-title {
        padding: 14px;
    }

    .chat {
        min-height: 480px;
    }

    .message-bubble {
        max-width: 88%;
    }

    .composer form {
        flex-wrap: wrap;
    }

    .composer textarea {
        width: 100%;
        flex-basis: 100%;
    }

    .send-btn,
    .complaint-btn {
        flex: 1;
    }
}

</style>
</head>

<body>





<div class="page">

    <div class="header">

        <h1>💬 TransCalltation Messenger</h1>

        <p>
            Welcome,
            <?php echo htmlspecialchars($user["full_name"]); ?>.
            Account:
            <?php echo htmlspecialchars($user["role"]); ?>
        </p>

    </div>

    <div class="messenger">

        <!-- USER LIST -->

        <?php if ($user["role"] === "admin"): ?>
            <form method="get" action="messages.php" class="admin-inbox-form">
            <input type="hidden" name="inbox" value="all">

            <button type="submit"
                    class="admin-inbox-card <?php echo $admin_inbox ? "active" : ""; ?>">
                <span class="admin-inbox-icon">📥</span>

                <span class="admin-inbox-text">
                    <strong>ALL INBOX</strong>
                    <small>View all messages &amp; complaints</small>
                </span>

                <?php if ($admin_unread_total > 0): ?>
                    <span class="admin-inbox-badge">
                        <?php echo $admin_unread_total; ?>
                    </span>
                <?php endif; ?>
            </button>
        </form>
        <?php endif; ?>

        <aside class="user-list">

            <div class="user-list-title">
                👥 USERS
            </div>

            <?php while ($person = $users->fetch_assoc()): ?>

                <?php
                $person_id = (int)$person["id"];

                $avatar = "👤";

                if ($person["role"] === "admin") {
                    $avatar = "🛡️";
                } elseif ($person["role"] === "driver") {
                    $avatar = "🛵";
                } elseif ($person["role"] === "student") {
                    $avatar = "🎓";
                }

                $unread = $unread_counts[$person_id] ?? 0;
                ?>

                <a
                    href="messages.php?user=<?php echo $person_id; ?>"
                    class="user-card <?php echo $selected_user_id === $person_id ? 'active' : ''; ?>"
                >

                    <div class="avatar">
                        <?php echo $avatar; ?>
                    </div>

                    <div class="user-info">

                        <div class="user-name">
                            <?php echo htmlspecialchars($person["full_name"]); ?>
                        </div>

                        <div class="user-role">
                            <?php echo htmlspecialchars($person["role"]); ?>
                        </div>

                    </div>

                    <?php if ($unread > 0): ?>

                        <div class="unread">
                            <?php echo $unread > 99 ? "99+" : $unread; ?>
                        </div>

                    <?php endif; ?>

                </a>

            <?php endwhile; ?>

        </aside>


        <!-- CHAT -->

        <main class="chat">

            <?php if ($admin_inbox): ?>
                <div class="admin-inbox-view">
                    <div class="admin-inbox-header">
                        <h2>📥 ALL INBOX</h2>
                        <p>All messages and complaints from every account</p>
                    </div>

                    <?php if ($all_inbox_messages && $all_inbox_messages->num_rows > 0): ?>
                        <div class="admin-inbox-list">
                            <?php while ($inbox_msg = $all_inbox_messages->fetch_assoc()): ?>
                                <div class="admin-inbox-message">
                                    <div class="admin-inbox-message-top">
                                        <strong>
                                            <?php echo htmlspecialchars($inbox_msg["sender_name"]); ?>
                                        </strong>

                                        <span>
                                            <?php echo htmlspecialchars($inbox_msg["sender_role"]); ?>
                                            →
                                            <?php echo htmlspecialchars($inbox_msg["receiver_name"]); ?>
                                            (<?php echo htmlspecialchars($inbox_msg["receiver_role"]); ?>)
                                        </span>
                                    </div>

                                    <?php if ($inbox_msg["message_type"] === "complaint"): ?>
                                        <div class="inbox-type complaint">
                                            ⚠️ COMPLAINT
                                        </div>

                                    <div class="complaint-status">
                                        STATUS:
                                        <strong><?php echo htmlspecialchars($inbox_msg["complaint_status"]); ?></strong>
                                    </div>

                                    <div class="complaint-actions">
                                        <form method="post" action="manage_complaint.php">
                                            <input type="hidden" name="message_id" value="<?php echo (int)$inbox_msg["id"]; ?>">
                                            <input type="hidden" name="status" value="In Progress">
                                            <button type="submit" class="complaint-action progress">
                                                🔵 IN PROGRESS
                                            </button>
                                        </form>

                                        <form method="post" action="manage_complaint.php">
                                            <input type="hidden" name="message_id" value="<?php echo (int)$inbox_msg["id"]; ?>">
                                            <input type="hidden" name="status" value="Resolved">
                                            <button type="submit" class="complaint-action resolved">
                                                🟢 RESOLVED
                                            </button>
                                        </form>

                                        <form method="get" action="messages.php">
                                            <input type="hidden" name="user" value="<?php echo (int)$inbox_msg["sender_id"]; ?>">
                                            <button type="submit" class="complaint-action reply">
                                                💬 REPLY DIRECTLY
                                            </button>
                                        </form>
                                    </div>
                                    <?php else: ?>
                                        <div class="inbox-type message">
                                            💬 MESSAGE
                                        </div>
                                    <?php endif; ?>

                                    <?php if (!empty($inbox_msg["message"])): ?>
                                        <div class="admin-inbox-message-text">
                                            <?php echo nl2br(htmlspecialchars($inbox_msg["message"])); ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (!empty($inbox_msg["photo"])): ?>
                                        <div class="admin-inbox-photo">
                                            <img src="<?php echo htmlspecialchars($inbox_msg["photo"]); ?>" alt="Message photo">
                                        </div>
                                    <?php endif; ?>

                                    <div class="admin-inbox-time">
                                        <?php echo htmlspecialchars($inbox_msg["created_at"]); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-chat">
                            📭 No messages or complaints yet.
                        </div>
                    <?php endif; ?>
                </div>

            <?php elseif ($selected_user): ?>

                <div class="chat-header">

                    <div class="avatar">
                        <?php
                        if ($selected_user["role"] === "admin") {
                            echo "🛡️";
                        } elseif ($selected_user["role"] === "driver") {
                            echo "🛵";
                        } else {
                            echo "🎓";
                        }
                        ?>
                    </div>

                    <div>

                        <div class="chat-header-name">
                            <?php echo htmlspecialchars($selected_user["full_name"]); ?>
                        </div>

                        <div class="chat-header-role">
                            <?php echo htmlspecialchars($selected_user["role"]); ?>
                        </div>

                    </div>

                </div>


                <div class="messages">

                    <?php if ($messages && $messages->num_rows > 0): ?>

                        <?php while ($msg = $messages->fetch_assoc()): ?>

                            <div class="message-row <?php echo (int)$msg["sender_id"] === $user_id ? 'mine' : ''; ?>">

                                <div class="message-bubble">

                                    <?php if ($msg["message_type"] !== "message"): ?>

                                        <div class="message-type">
                                            🚨 <?php echo htmlspecialchars($msg["message_type"]); ?>
                                        </div>

                                    <?php endif; ?>

                                    <?php if (!empty($msg["message"])): ?>

                                        <div class="message-text">
                                            <?php echo htmlspecialchars($msg["message"]); ?>
                                        </div>

                                    <?php endif; ?>

                                    <?php if (!empty($msg["photo"])): ?>

                                        <img
                                            src="<?php echo htmlspecialchars($msg["photo"]); ?>"
                                            class="message-photo"
                                            alt="Message photo"
                                        >

                                    <?php endif; ?>

                                    <div class="message-time">
                                        <?php echo htmlspecialchars($msg["created_at"]); ?>
                                    </div>

                                </div>

                            </div>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <div class="empty-chat">

                            <div>

                                <div class="empty-chat-icon">
                                    💬
                                </div>

                                <h2>
                                    Start a conversation
                                </h2>

                                <p>
                                    Send a message to
                                    <?php echo htmlspecialchars($selected_user["full_name"]); ?>.
                                </p>

                            </div>

                        </div>

                    <?php endif; ?>

                </div>


                <!-- MESSAGE COMPOSER -->

                <div class="composer">

                    <form
                        action="send_message.php"
                        method="POST"
                        enctype="multipart/form-data"
                    >

                        <input
                            type="hidden"
                            name="receiver_id"
                            value="<?php echo $selected_user_id; ?>"
                        >

                        <textarea
                            name="message"
                            placeholder="Type a message..."
                        ></textarea>

                        <label
                            for="photo"
                            class="photo-label"
                            title="Attach photo"
                        >
                            📷
                        </label>

                        <input
                            type="file"
                            name="photo"
                            id="photo"
                            accept="image/*"
                        >

                        <button
                            type="submit"
                            name="message_type"
                            value="message"
                            class="send-btn"
                        >
                            ➤ SEND
                        </button>

                        <button
                            type="submit"
                            name="message_type"
                            value="complaint"
                            class="complaint-btn"
                        >
                            🚨 COMPLAINT
                        </button>

                    </form>

                    <div id="selectedFile" class="selected-file"></div>

                </div>

            <?php else: ?>

                <div class="empty-chat">

                    <div>

                        <div class="empty-chat-icon">
                            💬
                        </div>

                        <h2>
                            TransCalltation Messenger
                        </h2>

                        <p>
                            Select a user on the left to start a conversation.
                        </p>

                    </div>

                </div>

            <?php endif; ?>

        </main>

    </div>

</div>

<script>

const photoInput = document.getElementById("photo");
const selectedFile = document.getElementById("selectedFile");

if (photoInput) {

    photoInput.addEventListener("change", function () {

        if (this.files.length > 0) {

            selectedFile.textContent =
                "📷 Selected: " + this.files[0].name;

        } else {

            selectedFile.textContent = "";

        }

    });

}

</script>


<div class="back-dashboard-wrap">
    <a href="<?php echo htmlspecialchars($back_dashboard); ?>" class="back-dashboard-btn">
        ⬅️ BACK TO ADMIN DASHBOARD
    </a>
</div>

</body>

<style>
/* =====================================================
   STEP 64E-9 — CLEAN ALL INBOX BUTTON
===================================================== */

.admin-inbox-form {
    width: 100%;
    margin: 0 0 14px 0;
}

.admin-inbox-card {
    width: 100%;
    min-height: 72px;
    display: flex;
    align-items: center;
    gap: 12px;

    padding: 14px 16px;
    border: 1px solid rgba(255,255,255,0.18);
    border-radius: 16px;

    background:
        linear-gradient(
            145deg,
            rgba(102,70,190,0.95),
            rgba(48,32,105,0.98)
        );

    color: white;
    text-align: left;

    cursor: pointer;
    font: inherit;

    box-shadow:
        0 8px 22px rgba(0,0,0,0.28),
        inset 0 1px 0 rgba(255,255,255,0.18);

    transition:
        transform 0.2s ease,
        box-shadow 0.2s ease;
}

.admin-inbox-card:hover {
    transform: translateY(-2px);

    box-shadow:
        0 12px 28px rgba(0,0,0,0.35),
        0 0 18px rgba(145,100,255,0.28),
        inset 0 1px 0 rgba(255,255,255,0.22);
}

.admin-inbox-card.active {
    box-shadow:
        0 10px 28px rgba(0,0,0,0.35),
        0 0 20px rgba(160,110,255,0.40),
        inset 0 1px 0 rgba(255,255,255,0.22);
}

.admin-inbox-icon {
    flex: 0 0 auto;
    font-size: 28px;
}

.admin-inbox-text {
    min-width: 0;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.admin-inbox-text strong {
    font-size: 15px;
    font-weight: 800;
    letter-spacing: 0.4px;
}

.admin-inbox-text small {
    color: rgba(255,255,255,0.78);
    font-size: 12px;
    line-height: 1.3;
}

.admin-inbox-badge {
    flex: 0 0 auto;
    min-width: 28px;
    height: 28px;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 0 8px;
    border-radius: 999px;

    background: #ff3b3b;
    color: white;

    font-size: 12px;
    font-weight: 800;

    box-shadow: 0 0 12px rgba(255,59,59,0.45);
}

/* Keep the inbox view inside the chat area */
.admin-inbox-view {
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
}

.admin-inbox-header {
    margin-bottom: 16px;
}

.admin-inbox-header h2 {
    margin: 0 0 5px;
}

.admin-inbox-header p {
    margin: 0;
    opacity: 0.72;
    font-size: 13px;
}

.admin-inbox-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.admin-inbox-message {
    width: 100%;
    box-sizing: border-box;
    padding: 14px;
    border-radius: 15px;

    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.12);

    box-shadow: 0 5px 16px rgba(0,0,0,0.18);
}

.admin-inbox-message-top {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
}

.admin-inbox-message-top span {
    opacity: 0.7;
    font-size: 11px;
}

.admin-inbox-message-text {
    margin-top: 10px;
    line-height: 1.45;
    word-break: break-word;
}

.inbox-type {
    display: inline-block;
    margin-top: 9px;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 800;
}

.inbox-type.message {
    background: rgba(100,150,255,0.18);
}

.inbox-type.complaint {
    background: rgba(255,70,70,0.18);
}

.admin-inbox-time {
    margin-top: 9px;
    opacity: 0.5;
    font-size: 10px;
}

@media (max-width: 700px) {
    .admin-inbox-card {
        min-height: 64px;
        padding: 12px;
    }

    .admin-inbox-message {
        padding: 12px;
    }
}
</style>


<style>
/* =====================================================
   COMPLAINT MANAGEMENT
===================================================== */

.complaint-status {
    margin-top: 10px;
    padding: 9px 12px;
    border-radius: 12px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    color: #ffffff;
    font-size: 13px;
    font-weight: 600;
}

.complaint-status strong {
    margin-left: 5px;
    color: #ffd54a;
}

.complaint-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 12px;
}

.complaint-actions form {
    margin: 0;
}

.complaint-action {
    border: 0;
    border-radius: 12px;
    padding: 10px 13px;
    color: #ffffff;
    font-weight: 800;
    font-size: 12px;
    cursor: pointer;
    box-shadow:
        0 5px 14px rgba(0,0,0,0.28),
        inset 0 1px 0 rgba(255,255,255,0.25);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.complaint-action:hover {
    transform: translateY(-2px);
    box-shadow:
        0 8px 20px rgba(0,0,0,0.35),
        inset 0 1px 0 rgba(255,255,255,0.3);
}

.complaint-action:active {
    transform: translateY(0);
}

.complaint-action.progress {
    background: linear-gradient(135deg, #1976d2, #42a5f5);
}

.complaint-action.resolved {
    background: linear-gradient(135deg, #168a45, #43c96b);
}

.complaint-action.reply {
    background: linear-gradient(135deg, #6a35c9, #a66cff);
}

@media (max-width: 700px) {
    .complaint-actions {
        flex-direction: column;
    }

    .complaint-actions form,
    .complaint-action {
        width: 100%;
    }
}
</style>

</html>

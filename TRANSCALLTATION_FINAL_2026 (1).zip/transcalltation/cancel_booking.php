<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$booking_id = intval($_GET["id"] ?? 0);

if ($booking_id <= 0) {
    header("Location: dashboard.php");
    exit();
}

/*
 * Cancel only the logged-in student's booking.
 * This prevents one student from cancelling
 * another student's booking.
 */
$stmt = $conn->prepare(
    "UPDATE bookings
     SET status = 'Cancelled'
     WHERE id = ?
     AND student_id = ?
     AND status = 'Pending'"
);

$stmt->bind_param("ii", $booking_id, $user_id);
$stmt->execute();

$stmt->close();

header("Location: dashboard.php");
exit();
?>

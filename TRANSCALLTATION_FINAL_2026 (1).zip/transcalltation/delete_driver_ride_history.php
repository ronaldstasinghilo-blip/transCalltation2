<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

/* Make sure the account is a driver */
$stmt = $conn->prepare(
    "SELECT role FROM users WHERE id = ? LIMIT 1"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();

if (!$user || $user["role"] !== "driver") {
    header("Location: dashboard.php");
    exit();
}

/* Delete only this driver's ride history */
$stmt = $conn->prepare(
    "DELETE FROM bookings
     WHERE driver_id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$stmt->close();

header("Location: driver_dashboard.php");
exit();
?>

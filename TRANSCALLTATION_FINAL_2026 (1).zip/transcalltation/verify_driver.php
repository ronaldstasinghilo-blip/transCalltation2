<?php

session_start();
include "config.php";

/* Must be logged in */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}


/* Check admin */

$admin_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $admin_id);
$stmt->execute();

$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$stmt->close();


if (!$admin || $admin["role"] !== "admin") {

    header("Location: dashboard.php");
    exit();

}


/* Verify selected driver */

$driver_id = intval(
    $_POST["driver_id"] ?? 0
);

if ($driver_id > 0) {

    $stmt = $conn->prepare(
        "UPDATE users
         SET driver_verified = 1
         WHERE id = ?
         AND role = 'driver'"
    );

    $stmt->bind_param(
        "i",
        $driver_id
    );

    $stmt->execute();

    $stmt->close();
}


/* Return to admin dashboard */

header("Location: admin_dashboard.php");

exit();

?>
<?php
/*
=========================================================
TRANSCALLTATION 2.0
REALISTIC CINEMATIC WELCOME PAGE
=========================================================
This page only handles the welcome screen.
GET STARTED -> login.php
=========================================================
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="TransCalltation 2.0
        "
    >

    <title>TransCalltation 2.0</title>

    <!-- Google Font -->
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet"
    >

    <style>

        /* =====================================================
           RESET
        ===================================================== */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        html {
            scroll-behavior: smooth;
        }


        body {
            min-height: 100vh;

            font-family:
                "Inter",
                system-ui,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            color: #ffffff;

            overflow-x: hidden;

            background:
                linear-gradient(
                    rgba(3, 8, 25, 0.68),
                    rgba(3, 8, 25, 0.88)
                ),
                url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
                center center / cover no-repeat fixed;
        }


        /* =====================================================
           BACKGROUND EFFECTS
        ===================================================== */

        body::before {
            content: "";

            position: fixed;

            inset: 0;

            pointer-events: none;

            background:
                radial-gradient(
                    circle at 15% 30%,
                    rgba(0, 153, 255, 0.18),
                    transparent 35%
                ),

                radial-gradient(
                    circle at 85% 65%,
                    rgba(83, 55, 255, 0.18),
                    transparent 38%
                );

            z-index: -1;
        }


        body::after {
            content: "";

            position: fixed;

            inset: 0;

            pointer-events: none;

            background:
                linear-gradient(
                    90deg,
                    rgba(0, 0, 0, 0.25),
                    transparent 45%,
                    rgba(0, 0, 0, 0.35)
                );

            z-index: -1;
        }


        /* =====================================================
           MAIN CONTAINER
        ===================================================== */

        .page {
            min-height: 100vh;

            display: flex;

            flex-direction: column;
        }


        /* =====================================================
           NAVIGATION
        ===================================================== */

        .navbar {
            width: 100%;

            padding:
                22px
                6%;

            display: flex;

            align-items: center;

            justify-content: space-between;

            position: relative;

            z-index: 10;
        }


        .brand {
            display: flex;

            align-items: center;

            gap: 12px;

            text-decoration: none;

            color: white;

            font-size: 18px;

            font-weight: 800;

            letter-spacing: .5px;
        }


        .brand-icon {
            width: 45px;

            height: 45px;

            display: flex;

            align-items: center;

            justify-content: center;

            border-radius: 14px;

            background:
                linear-gradient(
                    135deg,
                    #087cff,
                    #5744ff
                );

            border:
                1px solid
                rgba(255,255,255,.35);

            box-shadow:
                0 0 18px
                rgba(0,145,255,.5);

            font-size: 23px;
        }


        .nav-status {
            display: flex;

            align-items: center;

            gap: 8px;

            padding:
                9px
                15px;

            border-radius: 30px;

            background:
                rgba(255,255,255,.08);

            border:
                1px solid
                rgba(255,255,255,.15);

            backdrop-filter: blur(12px);

            font-size: 12px;

            font-weight: 700;

            letter-spacing: .6px;

            color:
                rgba(255,255,255,.9);
        }


        .status-dot {
            width: 8px;

            height: 8px;

            border-radius: 50%;

            background: #39ff88;

            box-shadow:
                0 0 10px
                rgba(57,255,136,.9);

            animation:
                statusPulse 1.7s
                ease-in-out
                infinite;
        }


        @keyframes statusPulse {

            0%,
            100% {
                opacity: 1;

                transform: scale(1);
            }

            50% {
                opacity: .45;

                transform: scale(.7);
            }
        }


        /* =====================================================
           HERO
        ===================================================== */

        .hero {
            flex: 1;

            width: 100%;

            max-width: 1450px;

            margin:
                0
                auto;

            padding:
                45px
                6%
                80px;

            display: flex;

            align-items: center;

            position: relative;
        }


        .hero-content {
            width: 58%;

            max-width: 720px;

            position: relative;

            z-index: 3;

            animation:
                heroIn
                1s
                ease
                both;
        }


        @keyframes heroIn {

            from {
                opacity: 0;

                transform:
                    translateY(35px);
            }

            to {
                opacity: 1;

                transform:
                    translateY(0);
            }
        }


        /* =====================================================
           WELCOME LABEL
        ===================================================== */

        .welcome-label {
            display: inline-flex;

            align-items: center;

            gap: 10px;

            margin-bottom: 20px;

            padding:
                9px
                16px;

            border-radius: 30px;

            background:
                rgba(255,255,255,.09);

            border:
                1px solid
                rgba(255,255,255,.2);

            backdrop-filter: blur(12px);

            box-shadow:
                0 8px 30px
                rgba(0,0,0,.2);

            color:
                rgba(255,255,255,.9);

            font-size: 12px;

            font-weight: 800;

            letter-spacing: 2.5px;
        }


        .welcome-label span {
            width: 7px;

            height: 7px;

            border-radius: 50%;

            background: #23aaff;

            box-shadow:
                0 0 12px
                #23aaff;
        }


        /* =====================================================
           TITLE
        ===================================================== */

        h1 {
            font-size:
                clamp(
                    45px,
                    7vw,
                    92px
                );

            line-height: .94;

            font-weight: 900;

            letter-spacing: -4px;

            margin-bottom: 22px;

            text-shadow:
                0 5px 30px
                rgba(0,0,0,.45);
        }


        .title-main {
            display: block;

            background:
                linear-gradient(
                    100deg,
                    #ffffff 0%,
                    #dcecff 35%,
                    #6cbcff 65%,
                    #a37bff 100%
                );

            -webkit-background-clip: text;

            background-clip: text;

            color: transparent;
        }


        .title-version {
            display: block;

            margin-top: 8px;

            font-size:
                clamp(
                    22px,
                    3vw,
                    34px
                );

            letter-spacing:
                1px;

            color:
                rgba(255,255,255,.82);
        }


        /* =====================================================
           TAGLINE
        ===================================================== */

        .tagline {
            font-size:
                clamp(
                    15px,
                    2vw,
                    19px
                );

            font-weight: 800;

            letter-spacing: 4px;

            color:
                #8fcfff;

            margin-bottom: 24px;

            text-shadow:
                0 0 18px
                rgba(44,170,255,.35);
        }


        /* =====================================================
           DESCRIPTION
        ===================================================== */

        .description {
            max-width: 610px;

            font-size: 16px;

            line-height: 1.8;

            color:
                rgba(255,255,255,.78);

            margin-bottom: 35px;
        }


        /* =====================================================
           GET STARTED BUTTON
        ===================================================== */

        .get-started {
            position: relative;

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 13px;

            min-width: 270px;

            padding:
                18px
                30px;

            border-radius: 60px;

            text-decoration: none;

            color: #ffffff;

            font-size: 17px;

            font-weight: 900;

            letter-spacing: 1px;

            background:
                linear-gradient(
                    100deg,
                    #087cff,
                    #4c42ff,
                    #9b3cff,
                    #087cff
                );

            background-size: 300% 100%;

            border:
                2px solid
                rgba(255,255,255,.65);

            box-shadow:
                0 0 10px
                rgba(0,174,255,.8),

                0 0 25px
                rgba(0,115,255,.65),

                0 0 50px
                rgba(125,50,255,.45);

            animation:
                buttonGradient 4s
                linear
                infinite,

                buttonGlow 1.8s
                ease-in-out
                infinite;

            transition:
                transform .25s ease,
                box-shadow .25s ease;
        }


        .get-started::before {
            content: "";

            position: absolute;

            inset: -5px;

            border-radius: 60px;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    rgba(255,255,255,.45),
                    transparent
                );

            background-size: 200% 100%;

            opacity: .35;

            z-index: -1;

            animation:
                buttonSweep 2.5s
                linear
                infinite;
        }


        .get-started:hover {
            transform:
                translateY(-4px)
                scale(1.02);

            box-shadow:
                0 0 15px
                rgba(0,190,255,.95),

                0 0 35px
                rgba(60,100,255,.8),

                0 0 75px
                rgba(150,60,255,.65);
        }


        .get-started:active {
            transform:
                translateY(0)
                scale(.98);
        }


        @keyframes buttonGradient {

            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }


        @keyframes buttonGlow {

            0%,
            100% {
                box-shadow:
                    0 0 10px
                    rgba(0,174,255,.8),

                    0 0 25px
                    rgba(0,115,255,.65),

                    0 0 50px
                    rgba(125,50,255,.45);
            }

            50% {
                box-shadow:
                    0 0 15px
                    rgba(0,210,255,1),

                    0 0 35px
                    rgba(70,110,255,.85),

                    0 0 75px
                    rgba(155,60,255,.65);
            }
        }


        @keyframes buttonSweep {

            0% {
                background-position:
                    200% 0;
            }

            100% {
                background-position:
                    -200% 0;
            }
        }


        .button-arrow {
            font-size: 20px;

            transition:
                transform .25s ease;
        }


        .get-started:hover .button-arrow {
            transform:
                translateX(5px);
        }


        /* =====================================================
           MOTORCYCLE VISUAL
        ===================================================== */

        .motorcycle-area {
            position: absolute;

            right: 1%;

            bottom: 5%;

            width: 48%;

            height: 80%;

            display: flex;

            align-items: flex-end;

            justify-content: center;

            pointer-events: none;

            z-index: 2;
        }


        .motorcycle-glow {
            position: absolute;

            width: 75%;

            height: 28%;

            bottom: 8%;

            border-radius: 50%;

            background:
                radial-gradient(
                    ellipse,
                    rgba(0,155,255,.35),
                    transparent 65%
                );

            filter: blur(18px);

            animation:
                roadGlow 3s
                ease-in-out
                infinite;
        }


        @keyframes roadGlow {

            0%,
            100% {
                transform: scaleX(1);

                opacity: .7;
            }

            50% {
                transform: scaleX(1.12);

                opacity: 1;
            }
        }


        /*
           Decorative motorcycle silhouette.
           The actual page background supplies the
           realistic photographic motorcycle environment.
        */

        .bike-symbol {
            position: relative;

            font-size:
                clamp(
                    150px,
                    24vw,
                    340px
                );

            filter:
                drop-shadow(
                    0 15px 35px
                    rgba(0,0,0,.8)
                )

                drop-shadow(
                    0 0 35px
                    rgba(0,145,255,.28)
                );

            transform:
                rotate(-3deg);

            animation:
                bikeFloat 4s
                ease-in-out
                infinite;
        }


        @keyframes bikeFloat {

            0%,
            100% {
                transform:
                    translateY(0)
                    rotate(-3deg);
            }

            50% {
                transform:
                    translateY(-9px)
                    rotate(-2deg);
            }
        }


        /* =====================================================
           FEATURE CARDS
        ===================================================== */

        .features {
            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 14px;

            margin-top: 38px;

            max-width: 720px;
        }


        .feature {
            min-height: 105px;

            padding:
                17px;

            border-radius: 18px;

            background:
                rgba(255,255,255,.075);

            border:
                1px solid
                rgba(255,255,255,.16);

            backdrop-filter:
                blur(15px);

            box-shadow:
                0 12px 35px
                rgba(0,0,0,.2);

            transition:
                transform .25s ease,
                background .25s ease,
                border-color .25s ease;
        }


        .feature:hover {
            transform:
                translateY(-5px);

            background:
                rgba(255,255,255,.12);

            border-color:
                rgba(120,200,255,.4);
        }


        .feature-icon {
            font-size: 24px;

            margin-bottom: 9px;
        }


        .feature-title {
            font-size: 13px;

            font-weight: 800;

            margin-bottom: 5px;
        }


        .feature-text {
            font-size: 11px;

            line-height: 1.5;

            color:
                rgba(255,255,255,.58);
        }


        /* =====================================================
           BOTTOM SCROLL INDICATOR
        ===================================================== */

        .scroll-indicator {
            position: absolute;

            bottom: 28px;

            left: 50%;

            transform:
                translateX(-50%);

            display: flex;

            flex-direction: column;

            align-items: center;

            gap: 7px;

            color:
                rgba(255,255,255,.45);

            font-size: 10px;

            letter-spacing: 2px;

            font-weight: 700;
        }


        .scroll-line {
            width: 1px;

            height: 28px;

            background:
                linear-gradient(
                    to bottom,
                    rgba(255,255,255,.65),
                    transparent
                );

            animation:
                scrollLine 1.7s
                ease-in-out
                infinite;
        }


        @keyframes scrollLine {

            0%,
            100% {
                transform:
                    translateY(0);

                opacity: .4;
            }

            50% {
                transform:
                    translateY(7px);

                opacity: 1;
            }
        }


        /* =====================================================
           FOOTER
        ===================================================== */

        footer {
            position: relative;

            z-index: 5;

            padding:
                20px 6%;

            text-align: center;

            color:
                rgba(255,255,255,.45);

            font-size: 11px;

            letter-spacing: .4px;

            border-top:
                1px solid
                rgba(255,255,255,.08);

            background:
                rgba(0,0,0,.16);

            backdrop-filter:
                blur(10px);
        }


        footer strong {
            color:
                rgba(255,255,255,.72);
        }


        /* =====================================================
           TABLET
        ================================

========================================= */

        @media (max-width: 1000px) {

            .hero {
                padding-top: 35px;
            }


            .hero-content {
                width: 70%;
            }


            .motorcycle-area {
                width: 48%;

                right: -7%;

                opacity: .72;
            }


            .features {
                grid-template-columns:
                    repeat(2, 1fr);
            }
        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 700px) {

            body {
                background-attachment: scroll;

                background-position:
                    62% center;
            }


            .navbar {
                padding:
                    18px 20px;
            }


            .brand {
                font-size: 15px;
            }


            .brand-icon {
                width: 39px;

                height: 39px;

                font-size: 19px;
            }


            .nav-status {
                font-size: 9px;

                padding:
                    7px 10px;
            }


            .hero {
                min-height:
                    calc(100vh - 75px);

                padding:
                    35px 20px 70px;

                align-items: center;
            }


            .hero-content {
                width: 100%;

                max-width: none;

                text-align: center;

                z-index: 4;
            }


            .welcome-label {
                font-size: 9px;

                letter-spacing: 2px;
            }


            h1 {
                font-size:
                    clamp(
                        42px,
                        14vw,
                        65px
                    );

                letter-spacing:
                    -2.5px;
            }


            .title-version {
                font-size: 20px;
            }


            .tagline {
                font-size: 11px;

                letter-spacing: 2px;

                line-height: 1.7;
            }


            .description {
                font-size: 13px;

                line-height: 1.7;

                margin-left: auto;

                margin-right: auto;

                max-width: 480px;
            }


            .get-started {
                min-width: 235px;

                padding:
                    16px 24px;

                font-size: 14px;
            }


            .motorcycle-area {
                width: 100%;

                height: 45%;

                right: 0;

                bottom: 5%;

                opacity: .28;

                z-index: 1;
            }


            .bike-symbol {
                font-size: 180px;
            }


            .features {
                max-width: 500px;

                margin:
                    30px auto 0;

                grid-template-columns:
                    repeat(2, 1fr);

                text-align: left;
            }


            .feature {
                min-height: 95px;

                padding: 14px;
            }


            .scroll-indicator {
                display: none;
            }


            footer {
                padding:
                    17px 20px;

                font-size: 9px;
            }
        }


        /* =====================================================
           SMALL PHONES
        ===================================================== */

        @media (max-width: 420px) {

            .nav-status {
                display: none;
            }


            .hero {
                padding-top: 20px;
            }


            .welcome-label {
                margin-bottom: 14px;
            }


            .description {
                font-size: 12px;

                margin-bottom: 25px;
            }


            .features {
                gap: 9px;
            }


            .feature {
                min-height: 90px;

                border-radius: 14px;
            }


            .feature-icon {
                font-size: 20px;
            }


            .feature-title {
                font-size: 11px;
            }


            .feature-text {
                font-size: 9px;
            }
        }

    </style>

<style>
.creator-credit {
    margin-top: 8px;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 1.5px;
    color: rgba(255,255,255,0.78);
    text-shadow: 0 2px 8px rgba(0,0,0,0.6);
}
</style>

</head>


<body>

<div class="page">


    <!-- =====================================================
         NAVIGATION
    ===================================================== -->

    <header class="navbar">

        <a href="index.php" class="brand">

            <div class="brand-icon">
                🏍️
            </div>

            <span>
                TransCalltation
            </span>

        </a>


        <div class="nav-status">

            <span class="status-dot"></span>

            SYSTEM ONLINE

        </div>

    </header>



    <!-- =====================================================
         HERO SECTION
    ===================================================== -->

    <main class="hero">


        <div class="hero-content">


            <div class="welcome-label">

                <span></span>

                WELCOME TO

            </div>



            <h1>

                <span class="title-main">
                    TransCalltation
                    <div class="creator-credit">Made by | Texpad</div>
                </span>

                <span class="title-version">
                    2.0
                </span>

            </h1>



            <div class="tagline">

                SMART • SAFE • SIMPLE TRANSPORTATION

            </div>



            <p class="description">

                Your convenient student transportation
                booking system. Find available drivers,
                request a ride, and manage your bookings
                through one simple and secure platform.

            </p>



            <!-- =================================================
                 GET STARTED
            ================================================= -->

            <a
                href="about.php"
                class="get-started"
            >

                <span>
                    GET STARTED
                </span>

                <span class="button-arrow">
                    →
                </span>

            </a>



            <!-- =================================================
                 FEATURES
            ================================================= -->

            <div class="features">


                <div class="feature">

                    <div class="feature-icon">
                        📍
                    </div>

                    <div class="feature-title">
                        EASY BOOKING
                    </div>

                    <div class="feature-text">
                        Request your ride with
                        a simple booking process.
                    </div>

                </div>



                <div class="feature">

                    <div class="feature-icon">
                        🛵
                    </div>

                    <div class="feature-title">
                        VERIFIED DRIVERS
                    </div>

                    <div class="feature-text">
                        Connect with registered
                        and verified drivers.
                    </div>

                </div>



                <div class="feature">

                    <div class="feature-icon">
                        🛡️
                    </div>

                    <div class="feature-title">
                        SAFE & SECURE
                    </div>

                    <div class="feature-text">
                        Designed with student
                        transportation in mind.
                    </div>

                </div>



                <div class="feature">

                    <div class="feature-icon">
                        📋
                    </div>

                    <div class="feature-title">
                        RIDE RECORDS
                    </div>

                    <div class="feature-text">
                        Keep track of your
                        transportation bookings.
                    </div>

                </div>


            </div>


        </div>



        <!-- =====================================================
             MOTORCYCLE VISUAL
        ===================================================== -->

        <div class="motorcycle-area">

            <div class="motorcycle-glow"></div>

            <div class="bike-symbol">
                🏍️
            </div>

        </div>



        <!-- =====================================================
             SCROLL INDICATOR
        ===================================================== -->

        <div class="scroll-indicator">

            <div class="scroll-line"></div>

            EXPLORE

        </div>


    </main>



    <!-- =====================================================
         FOOTER
    ===================================================== -->

    <footer>

        <strong>
            TransCalltation 2.0
        </strong>

        &nbsp;•&nbsp;

        Smart • Safe • Simple Transportation

        &nbsp;•&nbsp;

        Student Transportation System

    </footer>


</div>

</body>
</html>

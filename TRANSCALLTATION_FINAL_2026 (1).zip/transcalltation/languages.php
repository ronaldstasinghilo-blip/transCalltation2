<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/* =====================================================
   SUPPORTED LANGUAGES
===================================================== */

$languages = [

    "en"  => "English",
    "fil" => "Filipino",
    "ceb" => "Cebuano",
    "war" => "Waray",
    "zh"  => "Chinese",
    "ko"  => "Korean"

];


/* =====================================================
   LANGUAGE SELECTION
===================================================== */

if (
    isset($_GET["lang"]) &&
    array_key_exists($_GET["lang"], $languages)
) {

    $_SESSION["language"] = $_GET["lang"];
}


/* =====================================================
   CURRENT LANGUAGE
===================================================== */

$current_language = $_SESSION["language"] ?? "en";

if (isset($_SESSION["user_id"]) && isset($conn)) {

    $stmt = $conn->prepare(
        "SELECT language
         FROM users
         WHERE id = ?
         LIMIT 1"
    );

    $stmt->bind_param("i", $_SESSION["user_id"]);
    $stmt->execute();

    $result = $stmt->get_result();
    $user_language = $result->fetch_assoc();

    $stmt->close();

    if (!empty($user_language["language"])) {
        $current_language = $user_language["language"];
        $_SESSION["language"] = $current_language;
    }
}


/* =====================================================
   TRANSLATIONS
===================================================== */

$text = [

    /* ================= ENGLISH ================= */

    "en" => [

        "dashboard"    => "Dashboard",
        "welcome"      => "Welcome",
        "logout"       => "Logout",
        "language"     => "Language",
        "book"         => "Book a Ride",
        "bookings"     => "My Bookings",
        "availability" => "Manage Availability",
        "users"        => "Users",
        "drivers"      => "Drivers",
        "verify_driver"=> "Verify Drivers",
        "admin"        => "Admin",
        "student"      => "Student",
        "driver"       => "Driver",
        "available"    => "Available",
        "unavailable"  => "Unavailable"

    ],


    /* ================= FILIPINO ================= */

    "fil" => [

        "dashboard"    => "Dashboard",
        "welcome"      => "Maligayang Pagdating",
        "logout"       => "Mag-logout",
        "language"     => "Wika",
        "book"         => "Mag-book ng Sakay",
        "bookings"     => "Aking mga Booking",
        "availability" => "Pamahalaan ang Availability",
        "users"        => "Mga User",
        "drivers"      => "Mga Driver",
        "verify_driver"=> "I-verify ang mga Driver",
        "admin"        => "Admin",
        "student"      => "Estudyante",
        "driver"       => "Driver",
        "available"    => "Available",
        "unavailable"  => "Hindi Available"

    ],


    /* ================= CEBUANO ================= */

    "ceb" => [

        "dashboard"    => "Dashboard",
        "welcome"      => "Maayong Pag-abot",
        "logout"       => "Pag-logout",
        "language"     => "Pinulongan",
        "book"         => "Mag-book og Sakay",
        "bookings"     => "Akong mga Booking",
        "availability" => "Pagdumala sa Availability",
        "users"        => "Mga User",
        "drivers"      => "Mga Driver",
        "verify_driver"=> "I-verify ang mga Driver",
        "admin"        => "Admin",
        "student"      => "Estudyante",
        "driver"       => "Driver",
        "available"    => "Available",
        "unavailable"  => "Dili Available"

    ],


    /* ================= WARAY ================= */

    "war" => [

        "dashboard"    => "Dashboard",
        "welcome"      => "Maupay nga Pag-abot",
        "logout"       => "Pag-logout",
        "language"     => "Pinulongan",
        "book"         => "Mag-book hin Sakay",
        "bookings"     => "Akon mga Booking",
        "availability" => "Pagdumara han Availability",
        "users"        => "Mga User",
        "drivers"      => "Mga Driver",
        "verify_driver"=> "I-verify an mga Driver",
        "admin"        => "Admin",
        "student"      => "Estudyante",
        "driver"       => "Driver",
        "available"    => "Available",
        "unavailable"  => "Diri Available"

    ],


    /* ================= CHINESE ================= */

    "zh" => [

        "dashboard"    => "仪表板",
        "welcome"      => "欢迎",
        "logout"       => "退出登录",
        "language"     => "语言",
        "book"         => "预约乘车",
        "bookings"     => "我的预约",
        "availability" => "管理可用状态",
        "users"        => "用户",
        "drivers"      => "司机",
        "verify_driver"=> "验证司机",
        "admin"        => "管理员",
        "student"      => "学生",
        "driver"       => "司机",
        "available"    => "可用",
        "unavailable"  => "不可用"

    ],


    /* ================= KOREAN ================= */

    "ko" => [

        "dashboard"    => "대시보드",
        "welcome"      => "환영합니다",
        "logout"       => "로그아웃",
        "language"     => "언어",
        "book"         => "차량 예약",
        "bookings"     => "내 예약",
        "availability" => "운행 가능 여부 관리",
        "users"        => "사용자",
        "drivers"      => "운전자",
        "verify_driver"=> "운전자 인증",
        "admin"        => "관리자",
        "student"      => "학생",
        "driver"       => "운전자",
        "available"    => "이용 가능",
        "unavailable"  => "이용 불가"

    ]

];


/* =====================================================
   TRANSLATION FUNCTION
===================================================== */

function t($key) {

    global $text, $current_language;

    return $text[$current_language][$key]
        ?? $text["en"][$key]
        ?? $key;
}

?>

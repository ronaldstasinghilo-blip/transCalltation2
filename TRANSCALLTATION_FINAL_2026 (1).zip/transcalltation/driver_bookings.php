<?php
session_start();
include "config.php";

/* =====================================================
   PROTECT PAGE
===================================================== */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = (int) $_SESSION["user_id"];


/* =====================================================
   GET LOGGED-IN USER
===================================================== */

$stmt = $conn->prepare(
    "SELECT id, full_name, email, role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

if (!$stmt) {
    die("Database error: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();


/* =====================================================
   ONLY DRIVER CAN ACCESS
===================================================== */

if (!$user || strtolower($user["role"]) !== "driver") {
    header("Location: driver_dashboard.php");
    exit();
}
/* =====================================================
   ACCEPT PENDING BOOKING
===================================================== */

if ($_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST["accept_booking"])) {

    $booking_id = (int) $_POST["accept_booking"];

    $stmt = $conn->prepare(
        "UPDATE bookings
         SET status = 'Accepted'
         WHERE id = ?
           AND driver_id = ?
           AND LOWER(status) = 'pending'"
    );

    if (!$stmt) {
        die("Accept booking error: " . $conn->error);
    }

    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $stmt->close();

    header("Location: driver_bookings.php");
    exit();
}


/* =====================================================
   GET DRIVER BOOKINGS
===================================================== */

$bookings = [];

/* =====================================================
   GET DRIVER BOOKINGS
===================================================== */

$bookings = [];

$stmt = $conn->prepare(
    "SELECT
        b.id,
        b.pickup,
        b.pickup_latitude,
        b.pickup_longitude,
        b.dropoff,
        b.status,
        b.created_at,
        u.full_name AS student_name,
        u.email AS student_email
     FROM bookings b
     LEFT JOIN users u
        ON b.student_id = u.id
     WHERE b.driver_id = ?
     ORDER BY b.id DESC"
);

if (!$stmt) {
    die("Booking database error: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

$stmt->close();


/* =====================================================
   COUNT BOOKINGS
===================================================== */

$total = count($bookings);
$pending = 0;
$accepted = 0;
$completed = 0;
$cancelled = 0;

foreach ($bookings as $booking) {

    $status = strtolower(
        trim($booking["status"] ?? "")
    );

    if ($status === "pending") {
        $pending++;
    } elseif ($status === "accepted") {
        $accepted++;
    } elseif ($status === "completed") {
        $completed++;
    } elseif ($status === "cancelled") {
        $cancelled++;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Driver Bookings | TransCalltation 2.0</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 15px;
    min-height: 100vh;

    font-family: Arial, Helvetica, sans-serif;
    color: white;

    background:
        radial-gradient(
            circle at top left,
            #00e5ff,
            transparent 30%
        ),
        radial-gradient(
            circle at bottom right,
            #e100ff,
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

    background-size: 200% 200%;
    animation: bgMove 12s ease infinite;
}

.container {
    width: 100%;
    max-width: 1050px;
    margin: auto;
}

.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;

    padding: 18px;
    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.9),
            rgba(142,45,226,.9)
        );

    border: 1px solid rgba(255,255,255,.3);

    box-shadow:
        0 15px 35px rgba(0,0,0,.3),
        inset 0 1px 3px rgba(255,255,255,.5);
}

.brand {
    display: flex;
    align-items: center;
    gap: 12px;
}

.logo {
    width: 55px;
    height: 55px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 16px;

    font-size: 28px;

    background: rgba(255,255,255,.2);

    box-shadow:
        inset 0 1px 4px rgba(255,255,255,.5);
}

h1 {
    margin: 0;
    font-size: 20px;
}

.brand p {
    margin: 4px 0 0;
    font-size: 10px;
    opacity: .8;
}

.back {
    display: inline-block;

    padding: 10px 15px;

    border-radius: 12px;

    color: white;
    text-decoration: none;

    font-size: 11px;
    font-weight: bold;

    background: rgba(0,0,0,.25);
}

.welcome {
    padding: 25px;
    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.07)
        );

    border: 1px solid rgba(255,255,255,.25);

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px rgba(0,0,0,.25);
}

.welcome h2 {
    margin: 0;
    font-size: 24px;
}

.welcome p {
    margin-top: 8px;
    font-size: 13px;
    opacity: .8;
}

.stats {
    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 12px;

    margin-bottom: 20px;
}

.stat {
    padding: 17px;

    text-align: center;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border: 1px solid rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px rgba(0,0,0,.2);
}

.stat-icon {
    font-size: 24px;
}

.stat-number {
    margin-top: 5px;

    font-size: 22px;
    font-weight: bold;
}

.stat-label {
    margin-top: 4px;

    font-size: 9px;
    font-weight: bold;

    opacity: .75;
}

.section {
    padding: 20px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.07)
        );

    border: 1px solid rgba(255,255,255,.25);

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px rgba(0,0,0,.25);
}

.section h3 {
    margin: 0 0 15px;
    font-size: 19px;
}

.booking {
    padding: 18px;
    margin-bottom: 13px;

    border-radius: 18px;

    background:
        linear-gradient(
            135deg,
            rgba(0,198,255,.22),
            rgba(123,44,255,.18)
        );

    border: 1px solid rgba(255,255,255,.25);

    box-shadow:
        0 8px 20px rgba(0,0,0,.2);
}

.booking:last-child {
    margin-bottom: 0;
}

.booking-top {
    display: flex;
    justify-content: space-between;
    gap: 10px;

    margin-bottom: 12px;
}

.student {
    font-size: 16px;
    font-weight: bold;
}

.booking-id {
    font-size: 10px;
    opacity: .7;
}

.info {
    font-size: 12px;
    line-height: 1.9;
}

.info strong {
    color: white;
}

.status {
    display: inline-block;

    padding: 6px 11px;

    margin-top: 5px;

    border-radius: 20px;

    font-size: 10px;
    font-weight: bold;

    background: rgba(0,0,0,.3);
}

.empty {
    padding: 40px 20px;

    text-align: center;

    font-size: 14px;

    opacity: .8;
}

@keyframes bgMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

@media(max-width:700px) {

    body {
        padding: 10px;
    }

    .header {
        padding: 14px;
    }

    h1 {
        font-size: 16px;
    }

    .stats {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .booking-top {
        flex-direction: column;
    }

    .back {
        padding: 9px 11px;
    }
}


.driver-pickup-map {
    width: 100%;
    height: 45vh;
    min-height: 280px;
    max-height: 550px;
    margin: 12px 0 18px;
    border-radius: 16px;
    overflow: hidden;
    border: 2px solid rgba(255,255,255,.3);
    box-shadow: 0 8px 25px rgba(0,0,0,.30);
}

.pickup-map-title {
    margin-top: 12px;
    margin-bottom: 8px;
    font-weight: bold;
}

.pickup-map-unavailable {
    margin: 12px 0 18px;
    padding: 12px;
    border-radius: 12px;
    background: rgba(255,255,255,.12);
    font-weight: bold;
}

@media (max-width: 600px) {
    .driver-pickup-map {
        height: 55vh;
        min-height: 320px;
        max-height: 600px;
    }
}

</style>

</head>

<body>

<div class="container">

    <!-- HEADER -->

    <header class="header">

        <div class="brand">

            <div class="logo">
                🛵
            </div>

            <div>

                <h1>
                    TransCalltation 2.0
                </h1>

                <p>
                    DRIVER BOOKING MANAGEMENT
                </p>

            </div>

        </div>

        <a href="driver_dashboard.php" class="back">
            ← DASHBOARD
        </a>

    </header>


    <!-- WELCOME -->

    <section class="welcome">

        <h2>
            Driver Bookings 🚗
        </h2>

        <p>
            Welcome,
            <?php echo htmlspecialchars($user["full_name"]); ?>.
            Here you can view your assigned ride requests.
        </p>

    </section>


    <!-- STATISTICS -->

    <div class="stats">

        <div class="stat">

            <div class="stat-icon">
                📋
            </div>

            <div class="stat-number">
                <?php echo $total; ?>
            </div>

            <div class="stat-label">
                TOTAL
            </div>

        </div>


        <div class="stat">

            <div class="stat-icon">
                ⏳
            </div>

            <div class="stat-number">
                <?php echo $pending; ?>
            </div>

            <div class="stat-label">
                PENDING
            </div>

        </div>


        <div class="stat">

            <div class="stat-icon">
                ✅
            </div>

            <div class="stat-number">
                <?php echo $accepted; ?>
            </div>

            <div class="stat-label">
                ACCEPTED
            </div>

        </div>


        <div class="stat">

            <div class="stat-icon">
                🏁
            </div>

            <div class="stat-number">
                <?php echo $completed; ?>
            </div>

            <div class="stat-label">
                COMPLETED
            </div>

        </div>

    </div>


    <!-- BOOKINGS -->

    <section class="section">

        <h3>
            📋 My Ride Requests
        </h3>


        <?php if (empty($bookings)): ?>

            <div class="empty">

                🚫 No bookings assigned to you yet.

            </div>

        <?php else: ?>


            <?php foreach ($bookings as $booking): ?>

                <div class="booking">

                    <div class="booking-top">

                        <div class="student">

                            👨‍🎓
                            <?php
                            echo htmlspecialchars(
                                $booking["student_name"] ?? "Student"
                            );
                            ?>

                        </div>

                        <div class="booking-id">

                            Booking #
                            <?php
                            echo (int)$booking["id"];
                            ?>

                        </div>

                    </div>


                    <div class="info">

                        📧 Student Email:

                        <strong>
                            <?php
                            echo htmlspecialchars(
                                $booking["student_email"] ?? "N/A"
                            );
                            ?>
                        </strong>

                        <br>

                        📍 Pickup:

                        <strong>
                            <?php
                            echo htmlspecialchars(
                                $booking["pickup"] ?? "N/A"
                            );
                            ?>
                        </strong>

                        <br>

                        <?php if (!empty($booking["pickup_latitude"]) && !empty($booking["pickup_longitude"])): ?>
<div class="pickup-map-title">📍 CUSTOMER PICKUP AREA</div>
<div id="pickupMap<?php echo (int)$booking["id"]; ?>" class="driver-pickup-map" data-lat="<?php echo htmlspecialchars($booking["pickup_latitude"]); ?>" data-lng="<?php echo htmlspecialchars($booking["pickup_longitude"]); ?>"></div>
<?php else: ?>
<div class="pickup-map-unavailable">📍 GPS location not available for this booking.</div>
<?php endif; ?>

🏁 Drop-off:

                        <strong>
                            <?php
                            echo htmlspecialchars(
                                $booking["dropoff"] ?? "N/A"
                            );
                            ?>
                        </strong>

                        <br>

                        🕒 Requested:

                        <strong>
                            <?php
                            echo htmlspecialchars(
                                $booking["created_at"] ?? "N/A"
                            );
?>
                        </strong>

                        <br>

                        Status:

                        <span class="status">

                            <?php
                            echo htmlspecialchars(
                                $booking["status"] ?? "Pending"
                            );
                            ?>

                        </span>
<?php if (strtolower(trim($booking["status"] ?? "")) === "pending"): ?>

    <form method="POST" style="margin-top:15px;">

        <button
            type="submit"
            name="accept_booking"
            value="<?php echo (int) $booking["id"]; ?>"
        >
            ✅ Accept Request
        </button>

    </form>

<?php endif; ?>

                    </div>

                </div>

            <?php endforeach; ?>


        <?php endif; ?>

    </section>

</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".driver-pickup-map").forEach(function (mapElement) {
        const latitude = parseFloat(mapElement.dataset.lat);
        const longitude = parseFloat(mapElement.dataset.lng);

        if (isNaN(latitude) || isNaN(longitude)) {
            return;
        }

        const map = L.map(mapElement).setView([latitude, longitude], 16);

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            maxZoom: 19,
            attribution: "&copy; OpenStreetMap contributors"
        }).addTo(map);

        L.marker([latitude, longitude])
            .addTo(map)
            .bindPopup("📍 Customer Pickup Area")
            .openPopup();
    });
});
</script>

</body>
</html>

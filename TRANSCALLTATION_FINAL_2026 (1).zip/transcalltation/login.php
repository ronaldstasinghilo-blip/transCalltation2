<?php

session_start();
include "config.php";

$error = "";


/* ==============================
   PROCESS LOGIN
============================== */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";


    if ($email === "" || $password === "") {

        $error = "Please enter your email and password.";

    } else {

        $stmt = $conn->prepare(
            "SELECT id, full_name, email, password, role,
                    driver_verified, status, vehicle, plate
             FROM users
             WHERE email = ?
             LIMIT 1"
        );

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $result = $stmt->get_result();

        $user = $result->fetch_assoc();

        $stmt->close();


        /* ==============================
           CHECK LOGIN
        ============================== */

        if ($user && password_verify($password, $user["password"])) {


            /* ==============================
               CREATE SESSION
            ============================== */

            $_SESSION["user_id"] = $user["id"];

            $_SESSION["full_name"] = $user["full_name"];

            $_SESSION["role"] = $user["role"];


            /* ==============================
               REDIRECT BASED ON ROLE
            ============================== */

            if ($user["role"] === "admin") {

                header("Location: admin_dashboard.php");

                exit();

            } elseif ($user["role"] === "driver") {

                header("Location: driver_dashboard.php");

                exit();

            } else {

                header("Location: dashboard.php");

                exit();

            }


        } else {

            $error = "Invalid email or password.";

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Login | TransCalltation 2.0</title>


<style>

/* ==============================
   RESET
============================== */

* {

    box-sizing: border-box;

    margin: 0;

    padding: 0;

}


/* ==============================
   BODY
============================== */

body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    font-family: Arial, sans-serif;
    color: white;
    overflow: hidden;

    background:
        linear-gradient(
            rgba(3, 8, 25, 0.68),
            rgba(3, 8, 25, 0.88)
        ),
        url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
        center center / cover no-repeat fixed;
}


/* ==============================
   ANIMATED BACKGROUND
============================== */

body::before {

    content: "";

    position: fixed;

    width: 250px;

    height: 250px;

    border-radius: 50%;

    background:

        linear-gradient(
            135deg,
            #00eaff,
            #7b2cff
        );

    filter: blur(5px);

    opacity: .3;

    top: -80px;

    left: -80px;

    animation:
        float 6s ease-in-out infinite;

}


body::after {

    content: "";

    position: fixed;

    width: 300px;

    height: 300px;

    border-radius: 50%;

    background:

        linear-gradient(
            135deg,
            #ff00cc,
            #3333ff
        );

    filter: blur(8px);

    opacity: .3;

    right: -100px;

    bottom: -100px;

    animation:
        float2 8s ease-in-out infinite;

}


/* ==============================
   LOGIN BOX
============================== */

.login-box {

    position: relative;

    z-index: 2;

    width: 100%;

    max-width: 500px;

    padding: 30px 25px;

    border-radius: 25px;

    text-align: center;


    background:

        linear-gradient(
            145deg,
            rgba(255,255,255,.28),
            rgba(255,255,255,.08)
        );


    border:

        1px solid
        rgba(255,255,255,.35);


    backdrop-filter:

        blur(20px);


    -webkit-backdrop-filter:

        blur(20px);


    box-shadow:

        0 25px 60px
        rgba(0,0,0,.35),

        inset 0 1px 2px
        rgba(255,255,255,.5);


    animation:

        boxEnter 1s ease;

}


/* ==============================
   LOGO
============================== */

.logo {

    width: 75px;

    height: 75px;

    margin: 0 auto 15px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 22px;

    font-size: 30px;


    background:

        linear-gradient(
            135deg,
            #00c6ff,
            #0072ff,
            #8e2de2
        );


    box-shadow:

        0 10px 30px
        rgba(0,0,0,.35),

        inset 0 2px 4px
        rgba(255,255,255,.5);


    animation:

        logoFloat 3s ease-in-out infinite;

}


/* ==============================
   TITLE
============================== */

h1 {

    font-size: 32px;

    font-weight: 900;

    margin-bottom: 7px;

    text-shadow:

        2px 3px 7px
        rgba(0,0,0,.45);

}


.subtitle {

    font-size: 12px;

    opacity: .75;

    margin-bottom: 25px;

}


/* ==============================
   INPUT GROUP
============================== */

.input-group {

    text-align: left;

    margin-bottom: 15px;

}


label {

    display: block;

    margin-bottom: 6px;

    font-size: 12px;

    font-weight: 900;

    letter-spacing: 1px;


    text-shadow:

        1px 2px 4px
        rgba(0,0,0,.4);

}


input {

    width: 100%;

    padding: 14px;

    border-radius: 13px;


    border:

        1px solid
        rgba(255,255,255,.35);


    outline: none;

    color: white;

    font-size: 14px;


    background:

        linear-gradient(
            135deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.08)
        );


    box-shadow:

        inset 0 2px 5px
        rgba(0,0,0,.12);


    transition: .3s;

}


input::placeholder {

    color:

        rgba(255,255,255,.7);

}


input:focus {

    border-color: white;


    box-shadow:

        0 0 18px
        rgba(255,255,255,.25),

        inset 0 2px 5px
        rgba(0,0,0,.15);


    transform:

        translateY(-2px);

}


/* ==============================
   LOGIN BUTTON
============================== */

.login-button {

    width: 100%;

    padding: 15px;

    margin-top: 5px;

    border: none;

    border-radius: 13px;

    color: white;

    font-size: 15px;

    font-weight: 900;

    letter-spacing: 1px;

    cursor: pointer;


    background:

        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );


    background-size: 200%;


    box-shadow:

        0 10px 25px
        rgba(0,0,0,.3),

        inset 0 1px 2px
        rgba(255,255,255,.5);


    text-shadow:

        2px 2px 4px
        rgba(0,0,0,.4);


    animation:

        buttonGradient 4s linear infinite;


    transition: .25s;

}


.login-button:hover {

    transform:

        translateY(-2px);

}


.login-button:active {

    transform:

        scale(.96);

}


/* ==============================
   ERROR MESSAGE
============================== */

.error {

    margin-bottom: 15px;

    padding: 12px;

    border-radius: 12px;


    background:

        rgba(255,0,70,.25);


    border:

        1px solid
        rgba(255,255,255,.25);


    color: white;

    font-weight: bold;

    font-size: 13px;


    text-shadow:

        1px 2px 4px
        rgba(0,0,0,.4);


    animation:

        errorShake .4s ease;

}


/* ==============================
   REGISTER
============================== */

.register {

    margin-top: 20px;

    font-size: 12px;

}


.register a {

    color: white;

    font-weight: 900;

    text-decoration: none;


    text-shadow:

        1px 2px 4px
        rgba(0,0,0,.4);

}


.register a:hover {

    text-decoration: underline;

}


/* ==============================
   ANIMATIONS
============================== */

@keyframes boxEnter {

    from {

        opacity: 0;

        transform:
            translateY(50px)
            scale(.9);

    }

    to {

        opacity: 1;

        transform:
            translateY(0)
            scale(1);

    }

}


@keyframes logoFloat {

    0%,100% {

        transform:
            translateY(0)
            rotate(-2deg);

    }

    50% {

        transform:
            translateY(-8px)
            rotate(2deg);

    }

}


@keyframes float {

    0%,100% {

        transform:
            translate(0,0)
            scale(1);

    }

    50% {

        transform:
            translate(70px,50px)
            scale(1.2);

    }

}


@keyframes float2 {

    0%,100% {

        transform:
            translate(0,0)
            scale(1);

    }

    50% {

        transform:
            translate(-60px,-50px)
            scale(1.15);

    }

}


@keyframes buttonGradient {

    0% {

        background-position: 0%;

    }

    100% {

        background-position: 200%;

    }

}


@keyframes errorShake {

    0%,100% {

        transform:
            translateX(0);

    }

    25% {

        transform:
            translateX(-5px);

    }

    75% {

        transform:
            translateX(5px);

    }

}


/* ==============================
   MOBILE
============================== */

@media (max-width: 480px) {

    .login-box {

        padding: 28px 18px;

        border-radius: 22px;

    }


    h1 {

        font-size: 28px;

    }

}

.error-message {

    margin-bottom: 15px;
    padding: 12px;
    border-radius: 12px;

    background: rgba(255,70,70,.20);

    border: 1px solid rgba(255,150,150,.4);

    color: white;

    font-size: 12px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);

    animation: errorShake .4s ease;
}


@keyframes errorShake {

    0%,100% {
        transform: translateX(0);
    }

    25% {
        transform: translateX(-5px);
    }

    75% {
        transform: translateX(5px);
    }

}
.password-box {
    position: relative;
    width: 100%;
    display: block;
}

.password-box input {
    display: block;
    width: 100%;
    padding-right: 55px;
}

.password-box .eye-button {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);

    width: 40px;
    height: 40px;

    margin: 0;
    padding: 0;

    border: none;
    border-radius: 8px;

    background: transparent;
    color: white;

    font-size: 18px;
    cursor: pointer;

    z-index: 10;
}
</style>


<style>
.auth-intro {
    width: 100%;
    max-width: 700px;
    text-align: center;
    margin: 0 auto 25px;
}

.auth-intro h1 {
    margin: 0 0 12px;
    font-size: 38px;
    font-weight: 800;
    letter-spacing: .5px;
    text-shadow: 0 4px 15px rgba(0,0,0,.6);
}

.auth-intro p {
    margin: 0;
    font-size: 17px;
    line-height: 1.6;
    font-weight: 500;
    text-shadow: 0 2px 8px rgba(0,0,0,.6);
}
</style>


<style>

.auth-wrapper {
    width: 100%;
    max-width: 760px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 22px;
}

.auth-intro {
    width: 100%;
    text-align: center;
    padding: 5px 20px;
    position: relative;
    z-index: 5;
}

.intro-badge {
    display: inline-block;
    margin-bottom: 12px;
    padding: 7px 18px;
    border: 1px solid rgba(255,255,255,.35);
    border-radius: 50px;
    background: rgba(255,255,255,.10);
    backdrop-filter: blur(10px);
    font-size: 13px;
    font-weight: 800;
    letter-spacing: 2px;
    color: #ffffff;
    box-shadow: 0 8px 25px rgba(0,0,0,.25);
}

.auth-intro h1 {
    margin: 0;
    font-size: 44px;
    line-height: 1.12;
    font-weight: 900;
    color: white;
    text-shadow:
        0 4px 15px rgba(0,0,0,.65),
        0 0 25px rgba(0,210,255,.25);
}

.auth-intro h1 span {
    background: linear-gradient(
        90deg,
        #00eaff,
        #ffffff,
        #b86cff,
        #ff4fd8,
        #00eaff
    );
    background-size: 250% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: introGradient 5s linear infinite;
}

.auth-intro p {
    max-width: 650px;
    margin: 15px auto 0;
    font-size: 17px;
    line-height: 1.6;
    color: rgba(255,255,255,.88);
    text-shadow: 0 2px 8px rgba(0,0,0,.7);
}

.auth-intro p strong {
    color: #ffffff;
    font-weight: 800;
}

@keyframes introGradient {
    0% {
        background-position: 0% center;
    }
    100% {
        background-position: 250% center;
    }
}

@media (max-width: 600px) {

    .auth-wrapper {
        gap: 15px;
    }

    .auth-intro h1 {
        font-size: 31px;
    }

    .auth-intro p {
        font-size: 15px;
    }

    .intro-badge {
        font-size: 11px;
        letter-spacing: 1.5px;
    }
}

</style>


<style>\n/* CENTER AUTHENTICATION AREA */
body {
    min-height: 100vh !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 20px !important;
}

.auth-wrapper {
    width: 100% !important;
    max-width: 760px !important;
    margin: 0 auto !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 18px !important;
}

.auth-intro {
    margin: 0 auto !important;
}

.login-box {
    margin: 0 auto !important;
}
</style>


<style>
.auth-wrapper {
    transform: translateY(-70px) !important;
}
</style>

</head>


<body>




<div class="auth-wrapper">

    <div class="auth-intro">
        <div class="intro-badge">✨ TRANSCALLTATION 2.0</div>

        <h1>Create Your<br>
        <span>TransCalltation Account Here! 👇</span></h1>

        <p>
            Log in or create your account to unlock a
            <strong>smarter, safer, and more convenient</strong>
            transportation experience.
        </p>
    </div>

<div class="login-box">


    <div class="logo">

        🛵

    </div>


    <h1>

        TransCalltation 2.0

    </h1>


    <p class="subtitle">

        SMART • SAFE • SIMPLE TRANSPORTATION

    </p>


    <?php if ($error !== ""): ?>

        <div class="error">

            ⚠️

            <?php echo htmlspecialchars($error); ?>

        </div>

    <?php endif; ?>

<?php if ($error): ?>

<div class="error-message">

    <?php echo htmlspecialchars($error); ?>

</div>

<?php endif; ?>

    <form action="login.php" method="POST">


        <div class="input-group">

            <label>

                EMAIL

            </label>


            <input

                type="email"

                name="email"

                placeholder="Enter your email"

                required

            >

        </div>


        <div class="input-group">

            <label>

                PASSWORD

            </label>
<div class="password-box">

    <input
        type="password"
        name="password"
        id="login_password"
        placeholder="Enter your password"
        required
    >

    <button
        type="button"
        class="eye-button"
        onclick="togglePassword('login_password', this)"
    >
        👁️
    </button>

</div>

        </div>


        <button

            type="submit"

            class="login-button">

            🔐 LOGIN

        </button>


    </form>


    <div class="register">

        Don't have an account?

        <a href="register.php">

            Create Account

        </a>

    </div>


</div>

<script>
function togglePassword(id, button) {

    const input = document.getElementById(id);

    if (input.type === "password") {
        input.type = "text";
        button.textContent = "🗝️";
    } else {
        input.type = "password";
        button.textContent = "👁️";
    }
}
</script>

</body>

</html>

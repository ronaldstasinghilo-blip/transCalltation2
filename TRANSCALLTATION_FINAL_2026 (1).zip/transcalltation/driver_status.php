<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

/* Make sure the logged-in account is a driver */
$stmt = $conn->prepare(
    "SELECT role, status
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$driver = $result->fetch_assoc();

$stmt->close();

if (!$driver || $driver["role"] !== "driver") {
    header("Location: dashboard.php");
    exit();
}

/* Change availability */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $new_status = $_POST["status"] ?? "";

    if ($new_status === "Available" || $new_status === "Unavailable") {

        $update = $conn->prepare(
            "UPDATE users
             SET status = ?
             WHERE id = ?
             AND role = 'driver'"
        );

        $update->bind_param("si", $new_status, $user_id);
        $update->execute();

        $update->close();
    }

    header("Location: driver_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Driver Availability | TransCalltation 2.0</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 20px;

            font-family: Arial, sans-serif;
            color: white;

            background:
                radial-gradient(
                    circle at 10% 10%,
                    #00e5ff,
                    transparent 30%
                ),
                radial-gradient(
                    circle at 90% 90%,
                    #e100ff,
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #071952,
                    #088395,
                    #5700b3
                );
        }

        .box {
            width: 100%;
            max-width: 500px;
            margin: 40px auto;
            padding: 25px;

            border-radius: 22px;

            background:
                linear-gradient(
                    145deg,
                    rgba(255,255,255,.25),
                    rgba(255,255,255,.08)
                );

            backdrop-filter: blur(15px);

            box-shadow:
                0 15px 35px rgba(0,0,0,.3);
        }

        h1 {
            margin-bottom: 8px;
            font-size: 24px;
        }

        p {
            opacity: .85;
        }

        .current {
            margin: 20px 0;
            padding: 18px;

            border-radius: 16px;

            background: rgba(0,0,0,.2);

            text-align: center;
            font-size: 20px;
            font-weight: bold;
        }

        button {
            width: 100%;
            padding: 15px;
            margin-top: 12px;

            border: none;
            border-radius: 14px;

            color: white;
            font-size: 15px;
            font-weight: bold;

            cursor: pointer;

            background:
                linear-gradient(
                    90deg,
                    #006eff,
                    #7b2cff,
                    #e000ff
                );
        }

        .back {
            display: block;
            margin-top: 15px;

            text-align: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="box">

    <h1>🟢 Driver Availability</h1>

    <p>
        Choose whether you are currently available
        to receive student ride requests.
    </p>

    <div class="current">
        Current Status:
        <?php echo htmlspecialchars($driver["status"]); ?>
    </div>

    <form method="POST">
        <input type="hidden" name="status" value="Available">

        <button type="submit">
            🟢 SET AS AVAILABLE
        </button>
    </form>

    <form method="POST">
        <input type="hidden" name="status" value="Unavailable">

        <button type="submit">
            🔴 SET AS UNAVAILABLE
        </button>
    </form>

    <a href="driver_dashboard.php" class="back">
        ← BACK TO DRIVER DASHBOARD
    </a>

</div>

</body>
</html>

<?php
session_start();
include "config.php";

/* Admin login required */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$admin_id = (int)$_SESSION["user_id"];

/* Verify that the logged-in account is an admin */
$stmt = $conn->prepare(
    "SELECT id, role FROM users WHERE id=? LIMIT 1"
);
$stmt->bind_param("i", $admin_id);
$stmt->execute();

$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$admin || $admin["role"] !== "admin") {
    http_response_code(403);
    exit("Access denied.");
}

/* Only POST requests are allowed */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: messages.php?inbox=all");
    exit();
}

/* Get complaint ID */
$message_id = isset($_POST["message_id"])
    ? (int)$_POST["message_id"]
    : 0;

/* Get requested status */
$status = isset($_POST["status"])
    ? trim($_POST["status"])
    : "";

/* Allowed complaint statuses */
$allowed_statuses = [
    "Open",
    "In Progress",
    "Resolved"
];

if ($message_id <= 0 || !in_array($status, $allowed_statuses, true)) {
    header("Location: messages.php?inbox=all");
    exit();
}

/*
 * Only update actual complaints.
 * Admin cannot modify ordinary messages through this page.
 */
$stmt = $conn->prepare(
    "UPDATE messages
     SET complaint_status=?
     WHERE id=?
     AND message_type='complaint'"
);

$stmt->bind_param(
    "si",
    $status,
    $message_id
);

$stmt->execute();
$stmt->close();

/* Return to Admin inbox */
header("Location: messages.php?inbox=all");
exit();
?>

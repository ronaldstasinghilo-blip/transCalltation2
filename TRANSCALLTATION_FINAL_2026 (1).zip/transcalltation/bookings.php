<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION["user_id"];

$stmt = $conn->prepare("
    SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,
        u.full_name AS driver_name
    FROM bookings b
    LEFT JOIN users u ON b.driver_id = u.id
    WHERE b.student_id = ?
    ORDER BY b.created_at DESC
");

$stmt->bind_param("i", $student_id);
$stmt->execute();

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Bookings - TransCalltation 2.0</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background:
                linear-gradient(
                    135deg,
                    #071952,
                    #0b5ed7,
                    #4b20c9
                );
            min-height: 100vh;
            padding: 20px;
            color: white;
        }

        .container {
            width: 100%;
            max-width: 800px;
            margin: auto;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 900;
        }

        .header p {
            margin-top: 8px;
            opacity: .9;
        }

        .booking {
            background: rgba(255,255,255,.96);
            color: #222;
            border-radius: 18px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 12px 30px rgba(0,0,0,.3);
        }

        .booking h2 {
            margin: 0 0 15px;
            color: #3a5bff;
            font-size: 20px;
        }

        .booking p {
            margin: 8px 0;
            font-size: 15px;
        }

        .status {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 14px;
            border-radius: 20px;
            background: #e8edff;
            color: #3a5bff;
            font-weight: 900;
        }

        .back {
            display: block;
            text-align: center;
            text-decoration: none;
            color: white;
            background: linear-gradient(90deg,#006eff,#7b2cff);
            padding: 14px;
            border-radius: 12px;
            font-weight: 900;
            margin-top: 20px;
        }

        .empty {
            background: rgba(255,255,255,.96);
            color: #333;
            padding: 30px 20px;
            border-radius: 18px;
            text-align: center;
            font-weight: bold;
        }

          /* =====================================================
             GLOSSY RED CANCEL RIDE BUTTON
          ===================================================== */

          .cancel-ride-form {
              margin-top: 15px;
              width: 100%;
          }

          .cancel-ride-btn {
              position: relative;
              display: flex;
              align-items: center;
              justify-content: center;
              width: 100%;
              min-height: 56px;
              padding: 15px 20px;
              border: 1px solid rgba(255,255,255,.65);
              border-radius: 18px;
              color: #ffffff;
              background: linear-gradient(145deg,#ff6b6b,#e60000 45%,#8b0000);
              font-size: 16px;
              font-weight: 900;
              letter-spacing: .8px;
              cursor: pointer;
              box-shadow: 0 8px 18px rgba(0,0,0,.35),0 0 16px rgba(255,0,0,.65),0 0 35px rgba(255,0,0,.40);
              overflow: hidden;
              transition: transform .2s ease, box-shadow .2s ease;
          }

          .cancel-ride-btn::before {
              content: "";
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 48%;
              background: linear-gradient(to bottom,rgba(255,255,255,.50),rgba(255,255,255,0));
              pointer-events: none;
          }

          .cancel-ride-btn::after {
              content: "";
              position: absolute;
              top: -60%;
              left: -80%;
              width: 42%;
              height: 220%;
              background: linear-gradient(90deg,transparent,rgba(255,255,255,.55),transparent);
              transform: rotate(25deg);
              animation: cancelButtonShine 3s infinite;
          }

          .cancel-ride-btn:hover {
              transform: translateY(-2px);
              box-shadow: 0 11px 24px rgba(0,0,0,.40),0 0 24px rgba(255,0,0,.85),0 0 48px rgba(255,0,0,.55);
          }

          .cancel-ride-btn:active {
              transform: scale(.96);
          }

          @keyframes cancelButtonShine {
              0% { left: -80%; }
              45%,100% { left: 140%; }
          }
    </style>
</head>

<body>

<div class="container">

    <div class="header">
        <h1>📋 My Bookings</h1>
        <p>TransCalltation 2.0</p>
    </div>

    <?php if ($result->num_rows > 0): ?>

        <?php while ($booking = $result->fetch_assoc()): ?>

            <div class="booking">

                <h2>
                    🚕 Booking #<?php echo htmlspecialchars($booking["id"]); ?>
                </h2>

                <p>
                    📍 <strong>Pickup:</strong>
                    <?php echo htmlspecialchars($booking["pickup"]); ?>
                </p>

                <p>
                    🏁 <strong>Drop-off:</strong>
                    <?php echo htmlspecialchars($booking["dropoff"]); ?>
                </p>

                <p>
                    🛵 <strong>Driver:</strong>
                    <?php
                    echo htmlspecialchars(
                        $booking["driver_name"] ?? "Not assigned"
                    );
                    ?>
                </p>

                <p>
                    📅 <strong>Date:</strong>
                    <?php echo htmlspecialchars($booking["created_at"]); ?>
                </p>

                <div class="status">
                    📊 <?php echo htmlspecialchars($booking["status"]); ?>
                </div>

                  <?php if (strcasecmp(trim($booking["status"]), "Pending") === 0): ?>
                      <form method="POST" action="cancel_ride.php" class="cancel-ride-form" onsubmit="return confirm('Are you sure you want to cancel this ride?');">
                          <input type="hidden" name="booking_id" value="<?php echo (int) $booking["id"]; ?>">
                          <button type="submit" class="cancel-ride-btn">
                              🚫 CANCEL RIDE
                          </button>
                      </form>
                  <?php endif; ?>

            </div>

        <?php endwhile; ?>

    <?php else: ?>

        <div class="empty">
            📋 You don't have any bookings yet.
        </div>

    <?php endif; ?>

    <a href="dashboard.php" class="back">
        ← BACK TO DASHBOARD
    </a>

</div>

</body>
</html>

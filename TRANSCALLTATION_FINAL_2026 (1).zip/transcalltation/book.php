<?php

session_start();

include "config.php";

/*
|--------------------------------------------------------------------------
| STEP 1 — Check if student is logged in
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");
    exit();

}

$student_id = $_SESSION["user_id"];


/*
|--------------------------------------------------------------------------
| STEP 2 — Only process POST requests
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header("Location: dashboard.php");
    exit();

}


/*
|--------------------------------------------------------------------------
| STEP 3 — Get submitted booking information
|--------------------------------------------------------------------------
*/

$driver_id = intval($_POST["driver_id"] ?? 0);

$pickup = trim($_POST["pickup"] ?? "");

$dropoff = trim($_POST["dropoff"] ?? "");
$pickup_latitude = $_POST["pickup_latitude"] ?? "";
$pickup_longitude = $_POST["pickup_longitude"] ?? "";



/*
|--------------------------------------------------------------------------
| STEP 4 — Validate the information
|--------------------------------------------------------------------------
*/

if ($driver_id <= 0 || $pickup === "" || $dropoff === "") {

    die("
        <div style='
            font-family:Arial;
            text-align:center;
            padding:40px;
        '>

            <h2>⚠️ Invalid Booking</h2>

            <p>
                Please provide a driver, pickup location,
                and drop-off location.
            </p>

            <a href='dashboard.php'>
                ← Back to Dashboard
            </a>

        </div>
    ");

}


/*
|--------------------------------------------------------------------------
| STEP 5 — Check that the selected driver exists,
|          is verified, and is available
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare(
    "SELECT id, full_name, driver_verified, status
     FROM users
     WHERE id = ?
     AND role = 'driver'
     LIMIT 1"
);

$stmt->bind_param("i", $driver_id);

$stmt->execute();

$result = $stmt->get_result();

$driver = $result->fetch_assoc();

$stmt->close();


if (!$driver) {

    die("
        <div style='
            font-family:Arial;
            text-align:center;
            padding:40px;
        '>

            <h2>❌ Driver Not Found</h2>

            <p>
                The selected driver does not exist.
            </p>

            <a href='dashboard.php'>
                ← Back to Dashboard
            </a>

        </div>
    ");

}


/*
|--------------------------------------------------------------------------
| STEP 6 — Make sure driver is verified
|--------------------------------------------------------------------------
*/

if ((int)$driver["driver_verified"] !== 1) {

    die("
        <div style='
            font-family:Arial;
            text-align:center;
            padding:40px;
        '>

            <h2>🛡️ Driver Not Verified</h2>

            <p>
                You can only request a ride from a
                verified driver.
            </p>

            <a href='dashboard.php'>
                ← Back to Dashboard
            </a>

        </div>
    ");

}


/*
|--------------------------------------------------------------------------
| STEP 7 — Make sure driver is available
|--------------------------------------------------------------------------
*/

if ($driver["status"] !== "Available") {

    die("
        <div style='
            font-family:Arial;
            text-align:center;
            padding:40px;
        '>

            <h2>🔴 Driver Unavailable</h2>

            <p>
                This driver is currently unavailable.
                Please choose another driver.
            </p>

            <a href='dashboard.php'>
                ← Back to Dashboard
            </a>

        </div>
    ");

}


/*
|--------------------------------------------------------------------------
| STEP 8 — Insert booking into database
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare(
    "INSERT INTO bookings
        (student_id, driver_id, pickup, dropoff, status, pickup_latitude, pickup_longitude)
     VALUES
        (?, ?, ?, ?, 'Pending', ?, ?)"
);

$stmt->bind_param(
    "iissss",
    $student_id,
    $driver_id,
    $pickup,
    $dropoff,
    $pickup_latitude,
    $pickup_longitude
);


if ($stmt->execute()) {

    $stmt->close();

    /*
    |--------------------------------------------------------------
    | Booking successful
    |--------------------------------------------------------------
    */

    require_once __DIR__ . "/send_push_notification.php";

      sendPushNotification(
          $driver_id,
          "🏍️ New Ride Request",
          "You have received a new ride request from a student."
      );

      header("Location: dashboard.php?booking=success");
    exit();

}


/*
|--------------------------------------------------------------------------
| STEP 9 — Booking failed
|--------------------------------------------------------------------------
*/

$error = $stmt->error;

$stmt->close();

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    Booking Error | TransCalltation 2.0
</title>

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    min-height: 100vh;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 20px;

    font-family: Arial, sans-serif;

    color: white;

    background:

        radial-gradient(
            circle at 10% 10%,
            #00e5ff,
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 90%,
            #e100ff,
            transparent 35%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

}

.error-box {

    width: 100%;

    max-width: 420px;

    padding: 30px;

    text-align: center;

    border-radius: 25px;

    background:

        linear-gradient(
            145deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.08)
        );

    border:

        1px solid
        rgba(255,255,255,.3);

    backdrop-filter: blur(20px);

    box-shadow:

        0 25px 60px
        rgba(0,0,0,.4);

}

.error-box h1 {

    font-size: 24px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.4);

}

.error-box p {

    font-size: 13px;

    opacity: .85;

    margin-bottom: 20px;

}

.back-button {

    display: inline-block;

    padding: 13px 20px;

    border-radius: 12px;

    color: white;

    text-decoration: none;

    font-weight: 900;

    background:

        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    box-shadow:

        0 8px 20px
        rgba(0,0,0,.3);

}

</style>

</head>

<body>

<div class="error-box">

    <h1>
        ❌ Booking Failed
    </h1>

    <p>
        Sorry, your ride request could not be saved.
    </p>

    <a
        href="dashboard.php"
        class="back-button">

        ← BACK TO DASHBOARD

    </a>

</div>

</body>

</html>
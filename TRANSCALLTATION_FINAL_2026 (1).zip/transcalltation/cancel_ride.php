<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = (int) $_SESSION["user_id"];

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: dashboard.php");
    exit();
}

$booking_id = isset($_POST["booking_id"])
    ? (int) $_POST["booking_id"]
    : 0;

if ($booking_id <= 0) {
    header("Location: dashboard.php");
    exit();
}

/*
 * Students can cancel ONLY their own PENDING booking.
 */
$stmt = $conn->prepare(
    "UPDATE bookings
     SET status = 'Cancelled'
     WHERE id = ?
       AND student_id = ?
       AND LOWER(status) = 'pending'"
);

$stmt->bind_param("ii", $booking_id, $user_id);
$stmt->execute();

$stmt->close();

header("Location: dashboard.php");
exit();
?>

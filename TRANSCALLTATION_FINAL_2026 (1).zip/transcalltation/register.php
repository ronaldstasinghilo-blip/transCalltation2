<?php

session_start();

include "config.php";

$error = "";
$success = "";

/* Process registration */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $full_name = trim($_POST["full_name"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    error_log("PHONE RECEIVED: [" . ($_POST["phone"] ?? "NOT SET") . "]");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $role = $_POST["role"] ?? "student";

    $vehicle = trim($_POST["vehicle"] ?? "");
    $plate = trim($_POST["plate"] ?? "");


    /* Validate */

    if ($full_name === "" || $email === "" || $password === "") {

        $error = "Please complete all required fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } elseif (strlen($password) < 6) {

        $error = "Password must be at least 6 characters.";

    } elseif (!in_array($role, ["student", "driver"])) {

        $error = "Invalid account type.";

    } else {


        /* Check if email already exists */

        $check = $conn->prepare(
            "SELECT id FROM users WHERE email = ? LIMIT 1"
        );

        $check->bind_param("s", $email);

        $check->execute();

        $checkResult = $check->get_result();


        if ($checkResult->num_rows > 0) {

            $error = "This email is already registered.";

        } else {


            /* Secure password */

            $hashed_password =
                password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


            /* Driver starts unverified */

            $driver_verified =
                ($role === "driver") ? 0 : 1;


            /* Insert user */

            $stmt = $conn->prepare(
                "INSERT INTO users
                (
                    full_name,
                    email,
                    phone,
                    password,
                    role,
                    status,
                    vehicle,
                    plate,
                    driver_verified
                )
                VALUES (?, ?, ?, ?, ?, 'Available', ?, ?, ?)"
            );


            $stmt->bind_param(
                "sssssssi",
                $full_name,
                $email,
                $phone,
                $hashed_password,
                $role,
                $vehicle,
                $plate,
                $driver_verified
            );


            if ($stmt->execute()) {

                $success =
                    "Account created successfully! You can now login.";

            } else {

                $error =
                    "Registration failed. Please try again.";

            }


            $stmt->close();

        }


        $check->close();

    }

}

?><!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
    Register | TransCalltation 2.0
</title><style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    font-family: Arial, sans-serif;
    color: white;
    overflow: hidden;

    background:
        linear-gradient(
            rgba(3, 8, 25, 0.68),
            rgba(3, 8, 25, 0.88)
        ),
        url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
        center center / cover no-repeat fixed;
}

.register-box {

    width: 100%;

    max-width: 430px;

    padding: 30px 25px;

    border-radius: 25px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.28),
            rgba(255,255,255,.08)
        );

    border:
        1px solid
        rgba(255,255,255,.35);

    backdrop-filter: blur(20px);

    -webkit-backdrop-filter: blur(20px);

    box-shadow:
        0 25px 60px
        rgba(0,0,0,.35),

        inset 0 1px 3px
        rgba(255,255,255,.5);

    animation: boxEnter 1s ease;
}

.logo {

    width: 70px;

    height: 70px;

    margin: 0 auto 15px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 20px;

    font-size: 30px;

    background:
        linear-gradient(
            135deg,
            #00c6ff,
            #0072ff,
            #8e2de2
        );

    box-shadow:
        0 10px 30px
        rgba(0,0,0,.35);

    animation: logoFloat 3s ease-in-out infinite;
}

h1 {

    text-align: center;

    font-size: 28px;

    font-weight: 900;

    text-shadow:
        2px 3px 7px
        rgba(0,0,0,.45);
}

.subtitle {

    text-align: center;

    font-size: 12px;

    margin: 8px 0 20px;

    opacity: .8;
}

label {

    display: block;

    margin: 12px 0 6px;

    font-size: 12px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}

input,
select {

    width: 100%;

    padding: 14px;

    border-radius: 13px;

    border:
        1px solid
        rgba(255,255,255,.35);

    outline: none;

    color: white;

    font-size: 14px;

    background:
        linear-gradient(
            135deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.08)
        );
}

select option {

    color: #222;

    background: white;
}

button {

    width: 100%;

    padding: 14px;

    margin-top: 20px;

    border: none;

    border-radius: 13px;

    color: white;

    font-size: 14px;

    font-weight: 900;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    background-size: 200%;

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.3);

    animation:
        buttonGradient 4s linear infinite;
}

.message {

    padding: 10px;

    margin-bottom: 15px;

    border-radius: 10px;

    text-align: center;

    font-size: 13px;

    font-weight: bold;

    background:
        rgba(255,255,255,.15);
}

.error {

    background:
        rgba(255,0,60,.25);
}

.success {

    background:
        rgba(0,255,120,.25);
}

.login {

    text-align: center;

    margin-top: 18px;

    font-size: 12px;
}

.login a {

    color: white;

    font-weight: 900;

    text-decoration: none;
}

#driverFields {

    display: none;
}

@keyframes boxEnter {

    from {
        opacity: 0;
        transform:
            translateY(40px)
            scale(.9);
    }

    to {
        opacity: 1;
        transform:
            translateY(0)
            scale(1);
    }
}

@keyframes logoFloat {

    0%,100% {
        transform: translateY(0);
    }

    50% {
        transform: translateY(-8px);
    }
}

@keyframes buttonGradient {

    0% {
        background-position: 0%;
    }

    100% {
        background-position: 200%;
    }
}

@keyframes backgroundMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

</style>
<style>
.auth-intro {
    width: 100%;
    max-width: 700px;
    text-align: center;
    margin: 0 auto 25px;
}

.auth-intro h1 {
    margin: 0 0 12px;
    font-size: 38px;
    font-weight: 800;
    letter-spacing: .5px;
    text-shadow: 0 4px 15px rgba(0,0,0,.6);
}

.auth-intro p {
    margin: 0;
    font-size: 17px;
    line-height: 1.6;
    font-weight: 500;
    text-shadow: 0 2px 8px rgba(0,0,0,.6);
}
</style>


<style>/* REGISTER AUTH DESIGN */
body {
    min-height: 100vh !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 20px !important;
}

.auth-wrapper {
    width: 100% !important;
    max-width: 900px !important;
    margin: 0 auto !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 18px !important;
    transform: translateY(-70px) !important;
}

.auth-intro {
    width: 100%;
    text-align: center;
    padding: 5px 20px;
    position: relative;
    z-index: 5;
}

.intro-badge {
    display: inline-block;
    margin-bottom: 12px;
    padding: 7px 18px;
    border: 1px solid rgba(255,255,255,.35);
    border-radius: 50px;
    background: rgba(255,255,255,.10);
    backdrop-filter: blur(10px);
    font-size: 13px;
    font-weight: 800;
    letter-spacing: 2px;
    color: #fff;
    box-shadow: 0 8px 25px rgba(0,0,0,.25);
}

.auth-intro h1 {
    margin: 0;
    font-size: 44px;
    line-height: 1.12;
    font-weight: 900;
    color: white;
    text-shadow: 0 4px 15px rgba(0,0,0,.65);
}

.auth-intro h1 span {
    background: linear-gradient(
        90deg,
        #00eaff,
        #ffffff,
        #b86cff,
        #ff4fd8,
        #00eaff
    );
    background-size: 250% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: introGradient 5s linear infinite;
}

.auth-intro p {
    max-width: 650px;
    margin: 15px auto 0;
    font-size: 17px;
    line-height: 1.6;
    color: rgba(255,255,255,.88);
    text-shadow: 0 2px 8px rgba(0,0,0,.7);
}

.auth-intro p strong {
    color: #fff;
    font-weight: 800;
}

@keyframes introGradient {
    0% { background-position: 0% center; }
    100% { background-position: 250% center; }
}

.register-box {
    margin: 0 auto !important;
}

@media (max-width: 600px) {
    .auth-intro h1 {
        font-size: 31px;
    }

    .auth-intro p {
        font-size: 15px;
    }
}
</style>
</head><body><div class="auth-wrapper">

    <div class="auth-intro">
        <div class="intro-badge">✨ TRANSCALLTATION 2.0</div>

        <h1>Create Your<br>
        <span>TransCalltation Account Here! 👇</span></h1>

        <p>
            Log in or create your account to unlock a
            <strong>smarter, safer, and more convenient</strong>
            transportation experience.
        </p>
    </div>

<div class="register-box"><div class="logo">
    🛵
</div>

<h1>
    Create Account
</h1>

<p class="subtitle">
    JOIN TRANSCALLTATION 2.0
</p>


<?php if ($error !== ""): ?>

    <div class="message error">

        ⚠️
        <?php echo htmlspecialchars($error); ?>

    </div>

<?php endif; ?>


<?php if ($success !== ""): ?>

    <div class="message success">

        ✅
        <?php echo htmlspecialchars($success); ?>

    </div>

<?php endif; ?>


<form enctype="multipart/form-data"
    action="register.php"
    method="POST">


    <label>
        FULL NAME
    </label>

    <input
        type="text"
        name="full_name"
        placeholder="Enter your full name"
        required
    >


      <label>
          PHONE NUMBER
      </label>

      <input
          type="tel"
          name="phone"
          placeholder="Enter your phone number"
          maxlength="20"
          required
      >

    <label>
        EMAIL
    </label>

    <input
        type="email"
        name="email"
        placeholder="Enter your email"
        required
    >


    <label>
        PASSWORD
    </label>

    <input
        type="password"
        name="password"
        placeholder="Create a password"
        minlength="6"
        required
    >


    <label>
        ACCOUNT TYPE
    </label>

    <select
        name="role"
        id="role"
        onchange="handleAccountType()">

        <option value="student">
            👨‍🎓 Student
        </option>

        <option value="driver">
            🛵 Driver
        </option>

    </select>


    <div id="driverFields">

        <div class="driver-checklist">
            <h3>🏍️ DRIVER REQUIREMENTS</h3>
            <p class="driver-note">
                Please complete all requirements before creating your driver account.
            </p>

            <label>VEHICLE</label>
            <input
                type="text"
                name="vehicle"
                placeholder="Example: Honda Click"
            >

            <label>PLATE NUMBER</label>
            <input
                type="text"
                name="plate"
                placeholder="Example: ABC-1234"
            >

            <label>DRIVER'S LICENSE PHOTO</label>
            <input
                type="file"
                name="driver_license_photo"
                accept="image/*"
                capture="environment"
            >

            <label>GOVERNMENT ID PHOTO</label>
            <input
                type="file"
                name="government_id_photo"
                accept="image/*"
                capture="environment"
            >

            <label>DRIVER PROFILE PHOTO</label>
            <input
                type="file"
                name="profile_photo"
                accept="image/*"
                capture="user"
            >

            <label>VEHICLE PHOTO</label>
            <p class="driver-note">
                📸 Make sure the vehicle's license plate is clearly visible.
            </p>
            <input
                type="file"
                name="vehicle_photo"
                accept="image/*"
                capture="environment"
            >

            <div class="requirement-warning">
                ⚠️ All driver requirements are required.
            </div>
        </div>

    </div>


    <button type="submit">

        🚀 CREATE ACCOUNT

    </button>

</form>


<div class="login">

    Already have an account?

    <a href="login.php">
        Login
    </a>

</div>

</div><script>

function toggleDriverFields() {

    const role =
        document.getElementById("role").value;

    const fields =
        document.getElementById("driverFields");

    if (role === "driver") {

        fields.style.display = "block";

    } else {

        fields.style.display = "none";

    }

}

</script>
<script>
function handleAccountType() {
    const role = document.getElementById("role").value;

    if (role === "driver") {
        window.location.href = "driver_registration.php";
    }
}
</script>

</body></html>
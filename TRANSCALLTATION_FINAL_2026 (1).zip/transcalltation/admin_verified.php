<?php

session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT id, full_name, email, role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$stmt->close();

if (!$admin || strtolower($admin["role"]) !== "admin") {
    header("Location: dashboard.php");
    exit();
}

$verified_drivers = [];

$result = $conn->query(
    "SELECT id, full_name, email, vehicle, plate, status
     FROM users
     WHERE role = 'driver'
     AND driver_verified = 1
     ORDER BY id DESC"
);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $verified_drivers[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Verified Drivers | TransCalltation</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    min-height: 100vh;
    padding: 15px;
    font-family: Arial, sans-serif;
    color: white;

    background:
        radial-gradient(circle at 10% 10%, #00e5ff, transparent 30%),
        radial-gradient(circle at 90% 90%, #e100ff, transparent 35%),
        linear-gradient(135deg, #071952, #088395, #5700b3);
}

.container {
    width: 100%;
    max-width: 900px;
    margin: auto;
}

.header,
.driver-card {
    border-radius: 20px;
    background: rgba(255,255,255,.13);
    border: 1px solid rgba(255,255,255,.25);
    box-shadow: 0 12px 30px rgba(0,0,0,.25);
}

.header {
    padding: 20px;
    margin-bottom: 18px;
}

.header h1 {
    font-size: 22px;
    margin-bottom: 5px;
}

.header p {
    font-size: 12px;
    opacity: .8;
}

.back {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 14px;
    border-radius: 10px;
    color: white;
    text-decoration: none;
    background: rgba(0,0,0,.25);
    font-weight: bold;
}

.driver-card {
    padding: 18px;
    margin-bottom: 12px;
}

.name {
    font-size: 17px;
    font-weight: bold;
    margin-bottom: 8px;
}

.info {
    font-size: 12px;
    line-height: 1.8;
}

.verified {
    display: inline-block;
    margin-top: 10px;
    padding: 7px 12px;
    border-radius: 20px;
    background: rgba(0,255,120,.18);
    color: #7cffb2;
    font-size: 11px;
    font-weight: bold;
}

.empty {
    padding: 30px;
    text-align: center;
    border-radius: 20px;
    background: rgba(255,255,255,.1);
}

</style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>🛡️ Verified Drivers</h1>

        <p>
            Complete list of drivers verified by the administrator.
        </p>

        <a href="admin_dashboard.php" class="back">
            ← Back to Dashboard
        </a>

    </div>

    <?php if (count($verified_drivers) > 0): ?>

        <?php foreach ($verified_drivers as $driver): ?>

            <div class="driver-card">

                <div class="name">
                    👤
                    <?php echo htmlspecialchars($driver["full_name"]); ?>
                </div>

                <div class="info">

                    📧
                    <?php echo htmlspecialchars($driver["email"]); ?>

                    <br>

                    🛵 Vehicle:
                    <?php echo htmlspecialchars($driver["vehicle"]); ?>

                    <br>

                    🔢 Plate:
                    <?php echo htmlspecialchars($driver["plate"]); ?>

                    <br>

                    🟢 Status:
                    <?php echo htmlspecialchars($driver["status"]); ?>

                </div>

                <span class="verified">
                    ✅ VERIFIED DRIVER
                </span>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">
            🛡️
            <br><br>
            No verified drivers yet.
        </div>

    <?php endif; ?>

</div>

</body>

</html>

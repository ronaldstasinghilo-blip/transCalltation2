<?php

session_start();

include "config.php";
include "languages.php";


/* Protect dashboard */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];


/* Get logged-in user */

$stmt = $conn->prepare(
    "SELECT id, full_name, role, driver_verified, status, vehicle, plate, appearance
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();
$appearance = $user["appearance"] ?? "Gradient";

$stmt->close();


if (!$user) {

    session_destroy();

    header("Location: login.php");
    exit();
}

/* Get available verified drivers */

$drivers = [];

$driverQuery = $conn->query(
    "SELECT id, full_name, vehicle, plate, status
     FROM users
     WHERE role = 'driver'
     AND driver_verified = 1
     AND status = 'Available'
     ORDER BY full_name ASC"
);

if ($driverQuery) {

    while ($driver = $driverQuery->fetch_assoc()) {
        $drivers[] = $driver;
    }

}


/* Get student's bookings */

$bookings = [];

$bookingStmt = $conn->prepare(
    "SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,
        u.full_name AS driver_name,
        u.vehicle,
        u.plate
     FROM bookings b
     LEFT JOIN users u
        ON b.driver_id = u.id
     WHERE b.student_id = ?
     ORDER BY b.id DESC"
);

$bookingStmt->bind_param("i", $user_id);
$bookingStmt->execute();

$bookingResult = $bookingStmt->get_result();

while ($booking = $bookingResult->fetch_assoc()) {
    $bookings[] = $booking;
}

$bookingStmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    Student Dashboard | TransCalltation 2.0
</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    font-family: Arial, Helvetica, sans-serif;

    color: white;

    padding: 15px;

    background:
        radial-gradient(
            circle at 5% 5%,
            #00e5ff,
            transparent 28%
        ),

        radial-gradient(
            circle at 95% 95%,
            #e100ff,
            transparent 30%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

    background-size: 200% 200%;

    animation: backgroundMove 12s ease infinite;
}


/* Main */

.dashboard {

    width: 100%;

    max-width: 1000px;

    margin: auto;

    animation: pageEnter .8s ease;
}


/* Header */

.header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding: 18px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.85),
            rgba(142,45,226,.85)
        );

    border:
        1px solid
        rgba(255,255,255,.3);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.3),

        inset 0 1px 3px
        rgba(255,255,255,.5);
}

.brand {

    display: flex;

    align-items: center;

    gap: 12px;
}

.brand-icon {

    width: 52px;

    height: 52px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 15px;

    font-size: 25px;

    background:
        rgba(255,255,255,.2);

    box-shadow:
        inset 0 1px 3px
        rgba(255,255,255,.5);
}

.brand h1 {

    font-size: 20px;

    font-weight: 900;

    text-shadow:
        2px 3px 5px
        rgba(0,0,0,.4);
}

.brand p {

    font-size: 11px;

    opacity: .8;

    margin-top: 3px;
}


/* Logout */

.logout {

    padding: 10px 15px;

    border: none;

    border-radius: 12px;

    color: white;

    text-decoration: none;

    font-size: 12px;

    font-weight: 900;

    background:
        rgba(0,0,0,.25);

    box-shadow:
        0 5px 15px
        rgba(0,0,0,.2);

    transition: .25s;
}

.logout:hover {

    background:
        rgba(255,255,255,.2);

    transform: translateY(-2px);
}


/* Welcome */

.welcome {

    padding: 25px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.08)
        );

    border:
        1px solid
        rgba(255,255,255,.3);

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.welcome h2 {

    font-size: 26px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.45);
}

.welcome p {

    margin-top: 6px;

    font-size: 13px;

    opacity: .85;
}


/* Stats */

.stats {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 12px;

    margin-bottom: 20px;
}

.stat {

    padding: 18px;

    text-align: center;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);

    transition: .3s;
}

.stat:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 15px 30px
        rgba(0,0,0,.3);
}

.stat-icon {

    font-size: 25px;

    margin-bottom: 7px;
}

.stat-number {

    font-size: 22px;

    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}

.stat-label {

    font-size: 10px;

    opacity: .75;

    margin-top: 3px;
}


/* Section */

.section {

    padding: 20px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.28);

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.section-title {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 15px;
}

.section-title h3 {

    font-size: 18px;

    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}


/* Driver grid */

.driver-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 14px;
}


/* Driver card */

.driver-card {

    padding: 18px;

    border-radius: 18px;

    background:
        linear-gradient(
            135deg,
            rgba(0,198,255,.25),
            rgba(123,44,255,.18)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,.2);

    transition: .3s;

    animation: cardEnter .6s ease;
}

.driver-card:hover {

    transform:
        translateY(-5px)
        scale(1.01);
}

.driver-top {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 12px;
}

.driver-icon {

    width: 48px;

    height: 48px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 15px;

    font-size: 23px;

    background:
        linear-gradient(
            135deg,
            #00c6ff,
            #7b2cff
        );

    box-shadow:
        0 7px 15px
        rgba(0,0,0,.3);
}

.driver-name {

    font-size: 15px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}

.available {

    display: inline-block;

    margin-top: 4px;

    font-size: 10px;

    font-weight: 900;

    color: #7cffb2;
}

.driver-info {

    font-size: 12px;

    line-height: 1.8;

    opacity: .9;

    margin-bottom: 12px;
}


/* Request button */

.request-btn {

    width: 100%;

    padding: 12px;

    border: none;

    border-radius: 12px;

    color: white;

    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    background-size: 200%;

    box-shadow:
        0 8px 18px
        rgba(0,0,0,.25);

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);

    animation:
        buttonGradient 4s linear infinite;

    transition: .25s;
}

.request-btn:active {

    transform:
        scale(.95);
}


/* Booking */

.booking {

    padding: 15px;

    margin-bottom: 10px;

    border-radius: 15px;

    background:
        rgba(255,255,255,.1);

    border:
        1px solid
        rgba(255,255,255,.18);
}

.booking strong {

    font-size: 14px;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}

.route {

    margin: 8px 0;

    font-size: 13px;

    line-height: 1.7;
}

.status {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 900;

    background:
        rgba(0,0,0,.2);
}


/* Empty */

.empty {

    padding: 25px;

    text-align: center;

    opacity: .75;

    font-size: 13px;
}


/* Modal */

.modal {

    position: fixed;

    inset: 0;

    display: none;

    align-items: center;

    justify-content: center;

    padding: 20px;

    background:
        rgba(0,0,0,.65);

    z-index: 100;
}

.modal.active {

    display: flex;
}

.modal-box {

    width: 100%;

    max-width: 420px;

    padding: 25px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            #ffffff,
            #e9edff
        );

    color: #222;

    box-shadow:
        0 25px 60px
        rgba(0,0,0,.45);

    animation:
        modalEnter .3s ease;
}

.modal-box h2 {

    color: #3a5bff;

    margin-bottom: 5px;

    font-weight: 900;
}

.modal-box p {

    font-size: 12px;

    margin-bottom: 15px;
}

.modal-box label {

    display: block;

    font-size: 11px;

    font-weight: 900;

    margin: 12px 0 5px;
}

.modal-box input {

    width: 100%;

    padding: 13px;

    border: 1px solid #ccd2e0;

    border-radius: 10px;

    outline: none;

    font-size: 13px;
}

.confirm {

    width: 100%;

    padding: 13px;

    margin-top: 15px;

    border: none;

    border-radius: 11px;

    color: white;

    font-weight: 900;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff
        );
}

.cancel {

    width: 100%;

    padding: 11px;

    margin-top: 8px;

    border: none;

    border-radius: 11px;

    color: #333;

    font-weight: bold;

    background: #ddd;
}


/* Animations */

@keyframes backgroundMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

@keyframes pageEnter {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes cardEnter {

    from {
        opacity: 0;
        transform: translateY(20px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes modalEnter {

    from {
        opacity: 0;
        transform: scale(.9);
    }

    to {
        opacity: 1;
        transform: scale(1);
    }
}

@keyframes buttonGradient {

    0% {
        background-position: 0%;
    }

    100% {
        background-position: 200%;
    }
}


/* Mobile */

@media (max-width: 650px) {

    body {
        padding: 10px;
    }

    .header {
        padding: 14px;
    }

    .brand h1 {
        font-size: 16px;
    }

    .stats {
        grid-template-columns:
            repeat(3, 1fr);
    }

    .stat {
        padding: 13px 5px;
    }

    .stat-number {
        font-size: 18px;
    }

    .driver-grid {
        grid-template-columns: 1fr;
    }

}

.settings-btn {
    padding: 10px 15px;
    min-height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    font-size: 12px;
    font-weight: 900;
    background: linear-gradient(135deg, #006eff, #7b2cff);
    border: 1px solid rgba(255,255,255,.3);
    box-shadow: 0 5px 15px rgba(0,0,0,.2), inset 0 1px 3px rgba(255,255,255,.35);
    transition: .25s;
}
.settings-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,.3);
}

/* USER APPEARANCE */
body.appearance-light {
    background: #f2f5fa !important;
    color: #222 !important;
    animation: none !important;
}

body.appearance-dark {
    background: #111827 !important;
    color: #ffffff !important;
    animation: none !important;
}

body.appearance-gradient {
    background: radial-gradient(circle at 5% 5%, #00e5ff, transparent 28%), radial-gradient(circle at 95% 95%, #e100ff, transparent 30%), linear-gradient(135deg, #071952, #088395, #5700b3) !important;
    background-size: 200% 200% !important;
    animation: backgroundMove 12s ease infinite !important;
}

body.appearance-light .header,
body.appearance-light .welcome,
body.appearance-light .section,
body.appearance-light .stat,
body.appearance-light .driver-card,
body.appearance-light .booking {
    background: #ffffff !important;
    color: #222 !important;
}

body.appearance-dark .header,
body.appearance-dark .welcome,
body.appearance-dark .section,
body.appearance-dark .stat,
body.appearance-dark .driver-card,
body.appearance-dark .booking {
    background: #1f2937 !important;
    color: #ffffff !important;
}

/* FINAL STUDENT APPEARANCE OVERRIDE */
body.appearance-light {
    background: #f4f6f9 !important;
    color: #222 !important;
    animation: none !important;
}
body.appearance-light .header,
body.appearance-light .welcome,
body.appearance-light .section,
body.appearance-light .stat,
body.appearance-light .driver-card,
body.appearance-light .booking {
    background: #ffffff !important;
    color: #222222 !important;
}

body.appearance-dark {
    background: #111827 !important;
    color: #ffffff !important;
    animation: none !important;
}
body.appearance-dark .header,
body.appearance-dark .welcome,
body.appearance-dark .section,
body.appearance-dark .stat,
body.appearance-dark .driver-card,
body.appearance-dark .booking {
    background: #1f2937 !important;
    color: #ffffff !important;
}

body.appearance-gradient {
    background: radial-gradient(circle at 5% 5%, #00e5ff, transparent 28%), radial-gradient(circle at 95% 95%, #e100ff, transparent 30%), linear-gradient(135deg, #071952, #088395, #5700b3) !important;
    background-size: 200% 200% !important;
    animation: backgroundMove 12s ease infinite !important;
}

<!-- ABOUT US CSS -->
.about-btn {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 14px;

    color: white;
    font-size: 14px;
    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    background-size: 200%;

    box-shadow:
        0 8px 18px
        rgba(0,0,0,.25);

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);

    animation:
        buttonGradient 4s linear infinite;

    transition: .25s;
}

.about-btn:active {
    transform: scale(.95);
}
.about-modal {
    display:none;
    position:fixed;
    inset:0;
    z-index:99999;
    background:
        radial-gradient(circle at 10% 10%, rgba(0,110,255,.35), transparent 35%),
        radial-gradient(circle at 90% 90%, rgba(224,0,255,.35), transparent 35%),
        rgba(3,8,25,.88);
    padding:10px;
    align-items:center;
    justify-content:center;
    overflow-y:auto;
    backdrop-filter:blur(8px);
}
.about-modal.active { display:flex; }

.about-box {
    position:relative;
    width:100%;
    max-width:700px;
    max-height:92vh;
    padding:24px 18px 28px;
    border-radius:24px;
    background:linear-gradient(135deg,#071952,#0b5ed7,#4b20c9,#8b1fd1);
    background-size:300% 300%;
    animation:aboutGradient 10s ease infinite;
    color:white;
    border:1px solid rgba(255,255,255,.25);
    box-shadow:0 25px 70px rgba(0,0,0,.75);
    overflow-y:auto;
    scroll-behavior:smooth;
}

@keyframes aboutGradient {
    0% { background-position:0% 50%; }
    50% { background-position:100% 50%; }
    100% { background-position:0% 50%; }
}

.about-close {
    position:absolute;
    top:12px;
    right:12px;
    width:44px;
    height:44px;
    border:none;
    border-radius:50%;
    background:rgba(255,255,255,.18);
    color:white;
    font-size:24px;
    font-weight:bold;
    cursor:pointer;
    z-index:5;
    transition:.25s;
}
.about-close:hover {
    transform:rotate(90deg) scale(1.08);
    background:rgba(255,255,255,.3);
}

.about-welcome {
    text-align:center;
    padding:8px 48px 22px 8px;
    border-bottom:1px solid rgba(255,255,255,.25);
    margin-bottom:20px;
}

.about-welcome-title {
    margin:0 auto 12px;
    font-size:30px;
    line-height:1.3;
    font-weight:900;
    text-shadow:0 3px 12px rgba(0,0,0,.45);
    animation:welcomeAppear 1s ease-out,welcomeGlow 2.5s ease-in-out infinite alternate;
}

.about-welcome-text {
    margin:0 auto;
    font-size:17px;
    line-height:1.6;
    font-weight:600;
    color:rgba(255,255,255,.96);
    animation:welcomeAppear 1.4s ease-out;
}

@keyframes welcomeAppear {
    from { opacity:0; transform:translateY(-18px); }
    to { opacity:1; transform:translateY(0); }
}

@keyframes welcomeGlow {
    from { text-shadow:0 3px 12px rgba(0,0,0,.45); }
    to { text-shadow:0 0 10px rgba(255,255,255,.7),0 0 25px rgba(0,200,255,.5); }
}

.about-box h2 {
    margin:0 55px 10px 0;
    font-size:25px;
    line-height:1.3;
    font-weight:900;
}

.about-box h3 {
    margin-top:20px;
    margin-bottom:7px;
    font-size:19px;
    line-height:1.35;
    font-weight:900;
}

.about-box p {
    margin:7px 0;
    font-size:16px;
    line-height:1.65;
    font-weight:500;
}

.about-subtitle {
    margin-bottom:15px !important;
    font-size:17px !important;
    font-weight:700 !important;
}

.about-box ul {
    margin:8px 0 12px;
    padding-left:25px;
}

.about-box li {
    margin-bottom:7px;
    font-size:16px;
    line-height:1.55;
    font-weight:500;
}

.about-thankyou {
    margin-top:28px;
    padding:22px 15px;
    text-align:center;
    border-radius:18px;
    background:linear-gradient(135deg,rgba(0,110,255,.4),rgba(224,0,255,.4));
    border:1px solid rgba(255,255,255,.25);
    box-shadow:0 10px 30px rgba(0,0,0,.3);
}

.about-thankyou-title {
    margin:0 0 12px !important;
    font-size:32px !important;
    line-height:1.3 !important;
    font-weight:900 !important;
    text-align:center;
    animation:thankYouPulse 1.8s ease-in-out infinite;
    text-shadow:0 0 10px rgba(255,255,255,.6),0 4px 12px rgba(0,0,0,.45);
}

.about-contact {
    font-size:17px !important;
    line-height:1.6 !important;
    font-weight:600 !important;
    text-align:center;
    margin:0 !important;
}

@keyframes thankYouPulse {
    0%,100% { transform:scale(1); opacity:1; }
    50% { transform:scale(1.06); opacity:.88; }
}

.about-tagline {
    margin-top:18px;
    padding:14px;
    text-align:center;
    font-size:16px;
    line-height:1.5;
    font-weight:800;
    border-radius:14px;
    background:rgba(255,255,255,.1);
    border:1px solid rgba(255,255,255,.18);
}

@media (max-width:600px) {
    .about-modal { padding:8px; }
    .about-box { max-height:92vh; padding:22px 15px 25px; border-radius:22px; }
    .about-welcome { padding:8px 42px 20px 5px; }
    .about-welcome-title { font-size:25px; }
    .about-welcome-text { font-size:16px; }
    .about-box h2 { font-size:23px; }
    .about-box h3 { font-size:18px; }
    .about-box p { font-size:16px; line-height:1.65; }
    .about-box li { font-size:16px; line-height:1.55; }
    .about-thankyou-title { font-size:30px !important; }
    .about-contact { font-size:16px !important; }
    .about-tagline { font-size:15px; }
}
</style></head><body class="appearance-<?php echo strtolower(htmlspecialchars($appearance)); ?>"><div class="dashboard"><!-- HEADER --><header class="header"><div class="brand">

    <div class="brand-icon">
        🛵
    </div>

    <div>

        <h1>
            TransCalltation 2.0
        </h1>

        <p>
            SMART • SAFE • SIMPLE TRANSPORTATION
        </p>

    </div>

</div>


<a
  <a href="settings.php" class="settings-btn">
      ⚙️ Settings
  </a>

</header><!-- WELCOME --><div class="welcome"><h2>
    Welcome, <?php
    echo htmlspecialchars($user["full_name"]);
    ?>! 👋
</h2>

<p>
    Find an available driver and request your ride.
</p>

</div><!-- STATISTICS --><div class="stats"><div class="stat">

    <div class="stat-icon">
        🚕
    </div>

    <div class="stat-number">
        <?php echo count($drivers); ?>
    </div>

    <div class="stat-label">
        AVAILABLE DRIVERS
    </div>

</div>


<div class="stat">

    <div class="stat-icon">
        📋
    </div>

    <div class="stat-number">
        <?php echo count($bookings); ?>
    </div>

    <div class="stat-label">
        MY BOOKINGS
    </div>

</div>


<div class="stat">

    <div class="stat-icon">
        👨‍🎓
    </div>

    <div class="stat-number">
        STUDENT
    </div>

    <div class="stat-label">
        ACCOUNT TYPE
    </div>

</div>

</div><!-- AVAILABLE DRIVERS --><section class="section"><div class="section-title">

    <h3>
        🚕 Available Drivers
    </h3>

</div>


<?php if (count($drivers) > 0): ?>

    <div class="driver-grid">

        <?php foreach ($drivers as $driver): ?>

            <div class="driver-card">

                <div class="driver-top">

                    <div class="driver-icon">
                        🛵
                    </div>

                    <div>

                        <div class="driver-name">

                            <?php
                            echo htmlspecialchars(
                                $driver["full_name"]
                            );
                            ?>

                        </div>

                        <span class="available">

                            🟢 AVAILABLE

                        </span>

                    </div>

                </div>


                <div class="driver-info">

                    🛵 Vehicle:
                    <?php
                    echo htmlspecialchars(
                        $driver["vehicle"]
                    );
                    ?>

                    <br>

                    🔢 Plate:
                    <?php
                    echo htmlspecialchars(
                        $driver["plate"]
                    );
                    ?>

                </div>


                <button
                    class="request-btn"
                    onclick="openBooking(
                        <?php echo $driver['id']; ?>,
                        '<?php echo htmlspecialchars(
                            $driver['full_name'],
                            ENT_QUOTES
                        ); ?>'
                    )">

                    🚕 REQUEST RIDE

                </button>

            </div>

        <?php endforeach; ?>

    </div>


<?php else: ?>

    <div class="empty">

        🛵


        <strong>
            No drivers available right now.
        </strong>

        <br>

        Please check again later.

    </div>

<?php endif; ?>

</section><!-- BOOKING RECORDS --><section class="section"><div class="section-title">

    <h3>
        📋 My Booking Records
    </h3>

</div>


<?php if (count($bookings) > 0): ?>

    <?php foreach ($bookings as $booking): ?>

        <div class="booking">

            <strong>

                🛵
                <?php
                echo htmlspecialchars(
                    $booking["driver_name"] ?? "Driver"
                );
                ?>

            </strong>


            <div class="route">

                📍
                <?php
                echo htmlspecialchars(
                    $booking["pickup"]
                );
                ?>

                <br>

                🏁
                <?php
                echo htmlspecialchars(
                    $booking["dropoff"]
                );
                ?>

            </div>


            <span class="status">

                <?php
                echo htmlspecialchars(
                    $booking["status"]
                );
                ?>

            </span>

        </div>

    <?php endforeach; ?>


<?php else: ?>

    <div class="empty">

        📋

        <br><br>

        You don't have any bookings yet.

    </div>

<?php endif; ?>

<!-- ABOUT US -->
<section class="section">
    <h3>🛵 About TransCalltation</h3>

    <button
        type="button"
        class="about-btn"
        onclick="openAboutUs()"
    >
        ℹ️ ABOUT US
    </button>
</section>

<!-- ABOUT US MODAL -->
<div id="aboutUsModal" class="about-modal">
    <div class="about-box">

        <div class="about-welcome">
            <h1 class="about-welcome-title">
                ✨ Thank you for Choosing TransCalltation ✨
            </h1>

            <p class="about-welcome-text">
                Please read below for more information about TransCalltation,
                its purpose, features, and benefits.
            </p>
        </div>

        <button
            type="button"
            class="about-close"
            onclick="closeAboutUs()"
        >
            ✕
        </button>

        <h2>🛵 About TransCalltation</h2>

        <p class="about-subtitle">
            A Web-Based Transportation Assistance and Ride Booking System
        </p>

        <h3>1. Introduction</h3>
        <p>
            TransCalltation is a proposed web-based system designed to help
            students find available transportation more conveniently.
            It focuses on reducing long waiting times and helping students
            manage their schedules when looking for motorcycle or other
            available transportation.
        </p>

        <h3>2. Main Problem</h3>
        <p>
            Many students have difficulty finding available transportation,
            especially during busy hours. They may spend a long time waiting
            for a motorcycle or vehicle, which can cause delays and make it
            difficult to arrive at school or other destinations on time.
        </p>

        <h3>3. Why Transportation Is Important</h3>
        <p>
            Reliable transportation is important for students because it
            allows them to travel to school, go home, attend activities,
            and manage their daily responsibilities.
        </p>

        <h3>4. Reasons Why It Is a Problem</h3>
        <ul>
            <li>Long waiting times during peak hours.</li>
            <li>Limited available drivers near schools.</li>
            <li>Difficulty identifying available drivers.</li>
            <li>Students may arrive late to class.</li>
            <li>Transportation problems can affect students' daily schedules.</li>
        </ul>

        <h3>5. Effects on Students</h3>
        <p>
            Transportation problems can result in wasted time, delays,
            stress, and difficulty managing school activities. Students
            may also spend additional time searching for an available
            driver instead of focusing on their academic responsibilities.
        </p>

        <h3>6. Evidence of the Problem</h3>
        <p>
            The project can use photos and videos as evidence, such as:
        </p>

        <ul>
            <li>Students waiting for motorcycles.</li>
            <li>Long lines of commuters.</li>
            <li>Crowded roads near schools.</li>
            <li>Students waiting during peak hours.</li>
            <li>Areas with limited transportation.</li>
        </ul>

        <p>
            <strong>Note:</strong>
            Always ask permission when taking identifiable photos or videos
            of people.
        </p>

        <h3>7. Proposed Solution</h3>
        <p>
            TransCalltation provides a centralized website where students
            can find available drivers and request rides. Drivers can
            manage their availability, while administrators can manage
            users, drivers, and bookings.
        </p>

        <div class="about-tagline">
            🛵 SMART • SAFE • SIMPLE TRANSPORTATION
        </div>

        <div class="about-thankyou">
            <h2 class="about-thankyou-title">
                🙏 Thank you!
            </h2>

            <p class="about-contact">
                Please contact the administrator for more information,
                questions, assistance, or support regarding TransCalltation.
            </p>
        </div>

    </div>
</div>
</section></div><!-- BOOKING MODAL --><div
    class="modal"
    id="bookingModal"><div class="modal-box">

    <h2>
        🚕 Request Ride
    </h2>

    <p id="selectedDriver">
        Driver
    </p>


    <form
        action="book.php"
        method="POST">


        <input
            type="hidden"
            name="driver_id"
            id="driverId"
        >


        <label>
            📍 PICKUP LOCATION
        </label>

        <input
            type="text"
            name="pickup"
            placeholder="Example: Main Gate"
            required
        >


        <label>
            🏁 DROP-OFF LOCATION
        </label>

        <input
            type="text"
            name="dropoff"
            placeholder="Example: City Mall"
            required
        >


        <button
            type="submit"
            class="confirm">

            ✅ CONFIRM BOOKING

        </button>


        <button
            type="button"
            class="cancel"
            onclick="closeBooking()">

            CANCEL

        </button>

    </form>

</div>

</div><script>

function openBooking(id, name) {

    document.getElementById(
        "driverId"
    ).value = id;

    document.getElementById(
        "selectedDriver"
    ).textContent =
        "Driver: " + name;

    document.getElementById(
        "bookingModal"
    ).classList.add("active");

}


function closeBooking() {

    document.getElementById(
        "bookingModal"
    ).classList.remove("active");

}


/* Close when tapping outside */

document.getElementById(
    "bookingModal"
).addEventListener(
    "click",
    function(event) {

        if (event.target === this) {

            closeBooking();

        }

    }
);


<script>
function openAboutUs() {
    document.getElementById("aboutUsModal").classList.add("active");
}

function closeAboutUs() {
    document.getElementById("aboutUsModal").classList.remove("active");
}

document.getElementById("aboutUsModal").addEventListener(
    "click",
    function(event) {
        if (event.target === this) {
            closeAboutUs();
        }
    }
);
</script>


<script>
function openAboutUs() {
    document.getElementById("aboutUsModal").classList.add("active");
}

function closeAboutUs() {
    document.getElementById("aboutUsModal").classList.remove("active");
}

document.getElementById("aboutUsModal").addEventListener(
    "click",
    function(event) {
        if (event.target === this) {
            closeAboutUs();
        }
    }
);
</script>

</script></body></html>

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.20-12.3.3-MariaDB, for Android (aarch64)
--
-- Host: localhost    Database: transcalltation2
-- ------------------------------------------------------
-- Server version	12.3.3-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `admin_notifications`
--

DROP TABLE IF EXISTS `admin_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `driver_id` (`driver_id`),
  KEY `is_read` (`is_read`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `admin_notifications` WRITE;
/*!40000 ALTER TABLE `admin_notifications` DISABLE KEYS */;
INSERT INTO `admin_notifications` VALUES
(1,'driver_verification','New Driver Verification','Braderrr submitted a new driver registration application for verification.',15,0,'2026-09-05 20:34:57');
/*!40000 ALTER TABLE `admin_notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `pickup` varchar(255) NOT NULL,
  `dropoff` varchar(255) NOT NULL,
  `status` varchar(30) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `pickup_latitude` decimal(10,8) DEFAULT NULL,
  `pickup_longitude` decimal(11,8) DEFAULT NULL,
  `driver_latitude` decimal(10,8) DEFAULT NULL,
  `driver_longitude` decimal(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `driver_id` (`driver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES
(11,13,14,'Ipao','Calbayog gaisano','Accepted','2026-09-05 17:42:12',12.06802730,124.56425830,NULL,NULL),
(16,16,14,'Nwssu','Ipao','Accepted','2026-09-08 20:09:52',12.06802870,124.56426040,NULL,NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `message_type` varchar(20) NOT NULL DEFAULT 'message',
  `complaint_status` varchar(20) NOT NULL DEFAULT 'Open',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES
(1,1,3,'DATABASE TEST MESSAGE',NULL,'message','Open',0,'2026-09-08 10:40:08'),
(2,3,10,'Hi',NULL,'message','Open',0,'2026-09-08 10:54:37'),
(3,3,15,'Hi',NULL,'message','Open',0,'2026-09-08 10:54:47'),
(4,16,15,'Bosss adi AK gaisano',NULL,'message','Open',0,'2026-09-08 13:38:27'),
(5,16,15,'Jsjdjdhdhhdhh',NULL,'complaint','Resolved',0,'2026-09-08 13:38:51'),
(6,16,3,'I want to complaint the rider brother',NULL,'complaint','Resolved',1,'2026-09-08 13:39:39'),
(7,3,16,'We receive your message',NULL,'message','Open',1,'2026-09-08 16:13:42'),
(8,3,16,'Yes',NULL,'message','Open',0,'2026-09-08 22:39:13'),
(9,3,14,'','9894cdcd1f8f81f12645e65f279435ff.png','message','Open',1,'2026-09-14 14:22:07');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `push_subscriptions`
--

DROP TABLE IF EXISTS `push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `endpoint` text NOT NULL,
  `p256dh` text NOT NULL,
  `auth` text NOT NULL,
  `device_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscriptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `push_subscriptions` WRITE;
/*!40000 ALTER TABLE `push_subscriptions` DISABLE KEYS */;
INSERT INTO `push_subscriptions` VALUES
(4,3,'https://fcm.googleapis.com/fcm/send/cLkO6qEEhVA:APA91bG9UXlZqbM3Ef_CO323Q_X919edoe_XIRiKq9LBsaAoAVV8-aieoek9sKTh-U36tDoyObD6uzlu-zzob7hGdXo5mpOcZY11QGo5WyJFQIkclkb8mBxGy2rcX8Ke45JR0UC_HaXs','BM5sNIS1fExLufyIbcS_U34XmVrnGxg9vyHCQEWNS6BJmcZBB-Qp2CJq3DG1aNbo4E_V3EjRv6ClHACgvmqiM_g','cQcM09ZDaNJIMFivekzPCw','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.3','2026-09-08 19:07:40','2026-09-08 20:12:53'),
(5,14,'https://fcm.googleapis.com/fcm/send/fadKp5mlZ_A:APA91bHdHXlQVOXQYwuMQgYVcErCAr8LNZ5lvSyZX9Af0RfDHl5uivAzvsqqb3lw2s_bkRSPpfPavhrtKoWEecSpcS__n9QljPhhhTk1CQZ-UeakIMJ-grENioM9vvQrY0KcTOuyU2l2','BFaTE-uyLtKtFuBwRxlHvD7_uBGQEqxqKUjZN_62FSF6zLY1ohLx9Jt5ikJgP5B1k8DcaEfoCKMsg6KDXyv81QA','cih6e9Igyg87fFvqwD3Dbg','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.3','2026-10-01 07:09:52','2026-10-01 07:09:52');
/*!40000 ALTER TABLE `push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','driver','admin') NOT NULL DEFAULT 'student',
  `status` varchar(20) DEFAULT 'Available',
  `vehicle` varchar(100) DEFAULT NULL,
  `plate` varchar(50) DEFAULT NULL,
  `driver_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `booking_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `language` varchar(20) NOT NULL DEFAULT 'English',
  `appearance` varchar(20) NOT NULL DEFAULT 'Gradient',
  `suspended_until` datetime DEFAULT NULL,
  `suspension_reason` varchar(255) DEFAULT NULL,
  `driver_license_photo` varchar(255) DEFAULT NULL,
  `government_id_photo` varchar(255) DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `vehicle_photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Rolando','rolando@gmail.com',NULL,'$2y$12$bwIlDFa/4FLo0dr3ZycSHOV899DdqmFI12lO24Xo2Q2Dqe.6fYg8C','student','Available','','',1,'2026-08-30 16:41:40',1,'en','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(3,'KUYA DLAN','ronaldstasinghilo@gmail.com',NULL,'$2y$12$72YE57LS.NR2oCTBPimxauUIGgu5Jn7o6215zXFRllDOv0sUqWvZa','admin','Available',NULL,NULL,0,'2026-08-30 17:12:23',1,'en','Dark',NULL,NULL,NULL,NULL,NULL,NULL),
(4,'Jorge','jorge@gmail.com',NULL,'$2y$12$ZTUAMHvcfiNoD.fPwjeJyOrfmGVEysBcjL/at0GdhzU3xL9SY2Dp6','student','Available','','',1,'2026-08-30 18:15:32',1,'fil','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(6,'Junrel Lagahit','Junrel@gmail.com',NULL,'$2y$12$i/6yzpb5Tz5DG3ZkSfbkYeB.gnxyHgIbKZGwRvQHUrsBtI8QmlM/O','student','Available','','',1,'2026-08-31 18:27:24',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(8,'JUNREL D. LAGAHIT','junrellagahit47@gmail.com',NULL,'$2y$12$9dxKiMDhYLCeSt9xkBR7J.ytTeg0Dyzgrhf3n0MHyNKV3Kjq0fQPW','student','Available','','',1,'2026-09-01 07:15:19',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(9,'Micah belarmino','belarminomicah109@gmail.com',NULL,'$2y$12$jeRqpsKffjJKCtcKQohe9eE7OkDfCUgjtDyJl0AJW084u44IQfv86','student','Available','','',1,'2026-09-01 08:59:14',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(13,'JARED','jared@gmail.com','09123456789','$2y$12$2NO972FiJ48g7f0IDHoUVOu2qBthUFAUdguB9b53hzOpb58LCmcBW','student','Available','','',1,'2026-09-05 13:44:55',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(14,'Alex','alex@gmail.com','09123456789','$2y$12$y//KfQvWXRI6Ar.ALK9dRe2h4.6l/i3vHfZUVFqF3w8Ks9HPHGmTm','driver','Available','Rusi fi','Stzr7zzr7zz',1,'2026-09-05 17:39:43',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(16,'John','john@gmail.com','09123456789','$2y$12$gqIqe02RaL8TgC6vylpNo.dbHjfiao9Ej5CXANyOmYHmDNGsIS2Oi','student','Available','','',1,'2026-09-08 09:20:25',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL),
(17,'Jo Mary','jomary@gmail.com','09123456789','$2y$12$Ft4VIHbKSYxb7TRP1J/2Cu12XnvTVB3vmviO11p.cJFeekhSd2x2y','student','Available','','',1,'2026-09-14 17:23:02',1,'English','Gradient',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-01 15:14:29

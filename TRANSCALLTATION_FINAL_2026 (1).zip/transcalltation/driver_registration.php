<?php
session_start();
include "config.php";

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $full_name = trim($_POST["full_name"] ?? "");
    $phone     = trim($_POST["phone"] ?? "");
    $email     = trim($_POST["email"] ?? "");
    $password  = $_POST["password"] ?? "";
    $vehicle   = trim($_POST["vehicle"] ?? "");
    $plate     = trim($_POST["plate"] ?? "");

    /* Basic validation */
    if (
        $full_name === "" ||
        $phone === "" ||
        $email === "" ||
        $password === "" ||
        $vehicle === "" ||
        $plate === ""
    ) {
        $error = "Please complete all required fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";

    } elseif (
        strlen($password) < 8 ||
        !preg_match('/[A-Za-z]/', $password) ||
        !preg_match('/[0-9]/', $password)
    ) {
        $error = "Password must be at least 8 characters and contain letters and numbers.";

    } else {

        /* Check existing email */
        $check = $conn->prepare(
            "SELECT id FROM users WHERE email = ? LIMIT 1"
        );
        $check->bind_param("s", $email);
        $check->execute();
        $check_result = $check->get_result();

        if ($check_result->num_rows > 0) {

            $error = "This email is already registered.";

        } else {

            /*
             * Each photo can come from either Camera or Gallery.
             */
            $photo_groups = [
                "driver_license_photo" => [
                    "driver_license_camera",
                    "driver_license_gallery"
                ],
                "government_id_photo" => [
                    "government_id_camera",
                    "government_id_gallery"
                ],
                "profile_photo" => [
                    "profile_camera",
                    "profile_gallery"
                ],
                "vehicle_photo" => [
                    "vehicle_camera",
                    "vehicle_gallery"
                ]
            ];

            $uploaded_files = [];
            $upload_errors = [];

            $private_dir = dirname(__DIR__) . "/transcalltation_private/driver_documents";

            /*
             * Use the actual Termux home directory.
             */
            $private_dir = getenv("HOME") . "/transcalltation_private/driver_documents";

            if (!is_dir($private_dir)) {
                mkdir($private_dir, 0700, true);
            }

            $allowed_types = [
                "image/jpeg" => "jpg",
                "image/png"  => "png",
                "image/webp" => "webp"
            ];

            $max_size = 2 * 1024 * 1024;

            foreach ($photo_groups as $db_name => $inputs) {

                $selected_input = null;

                foreach ($inputs as $input_name) {

                    if (
                        isset($_FILES[$input_name]) &&
                        $_FILES[$input_name]["error"] !== UPLOAD_ERR_NO_FILE
                    ) {
                        $selected_input = $input_name;
                        break;
                    }
                }

                if ($selected_input === null) {
                    $upload_errors[] = "Please upload all required driver photos.";
                    break;
                }

                $file = $_FILES[$selected_input];

                if ($file["error"] !== UPLOAD_ERR_OK) {
                    $upload_errors[] = "One of the uploaded photos could not be processed.";
                    break;
                }

                if ($file["size"] > $max_size) {
                    $upload_errors[] = "Each photo must be 2 MB or smaller.";
                    break;
                }

                if (!is_uploaded_file($file["tmp_name"])) {
                    $upload_errors[] = "Invalid uploaded file.";
                    break;
                }

                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($file["tmp_name"]);

                if (!isset($allowed_types[$mime])) {
                    $upload_errors[] = "Only JPG, PNG, and WEBP images are allowed.";
                    break;
                }

                $extension = $allowed_types[$mime];

                $filename = bin2hex(random_bytes(16)) . "." . $extension;
                $destination = $private_dir . "/" . $filename;

                if (!move_uploaded_file($file["tmp_name"], $destination)) {
                    $upload_errors[] = "Failed to save an uploaded photo.";
                    break;
                }

                chmod($destination, 0600);

                $uploaded_files[$db_name] = $filename;
            }

            /*
             * If any upload failed, remove files already saved.
             */
            if (!empty($upload_errors)) {

                foreach ($uploaded_files as $filename) {
                    $path = $private_dir . "/" . $filename;

                    if (is_file($path)) {
                        unlink($path);
                    }
                }

                $error = $upload_errors[0];

            } else {

                $hashed_password = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                /*
                 * New drivers start unverified and pending.
                 */
                $driver_verified = 0;
                $status = "Pending";

                $stmt = $conn->prepare(
                    "INSERT INTO users
                    (
                        full_name,
                        email,
                        phone,
                        password,
                        role,
                        status,
                        vehicle,
                        plate,
                        driver_verified,
                        driver_license_photo,
                        government_id_photo,
                        profile_photo,
                        vehicle_photo
                    )
                    VALUES
                    (?, ?, ?, ?, 'driver', ?, ?, ?, ?, ?, ?, ?, ?)"
                );

                $stmt->bind_param(
                    "sssssssissss",
                    $full_name,
                    $email,
                    $phone,
                    $hashed_password,
                    $status,
                    $vehicle,
                    $plate,
                    $driver_verified,
                    $uploaded_files["driver_license_photo"],
                    $uploaded_files["government_id_photo"],
                    $uploaded_files["profile_photo"],
                    $uploaded_files["vehicle_photo"]
                );

                if ($stmt->execute()) {

                    $driver_id = $stmt->insert_id;

                    /*
                     * Create notification for the administrator.
                     */
                    $notification_title = "New Driver Verification";
                    $notification_message =
                        $full_name .
                        " submitted a new driver registration application for verification.";

                    $notification_type = "driver_verification";

                    $notify = $conn->prepare(
                        "INSERT INTO admin_notifications
                        (
                            type,
                            title,
                            message,
                            driver_id
                        )
                        VALUES (?, ?, ?, ?)"
                    );

                    $notify->bind_param(
                        "sssi",
                        $notification_type,
                        $notification_title,
                        $notification_message,
                        $driver_id
                    );

                    $notify->execute();
                    $notify->close();

                    $success =
                        "Driver application submitted successfully! " .
                        "Your account is pending admin verification.";

                } else {

                    foreach ($uploaded_files as $filename) {
                        $path = $private_dir . "/" . $filename;

                        if (is_file($path)) {
                            unlink($path);
                        }
                    }

                    $error = "Registration failed. Please try again.";
                }

                $stmt->close();
            }
        }

        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Driver Registration | TransCalltation 2.0</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    font-family: Arial, Helvetica, sans-serif;
    color: white;
    overflow-x: hidden;

    background:
        linear-gradient(
            rgba(3, 8, 25, 0.70),
            rgba(3, 8, 25, 0.90)
        ),
        url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
        center center / cover fixed no-repeat;
}

.portal {
    width: 100%;
    max-width: 900px;
    margin: 30px auto;
    padding: 25px;
}

.header {
    text-align: center;
    margin-bottom: 25px;
}

.badge {
    display: inline-block;
    padding: 9px 16px;
    border-radius: 30px;
    background: linear-gradient(135deg, #00c6ff, #7b2cff);
    font-weight: bold;
    font-size: 13px;
    box-shadow: 0 5px 20px rgba(0,0,0,.3);
}

.header h1 {
    margin: 15px 0 8px;
    font-size: clamp(28px, 6vw, 46px);
}

.header h1 span {
    background: linear-gradient(90deg, #00d4ff, #8c52ff, #ff4ecd);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.header p {
    opacity: .9;
    line-height: 1.6;
}

.card {
    padding: 28px;
    border-radius: 28px;

    background: rgba(255,255,255,.13);
    border: 1px solid rgba(255,255,255,.25);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);

    box-shadow: 0 20px 60px rgba(0,0,0,.45);
}

.section {
    margin-bottom: 30px;
}

.section-title {
    margin-bottom: 18px;
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(255,255,255,.2);

    font-size: 20px;
    font-weight: bold;
}

label {
    display: block;
    margin: 15px 0 7px;
    font-size: 13px;
    font-weight: bold;
    letter-spacing: .5px;
}

input {
    width: 100%;
    padding: 14px;
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 14px;

    background: rgba(255,255,255,.12);
    color: white;
    outline: none;
}

input::placeholder {
    color: rgba(255,255,255,.65);
}

input:focus {
    border-color: #00c6ff;
    box-shadow: 0 0 15px rgba(0,198,255,.25);
}

.password-note,
.photo-note {
    margin-top: 7px;
    font-size: 12px;
    opacity: .75;
}

.photo-card {
    margin-top: 18px;
    padding: 18px;
    border-radius: 20px;

    background: rgba(0,0,0,.20);
    border: 1px solid rgba(255,255,255,.15);
}

.photo-title {
    font-weight: bold;
    margin-bottom: 5px;
}

.photo-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-top: 12px;
}

.photo-button {
    position: relative;
    overflow: hidden;

    display: block;
    padding: 13px;
    border-radius: 13px;

    text-align: center;
    font-weight: bold;
    cursor: pointer;

    background: linear-gradient(135deg, #00a8ff, #7b2cff);
}

.photo-button.gallery {
    background: linear-gradient(135deg, #ff4ecd, #7b2cff);
}

.photo-button input {
    position: absolute;
    inset: 0;
    opacity: 0;
    cursor: pointer;
    padding: 0;
}

.preview {
    display: none;
    width: 100%;
    max-height: 220px;
    object-fit: contain;
    margin-top: 15px;

    border-radius: 15px;
    border: 1px solid rgba(255,255,255,.2);
}

.checklist {
    margin-top: 25px;
    padding: 20px;
    border-radius: 20px;

    background: rgba(0,0,0,.20);
}

.check-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 0;
    font-size: 14px;
}

.check {
    color: #35ff9b;
    font-size: 18px;
}

.progress {
    margin-top: 15px;
    font-weight: bold;
    text-align: center;
}

.submit-button {
    width: 100%;
    margin-top: 25px;
    padding: 16px;

    border: none;
    border-radius: 16px;

    color: white;
    font-size: 16px;
    font-weight: bold;

    background: linear-gradient(135deg, #00c6ff, #7b2cff);
    box-shadow: 0 10px 30px rgba(0,0,0,.3);

    cursor: pointer;
}

@media (max-width: 600px) {
    .portal {
        margin: 10px auto;
        padding: 12px;
    }

    .card {
        padding: 20px;
    }

    .photo-actions {
        grid-template-columns: 1fr;
    }
}
</style>
</head>

<body>

<div class="portal">

    <div class="header">
        <div class="badge">🏍️ TRANSCALLTATION 2.0</div>

        <h1>
            Driver <span>Registration Portal</span>
        </h1>

        <p>
            Complete all required information and submit the required
            documents for driver verification.
        </p>
    </div>

    <form class="card" id="driverForm" method="POST" enctype="multipart/form-data">

        <!-- PERSONAL INFORMATION -->
        <div class="section">

            <div class="section-title">
                👤 Personal Information
            </div>

            <label>FULL NAME</label>
            <input
                type="text"
                name="full_name"
                placeholder="Enter your full name"
                required
            >

            <label>PHONE NUMBER</label>
            <input
                type="tel"
                name="phone"
                placeholder="Enter your phone number"
                required
            >

            <label>EMAIL</label>
            <input
                type="email"
                name="email"
                placeholder="Enter your email"
                required
            >

            <label>CREATE PASSWORD</label>
            <input
                type="password"
                name="password"
                placeholder="At least 8 characters, letters and numbers"
                minlength="8"
                pattern="(?=.*[A-Za-z])(?=.*[0-9]).{8,}"
                required
            >

            <div class="password-note">
                🔐 Password must contain at least 8 characters,
                including letters and numbers.
            </div>

        </div>

        <!-- VEHICLE INFORMATION -->
        <div class="section">

            <div class="section-title">
                🏍️ Vehicle Information
            </div>

            <label>VEHICLE MODEL</label>
            <input
                type="text"
                name="vehicle"
                placeholder="Example: Honda Click"
                required
            >

            <label>PLATE NUMBER</label>
            <input
                type="text"
                name="plate"
                placeholder="Example: ABC-1234"
                required
            >

        </div>

        <!-- DOCUMENTS -->
        <div class="section">

            <div class="section-title">
                📋 Required Driver Documents
            </div>

            <!-- LICENSE -->
            <div class="photo-card">
                <div class="photo-title">
                    🪪 Driver's License
                </div>

                <div class="photo-note">
                    Upload a clear photo of your driver's license.
                </div>

                <div class="photo-actions">

                    <label class="photo-button">
                        📷 Take Photo
                        <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            name="driver_license_camera" data-preview="licensePreview"
                            required
                        >
                    </label>

                    <label class="photo-button gallery">
                        🖼️ Choose from Gallery
                        <input
                            type="file"
                            accept="image/*"
                            name="driver_license_gallery" data-preview="licensePreview"
                        >
                    </label>

                </div>

                <img id="licensePreview" class="preview">
            </div>

            <!-- GOVERNMENT ID -->
            <div class="photo-card">
                <div class="photo-title">
                    🆔 Government ID
                </div>

                <div class="photo-note">
                    Passport, National ID, or another accepted government ID.
                </div>

                <div class="photo-actions">

                    <label class="photo-button">
                        📷 Take Photo
                        <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            name="government_id_camera" data-preview="governmentPreview"
                            required
                        >
                    </label>

                    <label class="photo-button gallery">
                        🖼️ Choose from Gallery
                        <input
                            type="file"
                            accept="image/*"
                            name="government_id_gallery" data-preview="governmentPreview"
                        >
                    </label>

                </div>

                <img id="governmentPreview" class="preview">
            </div>

            <!-- PROFILE -->
            <div class="photo-card">
                <div class="photo-title">
                    👤 Driver Profile Photo
                </div>

                <div class="photo-note">
                    Use a clear photo of yourself.
                </div>

                <div class="photo-actions">

                    <label class="photo-button">
                        📷 Take Photo
                        <input
                            type="file"
                            accept="image/*"
                            capture="user"
                            name="profile_camera" data-preview="profilePreview"
                            required
                        >
                    </label>

                    <label class="photo-button gallery">
                        🖼️ Choose from Gallery
                        <input
                            type="file"
                            accept="image/*"
                            name="profile_gallery" data-preview="profilePreview"
                        >
                    </label>

                </div>

                <img id="profilePreview" class="preview">
            </div>

            <!-- VEHICLE -->
            <div class="photo-card">
                <div class="photo-title">
                    🏍️ Vehicle Photo
                </div>

                <div class="photo-note">
                    The vehicle's license plate must be clearly visible.
                </div>

                <div class="photo-actions">

                    <label class="photo-button">
                        📷 Take Photo
                        <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            name="vehicle_camera" data-preview="vehiclePreview"
                            required
                        >
                    </label>

                    <label class="photo-button gallery">
                        🖼️ Choose from Gallery
                        <input
                            type="file"
                            accept="image/*"
                            name="vehicle_gallery" data-preview="vehiclePreview"
                        >
                    </label>

                </div>

                <img id="vehiclePreview" class="preview">
            </div>

        </div>

        <!-- CHECKLIST -->
        <div class="checklist">

            <div class="section-title">
                ✅ Driver Requirements Checklist
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Full Name
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Phone Number & Email
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Strong Password
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Vehicle & Plate Number
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Driver's License Photo
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Government ID Photo
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Driver Profile Photo
            </div>

            <div class="check-item">
                <span class="check">✓</span>
                Vehicle Photo with Plate Visible
            </div>

            <div class="progress">
                📋 ALL REQUIRED ITEMS MUST BE COMPLETED
            </div>

        </div>

        <button type="submit" class="submit-button">
            🚀 SUBMIT DRIVER APPLICATION
        </button>

    </form>

</div>

<script>
document.querySelectorAll('input[type="file"]').forEach(function(input) {

    input.addEventListener('change', function() {

        if (!this.files || !this.files[0]) {
            return;
        }

        const previewId = this.dataset.preview;
        const preview = document.getElementById(previewId);

        if (!preview) {
            return;
        }

        const file = this.files[0];

        if (!file.type.startsWith("image/")) {
            alert("Please select an image file.");
            this.value = "";
            return;
        }

        preview.src = URL.createObjectURL(file);
        preview.style.display = "block";

    });

});
</script>

</body>
</html>

<?php

session_start();
include "config.php";

/* Only logged-in administrators can view driver documents */
if (!isset($_SESSION["user_id"])) {
    http_response_code(403);
    exit("Access denied.");
}

$user_id = (int) $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();

if (
    !$user ||
    strtolower($user["role"]) !== "admin"
) {
    http_response_code(403);
    exit("Access denied.");
}


/* Get requested filename */
$file = basename(
    $_GET["file"] ?? ""
);

if ($file === "") {
    http_response_code(404);
    exit("File not found.");
}


/* Private driver document folder */
$private_dir =
    getenv("HOME") .
    "/transcalltation_private/driver_documents";

$file_path =
    $private_dir .
    "/" .
    $file;


/* Verify that this file belongs to a registered driver */
$owner_stmt = $conn->prepare(
    "SELECT id
     FROM users
     WHERE role = 'driver'
       AND (
            driver_license_photo = ?
            OR government_id_photo = ?
            OR profile_photo = ?
            OR vehicle_photo = ?
       )
     LIMIT 1"
);

$owner_stmt->bind_param(
    "ssss",
    $file,
    $file,
    $file,
    $file
);

$owner_stmt->execute();

$owner_result = $owner_stmt->get_result();
$file_owner = $owner_result->fetch_assoc();

$owner_stmt->close();

if (!$file_owner) {
    http_response_code(404);
    exit("File not found.");
}

/* Make sure the file exists */
if (
    !is_file($file_path) ||
    !is_readable($file_path)
) {
    http_response_code(404);
    exit("File not found.");
}


/* Allow only image formats */
$finfo = new finfo(FILEINFO_MIME_TYPE);

$mime = $finfo->file($file_path);

$allowed = [
    "image/jpeg",
    "image/png",
    "image/webp"
];

if (!in_array($mime, $allowed, true)) {
    http_response_code(403);
    exit("Unsupported file.");
}


/* Send image */
header(
    "Content-Type: " . $mime
);

header(
    "Content-Length: " .
    filesize($file_path)
);

header(
    "X-Content-Type-Options: nosniff"
);

readfile($file_path);

exit();
?>

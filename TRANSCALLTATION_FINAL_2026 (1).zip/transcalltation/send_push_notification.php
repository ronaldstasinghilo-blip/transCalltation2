<?php

require_once __DIR__ . "/vendor/autoload.php";

include "config.php";
include "push_config.php";

use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

function sendPushNotification($user_id, $title, $body)
{
    global $conn;
    global $VAPID_SUBJECT;
    global $VAPID_PUBLIC_KEY;
    global $VAPID_PRIVATE_KEY;

    $user_id = (int)$user_id;

    if ($user_id <= 0) {
        return false;
    }

    $auth = [
        "VAPID" => [
            "subject" => $VAPID_SUBJECT,
            "publicKey" => $VAPID_PUBLIC_KEY,
            "privateKey" => $VAPID_PRIVATE_KEY
        ]
    ];

    try {
        $webPush = new WebPush($auth);

        $stmt = $conn->prepare(
            "SELECT id, endpoint, p256dh, auth
             FROM push_subscriptions
             WHERE user_id = ?"
        );

        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        $result = $stmt->get_result();

        $subscriptions = [];

        while ($row = $result->fetch_assoc()) {
            $subscriptions[] = $row;
        }

        $stmt->close();

        if (empty($subscriptions)) {
            return false;
        }

        $payload = json_encode([
            "title" => $title,
            "body" => $body
        ]);

        foreach ($subscriptions as $row) {

            $subscription = Subscription::create([
                "endpoint" => $row["endpoint"],
                "keys" => [
                    "p256dh" => $row["p256dh"],
                    "auth" => $row["auth"]
                ]
            ]);

            $webPush->queueNotification(
                $subscription,
                $payload
            );
        }

        foreach ($webPush->flush() as $report) {

            if (!$report->isSuccess()) {

                $reason = $report->getReason();

                if (stripos($reason, "Gone") !== false) {

                    $delete = $conn->prepare(
                        "DELETE FROM push_subscriptions
                         WHERE id = ?"
                    );

                    $subscription_id = 0;

                    foreach ($subscriptions as $row) {
                        if ($row["endpoint"] === $report->getEndpoint()) {
                            $subscription_id = (int)$row["id"];
                            break;
                        }
                    }

                    if ($subscription_id > 0) {
                        $delete->bind_param(
                            "i",
                            $subscription_id
                        );
                        $delete->execute();
                    }

                    $delete->close();
                }
            }
        }

        return true;

    } catch (Throwable $e) {
        error_log(
            "Push notification error: " . $e->getMessage()
        );

        return false;
    }
}
?>

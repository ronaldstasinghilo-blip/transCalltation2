<?php

session_start();

include "config.php";
include "appearance_loader.php";

/* Protect page */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];


/* Get admin information */

$stmt = $conn->prepare(
    "SELECT id, full_name, email, role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$stmt->close();


/* Only admin can access */

if (!$admin || $admin["role"] !== "admin") {
    header("Location: dashboard.php");
    exit();
}


/* Get drivers */

$drivers = [];

$result = $conn->query(
    "SELECT id, full_name, email, vehicle, plate,
            status, driver_verified
     FROM users
     WHERE role = 'driver'
     ORDER BY id DESC"
);

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }

}


/* Get all Wbookings */

$bookings = [];

$result = $conn->query(
    "SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,

        s.full_name AS student_name,

        d.full_name AS driver_name

     FROM bookings b

     LEFT JOIN users s
        ON b.student_id = s.id

     LEFT JOIN users d
        ON b.driver_id = d.id

     ORDER BY b.id DESC"
);

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    Admin Dashboard | TransCalltation 2.0
</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    padding: 15px;

    font-family: Arial, sans-serif;

    color: white;

    background:

        radial-gradient(
            circle at 10% 10%,
            #00e5ff,
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 90%,
            #e100ff,
            transparent 35%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

    background-size: 200% 200%;

    animation:
        backgroundMove 12s ease infinite;
}


/* MAIN */

.dashboard {

    width: 100%;

    max-width: 1100px;

    margin: auto;

    animation:
        pageEnter .8s ease;
}


/* HEADER */

.header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 18px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.9),
            rgba(142,45,226,.9)
        );

    border:
        1px solid
        rgba(255,255,255,.3);

    box-shadow:

        0 15px 35px
        rgba(0,0,0,.3),

        inset 0 1px 3px
        rgba(255,255,255,.5);
}


/* PROFESSIONAL HEADER UPGRADE */
.header {
    position: relative;
    overflow: hidden;
    background:
        linear-gradient(135deg, rgba(0,110,255,.96), rgba(94,35,220,.96), rgba(0,210,255,.88));
    background-size: 250% 250%;
    animation: headerGradient 8s ease infinite;
    border: 1px solid rgba(255,255,255,.38);
    box-shadow:
        0 18px 45px rgba(0,0,0,.38),
        inset 0 1px 4px rgba(255,255,255,.65);
}

.header::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(120deg, transparent 20%, rgba(255,255,255,.18), transparent 80%);
    transform: translateX(-100%);
    animation: headerShine 5s ease-in-out infinite;
    pointer-events: none;
}

.header > * {
    position: relative;
    z-index: 1;
}

.logo {
    width: 62px;
    height: 62px;
    border-radius: 18px;
    font-size: 29px;
    background: linear-gradient(145deg, rgba(255,255,255,.30), rgba(255,255,255,.10));
    border: 1px solid rgba(255,255,255,.35);
    box-shadow:
        0 8px 22px rgba(0,0,0,.25),
        inset 0 2px 6px rgba(255,255,255,.65);
    transition: .3s ease;
}

.logo:hover {
    transform: translateY(-3px) scale(1.04);
}

.brand h1 {
    font-size: 22px;
    letter-spacing: .3px;
}

.brand p {
    margin-top: 4px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.2px;
    color: rgba(255,255,255,.92);
}

.logout {
    padding: 12px 17px;
    border: 1px solid rgba(255,255,255,.28);
    background: linear-gradient(145deg, rgba(0,0,0,.28), rgba(255,255,255,.10));
    box-shadow: 0 8px 20px rgba(0,0,0,.25), inset 0 1px 3px rgba(255,255,255,.35);
}

@keyframes headerGradient {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

@keyframes headerShine {
    0%, 45% { transform: translateX(-100%); }
    70%, 100% { transform: translateX(100%); }
}

/* BRAND */

.brand {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 55px;

    height: 55px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 16px;

    font-size: 27px;

    background:
        rgba(255,255,255,.2);

    box-shadow:
        inset 0 1px 4px
        rgba(255,255,255,.5);
}

.brand h1 {

    font-size: 20px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.4);
}

.brand p {

    font-size: 10px;

    opacity: .8;
}


/* LOGOUT */

.logout {

    color: white;

    text-decoration: none;

    padding: 10px 15px;

    border-radius: 12px;

    font-size: 11px;

    font-weight: 900;

    background:
        rgba(0,0,0,.25);

    transition: .25s;
}

.logout:hover {

    transform:
        translateY(-2px);

    background:
        rgba(255,255,255,.2);
}


/* WELCOME */

.welcome {

    padding: 25px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    backdrop-filter:
        blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.welcome h2 {

    font-size: 25px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.45);
}

.welcome p {

    margin-top: 7px;
    font-size: 13px;
    opacity: .8;
}


/* STATISTICS */

.stats {
    display: grid;
grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 13px;
    width: 100%;
    margin-bottom: 20px;
    align-items: stretch;
}

.stat {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    width: 100%;
    min-width: 0;

    text-decoration: none;
    color: white;

    padding: 18px;
    text-align: center;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);

    transition: .3s;
}

.stat:hover {
    transform: translateY(-5px);
}

.stat-icon {
    font-size: 25px;
    margin-bottom: 6px;
}

.stat-number {
    font-size: 22px;
    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}

.stat-label {
    margin-top: 4px;
    font-size: 10px;
    opacity: .75;
}


/* SECTION */

.section {

    padding: 20px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    backdrop-filter:
        blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.section h3 {

    margin-bottom: 15px;

    font-size: 18px;

    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}


/* DRIVER CARD */

.driver-card {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding: 16px;

    margin-bottom: 10px;

    border-radius: 17px;

    background:
        linear-gradient(
            135deg,
            rgba(0,198,255,.2),
            rgba(123,44,255,.18)
        );

    border:
        1px solid
        rgba(255,255,255,.2);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,.2);

    animation:
        cardEnter .5s ease;
}

.driver-info {

    flex: 1;

    font-size: 12px;

    line-height: 1.8;
}

.driver-name {

    font-size: 15px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}


/* BUTTON */

.verify-btn {

    padding: 11px 16px;

    border: none;

    border-radius: 11px;

    color: white;

    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            90deg,
            #00a86b,
            #00d4ff
        );

    box-shadow:
        0 7px 16px
        rgba(0,0,0,.25);

    transition: .25s;
}

.verify-btn:active {

    transform:
        scale(.95);
}


/* VERIFIED */

.verified {

    padding: 8px 12px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 900;

    background:
        rgba(0,255,120,.18);

    color: #7cffb2;
}


/* UNVERIFIED */

.not-verified {

    padding: 8px 12px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 900;

    background:
        rgba(255,70,70,.2);

    color: #ff9999;
}


/* BOOKING */

.booking {

    padding: 15px;

    margin-bottom: 10px;

    border-radius: 15px;

    background:
        rgba(255,255,255,.1);

    border:
        1px solid
        rgba(255,255,255,.18);

    font-size: 12px;

    line-height: 1.8;
}

.booking strong {

    font-size: 14px;

    font-weight: 900;
}

.status {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 20px;

    background:
        rgba(0,0,0,.2);

    font-size: 10px;

    font-weight: 900;
}


/* EMPTY */

.empty {

    padding: 25px;

    text-align: center;

    font-size: 13px;

    opacity: .7;
}


/* ANIMATIONS */

@keyframes backgroundMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

@keyframes pageEnter {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes cardEnter {

    from {
        opacity: 0;
        transform: translateY(15px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}


/* MOBILE */

@media(max-width:650px) {

    .stats {

        grid-template-columns:
            repeat(3, 1fr);

    }

    .stat {

        padding: 12px 5px;

    }

    .stat-number {

        font-size: 17px;

    }

    .driver-card {

        flex-direction: column;

        align-items: stretch;

    }

    .verify-btn {

        width: 100%;

    }

    .header h1 {

        font-size: 16px;

    }

    .welcome h2 {

        font-size: 21px;

    }

}
/* APPEARANCE MODES */

body.light {
    background: #f4f7fb;
    color: #222;
}

body.dark {
    background: #111827;
    color: white;
}

body.gradient {
    background:
        radial-gradient(circle at 5% 5%, #00e5ff, transparent 28%),
        radial-gradient(circle at 95% 95%, #e100ff, transparent 30%),
        linear-gradient(135deg, #071952, #088395, #5700b3);

    background-size: 200% 200%;
    animation: backgroundMove 12s ease infinite;
}

.about-btn {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 14px;

    color: white;
    font-size: 14px;
    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    background-size: 200%;

    box-shadow:
        0 8px 18px
        rgba(0,0,0,.25);

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);

    animation:
        buttonGradient 4s linear infinite;

    transition: .25s;
}

.about-btn:active {
    transform: scale(.95);
}
.about-modal {
    display:none;
    position:fixed;
    inset:0;
    z-index:99999;
    background:
        radial-gradient(circle at 10% 10%, rgba(0,110,255,.35), transparent 35%),
        radial-gradient(circle at 90% 90%, rgba(224,0,255,.35), transparent 35%),
        rgba(3,8,25,.88);
    padding:10px;
    align-items:center;
    justify-content:center;
    overflow-y:auto;
    backdrop-filter:blur(8px);
}
.about-modal.active { display:flex; }

.about-box {
    position:relative;
    width:100%;
    max-width:700px;
    max-height:92vh;
    padding:24px 18px 28px;
    border-radius:24px;
    background:linear-gradient(135deg,#071952,#0b5ed7,#4b20c9,#8b1fd1);
    background-size:300% 300%;
    animation:aboutGradient 10s ease infinite;
    color:white;
    border:1px solid rgba(255,255,255,.25);
    box-shadow:0 25px 70px rgba(0,0,0,.75);
    overflow-y:auto;
    scroll-behavior:smooth;
}

@keyframes aboutGradient {
    0% { background-position:0% 50%; }
    50% { background-position:100% 50%; }
    100% { background-position:0% 50%; }
}

.about-close {
    position:absolute;
    top:12px;
    right:12px;
    width:44px;
    height:44px;
    border:none;
    border-radius:50%;
    background:rgba(255,255,255,.18);
    color:white;
    font-size:24px;
    font-weight:bold;
    cursor:pointer;
    z-index:5;
    transition:.25s;
}
.about-close:hover {
    transform:rotate(90deg) scale(1.08);
    background:rgba(255,255,255,.3);
}

.about-welcome {
    text-align:center;
    padding:8px 48px 22px 8px;
    border-bottom:1px solid rgba(255,255,255,.25);
    margin-bottom:20px;
}

.about-welcome-title {
    margin:0 auto 12px;
    font-size:30px;
    line-height:1.3;
    font-weight:900;
    text-shadow:0 3px 12px rgba(0,0,0,.45);
    animation:welcomeAppear 1s ease-out,welcomeGlow 2.5s ease-in-out infinite alternate;
}

.about-welcome-text {
    margin:0 auto;
    font-size:17px;
    line-height:1.6;
    font-weight:600;
    color:rgba(255,255,255,.96);
    animation:welcomeAppear 1.4s ease-out;
}

@keyframes welcomeAppear {
    from { opacity:0; transform:translateY(-18px); }
    to { opacity:1; transform:translateY(0); }
}

@keyframes welcomeGlow {
    from { text-shadow:0 3px 12px rgba(0,0,0,.45); }
    to { text-shadow:0 0 10px rgba(255,255,255,.7),0 0 25px rgba(0,200,255,.5); }
}

.about-box h2 {
    margin:0 55px 10px 0;
    font-size:25px;
    line-height:1.3;
    font-weight:900;
}

.about-box h3 {
    margin-top:20px;
    margin-bottom:7px;
    font-size:19px;
    line-height:1.35;
    font-weight:900;
}

.about-box p {
    margin:7px 0;
    font-size:16px;
    line-height:1.65;
    font-weight:500;
}

.about-subtitle {
    margin-bottom:15px !important;
    font-size:17px !important;
    font-weight:700 !important;
}

.about-box ul {
    margin:8px 0 12px;
    padding-left:25px;
}

.about-box li {
    margin-bottom:7px;
    font-size:16px;
    line-height:1.55;
    font-weight:500;
}

.about-thankyou {
    margin-top:28px;
    padding:22px 15px;
    text-align:center;
    border-radius:18px;
    background:linear-gradient(135deg,rgba(0,110,255,.4),rgba(224,0,255,.4));
    border:1px solid rgba(255,255,255,.25);
    box-shadow:0 10px 30px rgba(0,0,0,.3);
}

.about-thankyou-title {
    margin:0 0 12px !important;
    font-size:32px !important;
    line-height:1.3 !important;
    font-weight:900 !important;
    text-align:center;
    animation:thankYouPulse 1.8s ease-in-out infinite;
    text-shadow:0 0 10px rgba(255,255,255,.6),0 4px 12px rgba(0,0,0,.45);
}

.about-contact {
    font-size:17px !important;
    line-height:1.6 !important;
    font-weight:600 !important;
    text-align:center;
    margin:0 !important;
}

@keyframes thankYouPulse {
    0%,100% { transform:scale(1); opacity:1; }
    50% { transform:scale(1.06); opacity:.88; }
}

.about-tagline {
    margin-top:18px;
    padding:14px;
    text-align:center;
    font-size:16px;
    line-height:1.5;
    font-weight:800;
    border-radius:14px;
    background:rgba(255,255,255,.1);
    border:1px solid rgba(255,255,255,.18);
}

@media (max-width:600px) {
    .about-modal { padding:8px; }
    .about-box { max-height:92vh; padding:22px 15px 25px; border-radius:22px; }
    .about-welcome { padding:8px 42px 20px 5px; }
    .about-welcome-title { font-size:25px; }
    .about-welcome-text { font-size:16px; }
    .about-box h2 { font-size:23px; }
    .about-box h3 { font-size:18px; }
    .about-box p { font-size:16px; line-height:1.65; }
    .about-box li { font-size:16px; line-height:1.55; }
    .about-thankyou-title { font-size:30px !important; }
    .about-contact { font-size:16px !important; }
    .about-tagline { font-size:15px; }
}

/* =====================================================
   PRO GUI — SLIDE-IN ADMIN MENU
===================================================== */

.admin-menu-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,20,0.45);
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.3s ease, visibility 0.3s ease;
    z-index: 9998;
}

.admin-slide-menu {
    position: fixed;
    top: 0;
    right: 0;
    width: min(360px, 88vw);
    height: 100vh;
    padding: 22px;
    background:
        linear-gradient(
            145deg,
            rgba(7,20,47,0.98),
            rgba(40,16,92,0.98),
            rgba(0,75,120,0.97)
        );
    border-left: 1px solid rgba(255,255,255,0.25);
    box-shadow: -20px 0 60px rgba(0,0,0,0.35);
    backdrop-filter: blur(25px);
    -webkit-backdrop-filter: blur(25px);
    transform: translateX(105%);
    transition: transform 0.35s cubic-bezier(.22,1,.36,1);
    z-index: 9999;
    overflow-y: auto;
}

.admin-slide-menu.active {
    transform: translateX(0);
}

.admin-menu-overlay.active {
    opacity: 1;
    visibility: visible;
}

.admin-slide-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding-bottom: 20px;
    margin-bottom: 18px;
    border-bottom: 1px solid rgba(255,255,255,0.18);
}

.admin-slide-header strong {
    display: block;
    font-size: 20px;
    font-weight: 900;
    letter-spacing: 0.8px;
}

.admin-slide-header span {
    display: block;
    margin-top: 5px;
    font-size: 11px;
    opacity: 0.7;
}

.admin-menu-close {
    width: 44px;
    height: 44px;
    border: 1px solid rgba(255,255,255,0.3);
    border-radius: 14px;
    background: rgba(255,255,255,0.12);
    color: white;
    font-size: 28px;
    line-height: 1;
    cursor: pointer;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.25);
}

.admin-slide-links {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.admin-slide-links a {
    display: flex;
    align-items: center;
    min-height: 50px;
    padding: 13px 15px;
    border-radius: 16px;
    color: white;
    text-decoration: none;
    font-size: 14px;
    font-weight: 800;
    border: 1px solid rgba(255,255,255,0.15);
    background: rgba(255,255,255,0.08);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.12);
    transition: transform 0.2s ease, background 0.2s ease;
}

.admin-slide-links a:hover {
    transform: translateX(-4px);
    background:
        linear-gradient(
            90deg,
            rgba(0,207,255,0.20),
            rgba(106,0,255,0.25)
        );
}

@media (max-width: 480px) {
    .admin-slide-menu {
        width: 92vw;
        padding: 18px;
    }
}


/* =====================================================
   MOBILE SLIDE MENU — FINAL PROPORTIONS
===================================================== */

@media (max-width: 600px) {

    .admin-slide-menu {
        width: 82vw;
        max-width: 330px;
        padding: 18px;
        border-left: 1px solid rgba(255,255,255,0.25);
        box-shadow: -15px 0 45px rgba(0,0,0,0.45);
    }

    .admin-menu-overlay {
        background: rgba(3,8,25,0.38);
        backdrop-filter: blur(3px);
        -webkit-backdrop-filter: blur(3px);
    }

    .admin-slide-header {
        padding-bottom: 16px;
        margin-bottom: 16px;
    }

    .admin-slide-header strong {
        font-size: 18px;
    }

    .admin-slide-header span {
        font-size: 10px;
    }

    .admin-menu-close {
        width: 42px;
        height: 42px;
        border-radius: 13px;
        font-size: 25px;
    }

    .admin-slide-links {
        gap: 9px;
    }

    .admin-slide-links a {
        min-height: 48px;
        padding: 12px 14px;
        border-radius: 14px;
        font-size: 13px;
    }

    .admin-slide-links a:active {
        transform: scale(0.97);
    }
}

</style>

<style>
/* =====================================================
   GLOSSY GLOWING MESSAGES BUTTON
===================================================== */

.admin-messages-button {
    margin: 22px 0;
}

.admin-messages-button a {
    position: relative;

    display: flex;
    align-items: center;
    justify-content: center;

    width: 100%;
    min-height: 72px;

    padding: 18px 24px;

    border-radius: 22px;

    text-decoration: none;

    color: #ffffff;

    font-size: 18px;
    font-weight: 900;
    letter-spacing: .7px;

    background:
        linear-gradient(
            145deg,
            rgba(0, 234, 255, .95),
            rgba(0, 140, 255, .92) 45%,
            rgba(123, 44, 255, .96)
        );

    border: 1px solid rgba(255,255,255,.45);

    box-shadow:
        0 8px 18px rgba(0, 0, 0, .30),
        0 0 18px rgba(0, 234, 255, .45),
        0 0 38px rgba(123, 44, 255, .35);

    overflow: hidden;

    transition:
        transform .25s ease,
        box-shadow .25s ease;
}

/* Glossy highlight */
.admin-messages-button a::before {
    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 48%;

    background:
        linear-gradient(
            180deg,
            rgba(255,255,255,.48),
            rgba(255,255,255,.08),
            transparent
        );

    border-radius: 22px 22px 50% 50%;

    pointer-events: none;
}

/* Shine effect */
.admin-messages-button a::after {
    content: "";

    position: absolute;

    top: -80%;
    left: -35%;

    width: 35%;
    height: 260%;

    background:
        linear-gradient(
            90deg,
            transparent,
            rgba(255,255,255,.55),
            transparent
        );

    transform: rotate(25deg);

    animation: messageButtonShine 4s ease-in-out infinite;

    pointer-events: none;
}

.admin-messages-button a:hover {
    transform: translateY(-4px) scale(1.01);

    box-shadow:
        0 12px 25px rgba(0,0,0,.35),
        0 0 25px rgba(0,234,255,.70),
        0 0 55px rgba(123,44,255,.60);
}

.admin-messages-button a:active {
    transform: translateY(1px) scale(.99);
}

@keyframes messageButtonShine {

    0% {
        left: -40%;
    }

    45%,
    100% {
        left: 120%;
    }

}
</style>


<style>
.admin-management-button {
    width: 100%;
    margin: 22px 0;
}

.admin-management-button a {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;

    width: 100%;
    min-height: 72px;
    padding: 18px 24px;

    border-radius: 22px;
    text-decoration: none;

    color: #ffffff;
    font-size: 18px;
    font-weight: 900;
    letter-spacing: .7px;

    background:
        linear-gradient(
            145deg,
            rgba(123,44,255,.98),
            rgba(0,140,255,.94) 48%,
            rgba(0,234,255,.96)
        );

    border: 1px solid rgba(255,255,255,.48);

    box-shadow:
        0 8px 18px rgba(0,0,0,.30),
        0 0 18px rgba(123,44,255,.50),
        0 0 40px rgba(0,234,255,.35);

    overflow: hidden;

    transition:
        transform .25s ease,
        box-shadow .25s ease;
}

.admin-management-button a::before {
    content: "";
    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 48%;

    background:
        linear-gradient(
            180deg,
            rgba(255,255,255,.50),
            rgba(255,255,255,.10),
            transparent
        );

    border-radius: 22px 22px 50% 50%;
    pointer-events: none;
}

.admin-management-button a::after {
    content: "";

    position: absolute;
    top: -80%;
    left: -40%;

    width: 35%;
    height: 260%;

    background:
        linear-gradient(
            90deg,
            transparent,
            rgba(255,255,255,.58),
            transparent
        );

    transform: rotate(25deg);

    animation:
        adminManagementShine 4s ease-in-out infinite;

    pointer-events: none;
}

.admin-management-button a:hover {
    transform: translateY(-4px) scale(1.01);

    box-shadow:
        0 12px 25px rgba(0,0,0,.35),
        0 0 28px rgba(123,44,255,.75),
        0 0 58px rgba(0,234,255,.60);
}

.admin-management-button a:active {
    transform: translateY(1px) scale(.99);
}

@keyframes adminManagementShine {
    0% {
        left: -40%;
    }

    45%, 100% {
        left: 120%;
    }
}
</style>


<style>
.admin-map-button {
    width: 100%;
    margin: 22px 0;
}

.admin-map-button a {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;

    width: 100%;
    min-height: 72px;
    padding: 18px 24px;

    border-radius: 22px;
    text-decoration: none;

    color: #ffffff;
    font-size: 18px;
    font-weight: 900;
    letter-spacing: .7px;

    background:
        linear-gradient(
            145deg,
            rgba(0, 234, 255, .96),
            rgba(0, 140, 255, .94) 45%,
            rgba(123, 44, 255, .98)
        );

    border: 1px solid rgba(255,255,255,.48);

    box-shadow:
        0 8px 18px rgba(0,0,0,.30),
        0 0 20px rgba(0,234,255,.48),
        0 0 42px rgba(123,44,255,.38);

    overflow: hidden;

    transition:
        transform .25s ease,
        box-shadow .25s ease;
}

.admin-map-button a::before {
    content: "";
    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 48%;

    background:
        linear-gradient(
            180deg,
            rgba(255,255,255,.50),
            rgba(255,255,255,.10),
            transparent
        );

    border-radius: 22px 22px 50% 50%;
    pointer-events: none;
}

.admin-map-button a::after {
    content: "";

    position: absolute;
    top: -80%;
    left: -40%;

    width: 35%;
    height: 260%;

    background:
        linear-gradient(
            90deg,
            transparent,
            rgba(255,255,255,.58),
            transparent
        );

    transform: rotate(25deg);

    animation:
        adminMapShine 4s ease-in-out infinite;

    pointer-events: none;
}

.admin-map-button a:hover {
    transform: translateY(-4px) scale(1.01);

    box-shadow:
        0 12px 25px rgba(0,0,0,.35),
        0 0 28px rgba(0,234,255,.75),
        0 0 58px rgba(123,44,255,.62);
}

.admin-map-button a:active {
    transform: translateY(1px) scale(.99);
}

@keyframes adminMapShine {
    0% {
        left: -40%;
    }

    45%, 100% {
        left: 120%;
    }
}
/* =====================================================
   PRO GUI — ADMIN CONTENT CARDS
===================================================== */
.card,
.panel,
.admin-card,
.content-card {
    position: relative !important;
    overflow: hidden !important;
    border-radius: 24px !important;
    border: 1px solid rgba(255,255,255,0.22) !important;
    background: linear-gradient(145deg, rgba(255,255,255,0.12), rgba(45,30,150,0.20), rgba(0,180,255,0.08)) !important;
    backdrop-filter: blur(18px) !important;
    -webkit-backdrop-filter: blur(18px) !important;
    box-shadow: 0 18px 45px rgba(0,0,0,0.20), inset 0 1px 0 rgba(255,255,255,0.22) !important;
}

.card::before,
.panel::before,
.admin-card::before,
.content-card::before {
    content: "" !important;
    position: absolute !important;
    top: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 1px !important;
    background: rgba(255,255,255,0.35) !important;
    pointer-events: none !important;
}

.card h2,
.card h3,
.panel h2,
.panel h3,
.admin-card h2,
.admin-card h3,
.content-card h2,
.content-card h3 {
    position: relative !important;
    z-index: 2 !important;
    font-weight: 900 !important;
}

.card:hover,
.panel:hover,
.admin-card:hover,
.content-card:hover {
    box-shadow: 0 22px 52px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.30) !important;
}

/* =====================================================
   PRO GUI — ADMIN NAVIGATION
===================================================== */
.nav,
.navigation,
.admin-nav,
.menu,
.menu-container {
    border-radius: 22px !important;
    border: 1px solid rgba(255,255,255,0.20) !important;
    background: rgba(255,255,255,0.08) !important;
    backdrop-filter: blur(18px) !important;
    -webkit-backdrop-filter: blur(18px) !important;
    box-shadow: 0 15px 40px rgba(0,0,0,0.20), inset 0 1px 0 rgba(255,255,255,0.18) !important;
}

.nav a,
.navigation a,
.admin-nav a,
.menu a,
.menu-container a {
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
    min-height: 46px !important;
    padding: 11px 15px !important;
    border-radius: 14px !important;
    color: inherit !important;
    font-weight: 800 !important;
    text-decoration: none !important;
    transition: transform 0.2s ease, background 0.2s ease, box-shadow 0.2s ease !important;
}

.nav a:hover,
.navigation a:hover,
.admin-nav a:hover,
.menu a:hover,
.menu-container a:hover {
    transform: translateX(4px) !important;
    background: linear-gradient(90deg, rgba(0,207,255,0.18), rgba(106,0,255,0.20)) !important;
    box-shadow: 0 8px 22px rgba(0,0,0,0.16) !important;
}

@media (max-width: 768px) {
    .nav,
    .navigation,
    .admin-nav,
    .menu,
    .menu-container {
        border-radius: 18px !important;
    }
}

/* =====================================================
   PRO GUI — GLASS DASHBOARD SURFACE
===================================================== */
.dashboard {
    position: relative !important;
    isolation: isolate !important;
    padding: 24px !important;
    border-radius: 30px !important;
    background: rgba(255,255,255,0.055) !important;
    border: 1px solid rgba(255,255,255,0.16) !important;
    box-shadow: 0 25px 70px rgba(0,0,0,0.24), inset 0 1px 0 rgba(255,255,255,0.12) !important;
    backdrop-filter: blur(12px) !important;
    -webkit-backdrop-filter: blur(12px) !important;
}

.dashboard::before {
    content: "" !important;
    position: absolute !important;
    inset: 0 !important;
    border-radius: inherit !important;
    pointer-events: none !important;
    background: linear-gradient(135deg, rgba(255,255,255,0.08), transparent 35%, rgba(0,207,255,0.035)) !important;
    z-index: -1 !important;
}

@media (max-width: 768px) {
    .dashboard {
        padding: 14px !important;
        border-radius: 24px !important;
    }
}

/* =====================================================
   PRO GUI — ADMIN PREMIUM BACKGROUND
===================================================== */
body {
    position: relative !important;
    min-height: 100vh !important;
    background:
        radial-gradient(circle at 10% 10%, rgba(0,207,255,0.28), transparent 30%),
        radial-gradient(circle at 90% 15%, rgba(106,0,255,0.30), transparent 32%),
        radial-gradient(circle at 50% 100%, rgba(0,110,255,0.25), transparent 35%),
        linear-gradient(135deg, #07142f 0%, #111b4f 38%, #24105c 68%, #061d3d 100%) !important;
    background-attachment: fixed !important;
}

body::before {
    content: "" !important;
    position: fixed !important;
    inset: 0 !important;
    pointer-events: none !important;
    z-index: -1 !important;
    background:
        radial-gradient(circle at 20% 35%, rgba(0,207,255,0.12), transparent 22%),
        radial-gradient(circle at 80% 65%, rgba(165,80,255,0.12), transparent 25%);
    animation: proBackgroundGlow 10s ease-in-out infinite alternate !important;
}

body::after {
    content: "" !important;
    position: fixed !important;
    inset: 0 !important;
    pointer-events: none !important;
    z-index: -1 !important;
    background: linear-gradient(120deg, transparent 0%, rgba(255,255,255,0.025) 50%, transparent 100%) !important;
    background-size: 220% 220% !important;
    animation: proBackgroundSweep 14s linear infinite !important;
}

@keyframes proBackgroundGlow {
    from { transform: scale(1); opacity: 0.75; }
    to { transform: scale(1.12); opacity: 1; }
}

@keyframes proBackgroundSweep {
    from { background-position: 0% 50%; }
    to { background-position: 200% 50%; }
}

/* =====================================================
   PRO UI — SPACING & VISUAL RHYTHM
===================================================== */
.dashboard > * {
    margin-bottom: 18px !important;
}

.dashboard h1,
.dashboard h2,
.dashboard h3 {
    line-height: 1.25 !important;
}

.dashboard p {
    line-height: 1.55 !important;
}

.stat,
.driver-card,
.booking-card {
    margin-bottom: 16px !important;
}

.stat,
.driver-card,
.booking-card,
.section,
.dashboard-section,
.admin-section {
    box-sizing: border-box !important;
}

@media (max-width: 480px) {
    .dashboard {
        padding: 10px !important;
    }

    .header {
        margin-bottom: 14px !important;
    }

    .stat {
        padding: 14px !important;
    }

    .driver-card,
    .booking-card {
        padding: 16px !important;
    }
}

/* =====================================================
   PRO UI — BUTTON TOUCH FEEDBACK
===================================================== */
button,
a.admin-button,
.admin-management-button a,
.admin-map-button a {
    -webkit-tap-highlight-color: transparent !important;
    cursor: pointer !important;
}

button:active,
.admin-management-button a:active,
.admin-map-button a:active {
    transform: scale(0.97) !important;
    box-shadow: 0 5px 12px rgba(0,0,0,0.20) !important;
}

button:focus-visible,
.admin-management-button a:focus-visible,
.admin-map-button a:focus-visible {
    outline: 3px solid rgba(0,207,255,0.65) !important;
    outline-offset: 3px !important;
}

button:disabled {
    opacity: 0.55 !important;
    cursor: not-allowed !important;
    transform: none !important;
}

/* =====================================================
   PRO UI — BUTTON TOUCH FEEDBACK
===================================================== */
button,
a.admin-button,
.admin-management-button a,
.admin-map-button a {
    -webkit-tap-highlight-color: transparent !important;
    cursor: pointer !important;
}

button:active,
.admin-management-button a:active,
.admin-map-button a:active {
    transform: scale(0.97) !important;
    box-shadow: 0 5px 12px rgba(0,0,0,0.20) !important;
}

button:focus-visible,
.admin-management-button a:focus-visible,
.admin-map-button a:focus-visible {
    outline: 3px solid rgba(0,207,255,0.65) !important;
    outline-offset: 3px !important;
}

button:disabled {
    opacity: 0.55 !important;
    cursor: not-allowed !important;
    transform: none !important;
}

/* =====================================================
   PRO UI — RESPONSIVE ADMIN DASHBOARD
===================================================== */
@media (max-width: 768px) {
    .dashboard {
        width: 100% !important;
        max-width: 100% !important;
        padding: 12px !important;
    }

    .header {
        padding: 14px !important;
        border-radius: 20px !important;
        gap: 12px !important;
    }

    .brand {
        min-width: 0 !important;
    }

    .logo {
        width: 52px !important;
        height: 52px !important;
        flex-shrink: 0 !important;
    }

    .brand h1 {
        font-size: 18px !important;
    }

    .brand p {
        font-size: 9px !important;
    }

    .logout {
        padding: 10px 12px !important;
        font-size: 11px !important;
        white-space: nowrap !important;
    }

    .stat {
        min-width: 0 !important;
        padding: 15px !important;
        border-radius: 18px !important;
    }

    .stat strong {
        font-size: 26px !important;
    }

    .stat span {
        font-size: 11px !important;
    }

    .driver-card,
    .booking-card,
    .section,
    .dashboard-section,
    .admin-section {
        border-radius: 20px !important;
    }

    .section h2,
    .dashboard-section h2,
    .admin-section h2 {
        font-size: 19px !important;
    }

    button,
    .admin-management-button a,
    .admin-map-button a {
        min-height: 44px !important;
    }
}

@media (min-width: 769px) {
    .dashboard {
        max-width: 1180px !important;
        margin: 0 auto !important;
    }
}

/* =====================================================
   PRO UI — STATUS BADGES
===================================================== */
.status-badge,
.badge,
.status {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    min-width: 90px !important;
    padding: 7px 14px !important;
    border-radius: 999px !important;
    font-size: 12px !important;
    font-weight: 900 !important;
    letter-spacing: 0.5px !important;
    border: 1px solid rgba(255,255,255,0.30) !important;
    box-shadow: 0 5px 14px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.30) !important;
    backdrop-filter: blur(8px) !important;
    -webkit-backdrop-filter: blur(8px) !important;
    transition: transform 0.2s ease, box-shadow 0.2s ease !important;
}

.status-badge:hover,
.badge:hover,
.status:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 18px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.40) !important;
}

/* =====================================================
   PRO UI — ADMIN SECTION CONTAINERS
===================================================== */
.section,
.dashboard-section,
.admin-section {
    position: relative !important;
    border-radius: 24px !important;
    border: 1px solid rgba(255,255,255,0.25) !important;
    background: linear-gradient(145deg, rgba(255,255,255,0.13), rgba(55,35,180,0.20)) !important;
    backdrop-filter: blur(15px) !important;
    -webkit-backdrop-filter: blur(15px) !important;
    box-shadow: 0 14px 35px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.25) !important;
}

.section h2,
.dashboard-section h2,
.admin-section h2 {
    font-size: 22px !important;
    font-weight: 900 !important;
    letter-spacing: 0.4px !important;
    text-shadow: 0 3px 10px rgba(0,0,0,0.20) !important;
}

.section h2::after,
.dashboard-section h2::after,
.admin-section h2::after {
    content: "" !important;
    display: block !important;
    width: 55px !important;
    height: 4px !important;
    margin-top: 8px !important;
    border-radius: 99px !important;
    background: linear-gradient(90deg, #00cfff, #6a00ff) !important;
    box-shadow: 0 0 12px rgba(0,207,255,0.55) !important;
}

/* =====================================================
   PRO UI — ADMIN NAVIGATION & ACTION BUTTONS
===================================================== */
.admin-management-button,
.admin-map-button,
.admin-action-button {
    position: relative !important;
    overflow: hidden !important;
    border-radius: 18px !important;
    border: 1px solid rgba(255,255,255,0.30) !important;
    background: linear-gradient(135deg, rgba(0,110,255,0.90), rgba(106,0,255,0.90), rgba(0,207,255,0.82)) !important;
    box-shadow: 0 12px 30px rgba(0,0,0,0.22), inset 0 1px 0 rgba(255,255,255,0.35) !important;
    transition: transform 0.22s ease, box-shadow 0.22s ease !important;
}

.admin-management-button::before,
.admin-map-button::before,
.admin-action-button::before {
    content: "" !important;
    position: absolute !important;
    top: 0 !important;
    left: -120% !important;
    width: 70% !important;
    height: 100% !important;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.30), transparent) !important;
    transform: skewX(-20deg) !important;
    transition: left 0.6s ease !important;
}

.admin-management-button:hover::before,
.admin-map-button:hover::before,
.admin-action-button:hover::before {
    left: 140% !important;
}

.admin-management-button:hover,
.admin-map-button:hover,
.admin-action-button:hover {
    transform: translateY(-3px) !important;
    box-shadow: 0 18px 38px rgba(0,0,0,0.30), inset 0 1px 0 rgba(255,255,255,0.45) !important;
}

.admin-management-button a,
.admin-map-button a,
.admin-action-button a,
.admin-management-button button,
.admin-map-button button,
.admin-action-button button {
    position: relative !important;
    z-index: 2 !important;
    font-weight: 900 !important;
    letter-spacing: 0.4px !important;
}

/* =====================================================
   PRO UI — BOOKING MANAGEMENT
===================================================== */
.booking-card {
    position: relative !important;
    overflow: hidden !important;
    border-radius: 22px !important;
    border: 1px solid rgba(255,255,255,0.28) !important;
    background: linear-gradient(145deg, rgba(0,110,255,0.16), rgba(106,0,255,0.22), rgba(0,207,255,0.14)) !important;
    backdrop-filter: blur(16px) !important;
    -webkit-backdrop-filter: blur(16px) !important;
    box-shadow: 0 14px 35px rgba(0,0,0,0.20), inset 0 1px 0 rgba(255,255,255,0.30) !important;
    transition: transform 0.25s ease, box-shadow 0.25s ease !important;
}

.booking-card::before {
    content: "" !important;
    position: absolute !important;
    top: -60px !important;
    right: -60px !important;
    width: 150px !important;
    height: 150px !important;
    border-radius: 50% !important;
    background: rgba(255,255,255,0.12) !important;
}

.booking-card:hover {
    transform: translateY(-4px) !important;
    box-shadow: 0 20px 42px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.40) !important;
}

.booking-card strong {
    position: relative !important;
    z-index: 2 !important;
    font-weight: 900 !important;
}

.booking-card .status,
.booking-card .badge {
    position: relative !important;
    z-index: 3 !important;
    border-radius: 999px !important;
    font-weight: 800 !important;
    padding: 6px 12px !important;
}

.booking-card button {
    position: relative !important;
    z-index: 3 !important;
    border-radius: 14px !important;
    font-weight: 800 !important;
    transition: transform 0.2s ease, box-shadow 0.2s ease !important;
}

.booking-card button:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 18px rgba(0,0,0,0.22) !important;
}

/* =====================================================
   PRO UI — DRIVER MANAGEMENT CARDS
===================================================== */
.driver-card {
    position: relative !important;
    overflow: hidden !important;
    border-radius: 24px !important;
    border: 1px solid rgba(255,255,255,0.28) !important;
    background: linear-gradient(145deg, rgba(255,255,255,0.18), rgba(90,70,220,0.28)) !important;
    backdrop-filter: blur(18px) !important;
    -webkit-backdrop-filter: blur(18px) !important;
    box-shadow: 0 15px 40px rgba(0,0,0,0.22), inset 0 1px 0 rgba(255,255,255,0.35) !important;
    transition: transform 0.25s ease, box-shadow 0.25s ease !important;
}

.driver-card::before {
    content: "" !important;
    position: absolute !important;
    top: -70px !important;
    right: -70px !important;
    width: 170px !important;
    height: 170px !important;
    border-radius: 50% !important;
    background: rgba(0,207,255,0.16) !important;
}

.driver-card:hover {
    transform: translateY(-5px) !important;
    box-shadow: 0 22px 48px rgba(0,0,0,0.30), inset 0 1px 0 rgba(255,255,255,0.45) !important;
}

.driver-card h3 {
    position: relative !important;
    z-index: 2 !important;
    font-size: 20px !important;
    font-weight: 900 !important;
    margin-bottom: 8px !important;
}

.driver-card p {
    position: relative !important;
    z-index: 2 !important;
    font-size: 14px !important;
    line-height: 1.6 !important;
}

.driver-card button,
.driver-card a {
    position: relative !important;
    z-index: 3 !important;
    border-radius: 14px !important;
    font-weight: 800 !important;
    transition: transform 0.2s ease, box-shadow 0.2s ease !important;
}

.driver-card button:hover,
.driver-card a:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 20px rgba(0,0,0,0.22) !important;
}

/* =====================================================
   PRO UI — ADMIN STATISTICS CARDS
===================================================== */
.stat {
    position: relative !important;
    overflow: hidden !important;
    border: 1px solid rgba(255,255,255,0.30) !important;
    border-radius: 22px !important;
    background: linear-gradient(145deg, rgba(0,110,255,0.92), rgba(106,0,255,0.90), rgba(0,207,255,0.82)) !important;
    box-shadow: 0 14px 35px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.35) !important;
    transform: translateY(0) !important;
    transition: transform 0.25s ease, box-shadow 0.25s ease !important;
}

.stat::before {
    content: "" !important;
    position: absolute !important;
    top: -80px !important;
    right: -60px !important;
    width: 180px !important;
    height: 180px !important;
    border-radius: 50% !important;
    background: rgba(255,255,255,0.16) !important;
    filter: blur(2px) !important;
}

.stat::after {
    content: "" !important;
    position: absolute !important;
    left: -120px !important;
    bottom: -90px !important;
    width: 260px !important;
    height: 140px !important;
    background: rgba(255,255,255,0.10) !important;
    transform: rotate(-18deg) !important;
}

.stat:hover {
    transform: translateY(-6px) scale(1.015) !important;
    box-shadow: 0 20px 45px rgba(0,0,0,0.32), inset 0 1px 0 rgba(255,255,255,0.45) !important;
}

.stat * {
    position: relative !important;
    z-index: 2 !important;
}

.stat strong {
    font-size: 32px !important;
    font-weight: 900 !important;
    text-shadow: 0 3px 10px rgba(0,0,0,0.25) !important;
}

.stat span {
    font-size: 14px !important;
    font-weight: 800 !important;
    letter-spacing: 0.7px !important;
    text-transform: uppercase !important;
}

/* =====================================================
   PROFESSIONAL ADMIN HEADER OVERRIDE
===================================================== */
.header {
    position: relative;
    overflow: hidden;
    background: linear-gradient(135deg, #006eff, #6a00ff, #00cfff) !important;
    background-size: 300% 300% !important;
    animation: adminHeaderGradient 8s ease infinite !important;
    border: 1px solid rgba(255,255,255,.45) !important;
    box-shadow: 0 18px 45px rgba(0,0,0,.40), inset 0 2px 5px rgba(255,255,255,.55) !important;
}

.header::before {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 60%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,.22), transparent);
    transform: skewX(-20deg);
    animation: adminHeaderShine 5s ease-in-out infinite;
    pointer-events: none;
}

.header > * {
    position: relative;
    z-index: 2;
}

.logo {
    width: 64px !important;
    height: 64px !important;
    border-radius: 18px !important;
    font-size: 30px !important;
    background: linear-gradient(145deg, rgba(255,255,255,.32), rgba(255,255,255,.10)) !important;
    border: 1px solid rgba(255,255,255,.40) !important;
    box-shadow: 0 10px 25px rgba(0,0,0,.28), inset 0 2px 6px rgba(255,255,255,.65) !important;
    transition: transform .3s ease, box-shadow .3s ease;
}

.logo:hover {
    transform: translateY(-4px) scale(1.05);
    box-shadow: 0 14px 30px rgba(0,0,0,.35), 0 0 25px rgba(0,234,255,.55), inset 0 2px 6px rgba(255,255,255,.7) !important;
}

.brand h1 {
    font-size: 22px !important;
    font-weight: 900 !important;
    letter-spacing: .4px;
    text-shadow: 0 3px 10px rgba(0,0,0,.45) !important;
}

.brand p {
    margin-top: 5px;
    font-size: 11px !important;
    font-weight: 800 !important;
    letter-spacing: 1.3px;
    color: rgba(255,255,255,.95);
}

.logout {
    border: 1px solid rgba(255,255,255,.35) !important;
    background: linear-gradient(145deg, rgba(0,0,0,.30), rgba(255,255,255,.12)) !important;
    box-shadow: 0 8px 20px rgba(0,0,0,.28), inset 0 1px 4px rgba(255,255,255,.35) !important;
}

@keyframes adminHeaderGradient {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

@keyframes adminHeaderShine {
    0% { left: -100%; }
    45%, 100% { left: 150%; }
}

</style>


<style>
/* =====================================================
   ADMIN MENU — REAL SLIDE-IN ANIMATION
===================================================== */

#adminSlideMenu {
    position: fixed !important;
    top: 0 !important;
    right: 0 !important;
    bottom: 0 !important;

    width: min(340px, 85vw) !important;
    height: 100vh !important;

    z-index: 99999 !important;

    transform: translate3d(105%, 0, 0) !important;
    visibility: hidden !important;

    transition:
        transform 0.45s cubic-bezier(0.22, 1, 0.36, 1),
        visibility 0s linear 0.45s !important;

    overflow-y: auto !important;
}

#adminSlideMenu.active {
    transform: translate3d(0, 0, 0) !important;
    visibility: visible !important;

    transition:
        transform 0.45s cubic-bezier(0.22, 1, 0.36, 1),
        visibility 0s linear 0s !important;
}

#adminMenuOverlay {
    position: fixed !important;
    inset: 0 !important;

    z-index: 99998 !important;

    opacity: 0 !important;
    visibility: hidden !important;

    transition:
        opacity 0.35s ease,
        visibility 0s linear 0.35s !important;
}

#adminMenuOverlay.active {
    opacity: 1 !important;
    visibility: visible !important;

    transition:
        opacity 0.35s ease,
        visibility 0s linear 0s !important;
}

#openAdminMenu {
    cursor: pointer !important;
    position: relative !important;
    z-index: 10 !important;
}

#adminSlideMenu .admin-menu-close {
    cursor: pointer !important;
}

@media (max-width: 600px) {

    #adminSlideMenu {
        width: 84vw !important;
        max-width: 340px !important;
    }

}
</style>


<style>
/* =====================================================
   FINAL MOBILE ADMIN SLIDE MENU
===================================================== */

#adminSlideMenu {
    position: fixed !important;
    top: 0 !important;
    right: 0 !important;
    bottom: 0 !important;

    width: 88vw !important;
    max-width: none !important;
    height: 100dvh !important;

    z-index: 2147483647 !important;

    transform: translate3d(105%, 0, 0) !important;
    visibility: hidden !important;

    transition:
        transform 0.45s cubic-bezier(0.22, 1, 0.36, 1),
        visibility 0s linear 0.45s !important;

    overflow-x: hidden !important;
    overflow-y: auto !important;

    -webkit-overflow-scrolling: touch;
}

#adminSlideMenu.active {
    transform: translate3d(0, 0, 0) !important;
    visibility: visible !important;

    transition:
        transform 0.45s cubic-bezier(0.22, 1, 0.36, 1),
        visibility 0s linear 0s !important;
}

#adminMenuOverlay {
    position: fixed !important;
    inset: 0 !important;

    z-index: 2147483646 !important;

    opacity: 0 !important;
    visibility: hidden !important;

    transition:
        opacity 0.35s ease,
        visibility 0s linear 0.35s !important;
}

#adminMenuOverlay.active {
    opacity: 1 !important;
    visibility: visible !important;

    transition:
        opacity 0.35s ease,
        visibility 0s linear 0s !important;
}

#adminSlideMenu .admin-slide-header {
    position: sticky;
    top: 0;
    z-index: 2;

    padding-top: max(18px, env(safe-area-inset-top));
    background: rgba(20, 15, 65, 0.96);
}

#adminSlideMenu .admin-slide-links {
    padding-bottom: 30px;
}

#adminSlideMenu .admin-slide-links a {
    width: 100%;
    min-height: 52px;
}

/* Mobile */
@media (max-width: 600px) {

    #adminSlideMenu {
        width: 88vw !important;
    }

}
</style>


<style>
/* =====================================================
   FINAL FIX — ADMIN DASHBOARD FULL WIDTH
===================================================== */

html,
body {
    width: 100% !important;
    min-width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
}

.dashboard {
    display: block !important;
    width: 100% !important;
    max-width: none !important;
    min-width: 0 !important;
    margin: 0 !important;
    padding: 12px !important;
}

@media (min-width: 769px) {
    .dashboard {
        width: 100% !important;
        max-width: 1180px !important;
        margin: 0 auto !important;
    }
}

@media (max-width: 768px) {
    .dashboard {
        width: 100vw !important;
        max-width: none !important;
        margin: 0 !important;
        padding: 12px !important;
    }
}
</style>


<style>
/* SMALL CIRCULAR TRANSCALLTATION HEADER ICON */
.header .logo {
    width: 58px !important;
    height: 58px !important;
    min-width: 58px !important;
    border-radius: 50% !important;
    overflow: hidden !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 0 !important;
}

.header .logo img {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    border-radius: 50% !important;
    display: block !important;
}
</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>
/* GLOWING SIDEBAR TEXT — ICONS UNCHANGED */
#adminSlideMenu a {
    text-shadow:
        0 0 5px rgba(120, 220, 255, 0.75),
        0 0 10px rgba(130, 100, 255, 0.55),
        0 0 18px rgba(170, 80, 255, 0.35) !important;
}

#adminSlideMenu a i {
    text-shadow: none !important;
}
</style>


<style>
/* SIDEBAR CIRCULAR LOGO */
#adminSlideMenu .admin-menu-logo {
    width: 54px !important;
    height: 54px !important;
    margin: 18px auto 20px !important;
    border-radius: 50% !important;
    overflow: hidden !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow:
        0 0 10px rgba(80, 210, 255, 0.65),
        0 0 20px rgba(130, 80, 255, 0.45) !important;
}

#adminSlideMenu .admin-menu-logo img {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    border-radius: 50% !important;
    display: block !important;
}

/* ONE-SPACE ICON + TEXT */
#adminSlideMenu a {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
}

/* KEEP ICONS NORMAL */
#adminSlideMenu a i {
    margin: 0 !important;
    text-shadow: none !important;
}

/* GLOW TEXT ONLY */
#adminSlideMenu a {
    text-shadow:
        0 0 5px rgba(100, 220, 255, 0.8),
        0 0 10px rgba(120, 100, 255, 0.65),
        0 0 18px rgba(180, 80, 255, 0.45) !important;
}

#adminSlideMenu a i {
    text-shadow: none !important;
}
</style>

</head>

<body class="<?php echo htmlspecialchars($appearance_class); ?>">


<!-- PRO SLIDE-IN ADMIN MENU -->

<div class="admin-menu-overlay" id="adminMenuOverlay"></div>

<aside class="admin-slide-menu" id="adminSlideMenu" aria-hidden="true">
<div class="admin-menu-logo">
    <img src="transcalltation_header_logo.png" alt="TransCalltation 2.0">
</div>

    <div class="admin-slide-header">
        <div>
            <strong>ADMIN MENU</strong>
            <span>TransCalltation 2.0</span>
        </div>

        <button type="button" class="admin-menu-close" id="closeAdminMenu">
            ×
        </button>
    </div>

    <nav class="admin-slide-links">

        <a href="admin_dashboard.php"><i class="fa-solid fa-house"></i> Dashboard</a>

        <a href="admin_drivers.php"><i class="fa-solid fa-motorcycle"></i> Drivers</a>

        <a href="admin_verified.php">✅ Verified Drivers</a>

        <a href="admin_bookings.php"><i class="fa-solid fa-clipboard-list"></i> Bookings</a>

        <a href="admin_map.php"><i class="fa-solid fa-map-location-dot"></i> Live Map</a>

        <a href="admin_management.php"><i class="fa-solid fa-user-gear"></i> Admin Management</a>

        <a href="messages.php"><i class="fa-solid fa-comments"></i> Messages & Complaints</a>

        <a href="settings.php"><i class="fa-solid fa-gear"></i> Settings</a>

    </nav>

</aside>

<div class="dashboard">


<!-- HEADER -->

<div class="header">

    <div class="brand">

        <div class="logo">
            <img src="transcalltation_header_logo.png"
                 alt="TransCalltation 2.0 Logo">
        </div>

        <div>

            <h1>
                TransCalltation 2.0
            </h1>

            <p>
                ADMIN CONTROL PANEL
            </p>

        </div>

    </div>

<button type="button" class="logout" id="openAdminMenu" aria-label="Open admin menu">
    ☰ MENU
</button>

</div>




<!-- WELCOME -->

<div class="welcome">

    <h2>

        Welcome,
        <?php
        echo htmlspecialchars(
            $admin["full_name"]
        );
        ?>! 👋

    </h2>

    <p>
        Manage drivers and monitor transportation bookings.
    </p>

</div>


<!-- STATISTICS -->

<div class="stats">
<a href="admin_drivers.php" class="stat">

        <div class="stat-icon">
            🛵
        </div>
        <div class="stat-number">
            <?php echo count($drivers); ?>
        </div>

        <div class="stat-label">
            TOTAL DRIVERS
        </div>

    </a>


    <a href="admin_verified.php" class="stat">

        <div class="stat-icon">
            🛡️
        </div>

        <div class="stat-number">

            <?php

            $verified = 0;

            foreach ($drivers as $d) {

                if ($d["driver_verified"]) {
                    $verified++;
                }

            }

            echo $verified;

            ?>

        </div>

        <div class="stat-label">
            VERIFIED
        </div>

    </a>


    <a href="admin_bookings.php" class="stat">

        <div class="stat-icon">
            📋
        </div>

        <div class="stat-number">
            <?php echo count($bookings); ?>
        </div>

        <div class="stat-label">
            BOOKINGS
        </div>

    </a>

</div>


<!-- ADMIN MANAGEMENT -->
<div class="admin-management-button">
    <a href="admin_management.php">
        🛠️ ADMIN MANAGEMENT
    </a>
</div>

<!-- MESSAGES & COMPLAINTS -->
<div class="admin-messages-button">
    <a href="messages.php">
        💬 MESSAGES & COMPLAINTS
    </a>
</div>

<!-- ADMIN MAP -->
<div class="admin-map-button">
    <a href="admin_map.php">
        🗺️ ADMIN MAP
    </a>
</div>

<!-- DRIVERS -->

<section class="section">

    <h3>
        🛵 Driver Verification
    </h3>


    <?php if (count($drivers) > 0): ?>


        <?php foreach ($drivers as $driver): ?>

            <div class="driver-card">


                <div class="driver-info">

                    <div class="driver-name">

                        👤
                        <?php
                        echo htmlspecialchars(
                            $driver["full_name"]
                        );
                        ?>

                    </div>


                    📧
                    <?php
                    echo htmlspecialchars(
                        $driver["email"]
                    );
                    ?>

                    <br>


                    🛵 Vehicle:
                    <?php
                    echo htmlspecialchars(
                        $driver["vehicle"]
                    );
                    ?>

                    <br>


                    🔢 Plate:
                    <?php
                    echo htmlspecialchars(
                        $driver["plate"]
                    );
                    ?>

                    <br>


                    🟢 Status:
                    <?php
                    echo htmlspecialchars(
                        $driver["status"]
                    );
                    ?>

                </div>


                <?php if ($driver["driver_verified"]): ?>

                    <span class="verified">

                        ✅ VERIFIED

                    </span>

                <?php else: ?>

                    <form
                        action="verify_driver.php"
                        method="POST">

                        <input
                            type="hidden"
                            name="driver_id"
                            value="<?php
                            echo $driver["id"];
                            ?>">

                        <button
                            type="submit"
                            class="verify-btn">

                            🛡️ VERIFY DRIVER

                        </button>

                    </form>

                <?php endif; ?>


            </div>

        <?php endforeach; ?>


    <?php else: ?>

        <div class="empty">

            🛵

            <br><br>

            No drivers registered yet.

        </div>

    <?php endif; ?>


</div>


<script>
document.addEventListener("DOMContentLoaded", function () {

    const menu = document.getElementById("adminSlideMenu");
    const overlay = document.getElementById("adminMenuOverlay");
    const openButton = document.getElementById("openAdminMenu");
    const closeButton = document.getElementById("closeAdminMenu");

    if (!menu || !overlay || !openButton || !closeButton) return;

    function openMenu() {
        menu.classList.add("active");
        overlay.classList.add("active");
        menu.setAttribute("aria-hidden", "false");
        document.body.style.overflow = "hidden";
    }

    function closeMenu() {
        menu.classList.remove("active");
        overlay.classList.remove("active");
        menu.setAttribute("aria-hidden", "true");
        document.body.style.overflow = "";
    }

    openButton.addEventListener("click", openMenu);
    closeButton.addEventListener("click", closeMenu);
    overlay.addEventListener("click", closeMenu);

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            closeMenu();
        }
    });

});
</script>


<script>
(function () {

    function setupAdminMenu() {

        const menu = document.getElementById("adminSlideMenu");
        const overlay = document.getElementById("adminMenuOverlay");
        const openButton = document.getElementById("openAdminMenu");
        const closeButton = document.getElementById("closeAdminMenu");

        if (!menu || !overlay || !openButton || !closeButton) {
            return;
        }

        function openAdminMenu() {
            menu.classList.add("active");
            overlay.classList.add("active");
            menu.setAttribute("aria-hidden", "false");
            document.body.style.overflow = "hidden";
        }

        function closeAdminMenu() {
            menu.classList.remove("active");
            overlay.classList.remove("active");
            menu.setAttribute("aria-hidden", "true");
            document.body.style.overflow = "";
        }

        openButton.onclick = openAdminMenu;
        closeButton.onclick = closeAdminMenu;
        overlay.onclick = closeAdminMenu;

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                closeAdminMenu();
            }
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", setupAdminMenu);
    } else {
        setupAdminMenu();
    }

})();
</script>

</body>
</html></section>


<!-- BOOKINGS -->

<section class="section">

    <h3>
        📋 All Ride Bookings
    </h3>


    <?php if (count($bookings) > 0): ?>


        <?php foreach ($bookings as $booking): ?>

            <div class="booking">

                <strong>

                    👨‍🎓
                    <?php
                    echo htmlspecialchars(
                        $booking["student_name"]
                        ?? "Student"
                    );
                    ?>

                    →

                    🛵
                    <?php
                    echo htmlspecialchars(
                        $booking["driver_name"]
                        ?? "Driver"
                    );
                    ?>

                </strong>


                <br>

                📍 Pickup:
                <?php
                echo htmlspecialchars(
                    $booking["pickup"]
                );
                ?>

                <br>

                🏁 Drop-off:
                <?php
                echo htmlspecialchars(
                    $booking["dropoff"]
                );
                ?>

                <br>

                Status:

                <span class="status">

                    <?php
                    echo htmlspecialchars(
                        $booking["status"]
                    );
                    ?>

                </span>

            </div>

        <?php endforeach; ?>


    <?php else: ?>

        <div class="empty">

            📋

            <br><br>

            No bookings yet.

        </div>

    <?php endif; ?>

</section>
<!-- ABOUT US -->
<section class="section">

    <h3>🛵 About TransCalltation</h3>

    <button
        type="button"
        class="about-btn"
        onclick="openAboutUs()"
    >
        ℹ️ ABOUT US
    </button>

</section>

<!-- ABOUT US MODAL -->
<div id="aboutUsModal" class="about-modal">

    <div class="about-box">
        <div class="about-welcome">
            <h1 class="about-welcome-title">✨ Thank you for Choosing TransCalltation ✨</h1>
            <p class="about-welcome-text">Please read below for more information about TransCalltation, its purpose, features, and benefits.</p>
        </div>

        <button
            type="button"
            class="about-close"
            onclick="closeAboutUs()"
        >
            ✕
        </button>

        <h2>🛵 About TransCalltation</h2>

        <p class="about-subtitle">
            A Web-Based Transportation Assistance and Ride Booking System
        </p>

        <h3>1. Introduction</h3>
        <p>
            TransCalltation is a proposed web-based system designed to help
            students find available transportation more conveniently. It
            focuses on reducing long waiting times and helping students
            manage their schedules when looking for motorcycle or other
            available transportation.
        </p>

        <h3>2. Main Problem</h3>
        <p>
            Many students have difficulty finding available transportation,
            especially during busy hours. They may spend a long time waiting
            for a motorcycle or vehicle, which can cause delays and make it
            difficult to arrive at school or other destinations on time.
        </p>

        <h3>3. Why Transportation Is Important</h3>
        <p>
            Reliable transportation is important for students because it
            allows them to travel to school, go home, attend activities,
            and manage their daily responsibilities.
        </p>

        <h3>4. Reasons Why It Is a Problem</h3>
        <ul>
            <li>Long waiting times during peak hours.</li>
            <li>Limited available drivers near schools.</li>
            <li>Difficulty identifying available drivers.</li>
            <li>Students may arrive late to class.</li>
            <li>Transportation problems can affect students' daily schedules.</li>
        </ul>

        <h3>5. Effects on Students</h3>
        <p>
            Transportation problems can result in wasted time, delays,
            stress, and difficulty managing school activities. Students
            may also spend additional time searching for an available
            driver instead of focusing on their academic responsibilities.
        </p>

        <h3>6. Evidence of the Problem</h3>
        <p>
            The project can use photos and videos as evidence, such as:
        </p>

        <ul>
            <li>Students waiting for motorcycles.</li>
            <li>Long lines of commuters.</li>
            <li>Crowded roads near schools.</li>
            <li>Students waiting during peak hours.</li>
            <li>Areas with limited transportation.</li>
        </ul>

        <p>
            <strong>Note:</strong> Always ask permission when taking
            identifiable photos or videos of people.
        </p>

        <h3>7. Proposed Solution</h3>
        <p>
            TransCalltation provides a centralized website where students
            can find available drivers and request rides. Drivers can
            manage their availability, while administrators can manage
            users, drivers, and bookings.
        </p>

        <h3>8. User Registration & Login</h3>
        <p>
            Students can create accounts and securely log in to the system.
            Their accounts can contain basic information needed for
            transportation booking and account management.
        </p>

        <h3>9. Driver Registration & Verification</h3>
        <p>
            Drivers can register through the website and provide the
            required information. An administrator can review and verify
            driver accounts before they are allowed to accept ride requests.
        </p>

        <h3>10. Driver Availability</h3>
        <p>
            Drivers can set their status to:
        </p>

        <ul>
            <li>🟢 Available – Ready to receive ride requests.</li>
            <li>🔴 Unavailable – Not currently accepting requests.</li>
        </ul>

        <h3>11. Ride Booking</h3>
        <p>
            Students can select an available driver and submit a ride
            request. The booking can include the pickup location,
            destination, date, time, selected driver, and booking status.
        </p>

        <h3>12. Booking Records & Ride History</h3>
        <p>
            Students and drivers can view previous ride information.
            Records can include the place, date, time, driver/student,
            and booking status. This creates an organized history of
            transportation activities.
        </p>

        <h3>13. Administrator Dashboard</h3>
        <p>
            The administrator can manage important system information,
            including:
        </p>

        <ul>
            <li>Student accounts</li>
            <li>Driver accounts</li>
            <li>Driver verification</li>
            <li>Ride bookings</li>
            <li>Booking records</li>
            <li>User management</li>
        </ul>

        <h3>14. Beneficiaries & Benefits</h3>

        <ul>
            <li>🎓 <strong>Students</strong> – Easier access to available transportation.</li>
            <li>🛵 <strong>Drivers</strong> – More organized ride requests and availability management.</li>
            <li>🏫 <strong>Schools</strong> – Better transportation coordination for students.</li>
            <li>🚶 <strong>Commuters</strong> – A more organized way of connecting transportation needs with available drivers.</li>
        </ul>

        <h3>15. Goal & Expected Outcome</h3>
        <p>
            The goal of TransCalltation is to make student transportation
            easier, faster, and more organized. Through the web application,
            students can find available drivers, request rides, and view
            their ride history, while drivers can manage availability and
            bookings.
        </p>

        <div class="about-tagline">
        <div class="about-thankyou">
            <h2 class="about-thankyou-title">🙏 Thank you!</h2>
            <p class="about-contact">Please contact the administrator for more information, questions, assistance, or support regarding TransCalltation.</p>
        </div>
            🏍️ “TransCalltation: Connecting Students with Transportation —
            Faster, Easier, and More Organized.”
        </div>

    </div>

</div>

<script>

function openAboutUs() {
    document.getElementById("aboutUsModal").classList.add("active");
}

function closeAboutUs() {
    document.getElementById("aboutUsModal").classList.remove("active");
}

document.getElementById("aboutUsModal").addEventListener(
    "click",
    function(event) {
        if (event.target === this) {
            closeAboutUs();
        }
    }
);

</script>

</div>

</body>
</html>


<?php

session_start();

include "config.php";
include "languages.php";


/* Protect dashboard */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];


/* Get logged-in user */

$stmt = $conn->prepare(
    "SELECT id, full_name, role, driver_verified, status, vehicle, plate, appearance
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();
$appearance = $user["appearance"] ?? "Gradient";

$stmt->close();


if (!$user) {

    session_destroy();

    header("Location: login.php");
    exit();
}

/* Get available verified drivers */

$drivers = [];

$driverQuery = $conn->query(
    "SELECT id, full_name, vehicle, plate, status
     FROM users
     WHERE role = 'driver'
     AND driver_verified = 1
     AND status = 'Available'
     ORDER BY full_name ASC"
);

if ($driverQuery) {

    while ($driver = $driverQuery->fetch_assoc()) {
        $drivers[] = $driver;
    }

}


/* Get student's bookings */

$bookings = [];

$bookingStmt = $conn->prepare(
    "SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,
        u.full_name AS driver_name,
        u.vehicle,
        u.plate
     FROM bookings b
     LEFT JOIN users u
        ON b.driver_id = u.id
     WHERE b.student_id = ?
     ORDER BY b.id DESC"
);

$bookingStmt->bind_param("i", $user_id);
$bookingStmt->execute();

$bookingResult = $bookingStmt->get_result();

while ($booking = $bookingResult->fetch_assoc()) {
    $bookings[] = $booking;
}

$bookingStmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    Student Dashboard | TransCalltation 2.0
</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    font-family: Arial, Helvetica, sans-serif;

    color: white;

    padding: 15px;

    background:
        radial-gradient(
            circle at 5% 5%,
            #00e5ff,
            transparent 28%
        ),

        radial-gradient(
            circle at 95% 95%,
            #e100ff,
            transparent 30%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

    background-size: 200% 200%;

    animation: backgroundMove 12s ease infinite;
}


/* Main */

.dashboard {

    width: 100%;

    max-width: 1000px;

    margin: auto;

    animation: pageEnter .8s ease;
}


/* Header */

.header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding: 18px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.85),
            rgba(142,45,226,.85)
        );

    border:
        1px solid
        rgba(255,255,255,.3);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.3),

        inset 0 1px 3px
        rgba(255,255,255,.5);
}

.brand {

    display: flex;

    align-items: center;

    gap: 12px;
}

.brand-icon {

    width: 52px;

    height: 52px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 15px;

    font-size: 25px;

    background:
        rgba(255,255,255,.2);

    box-shadow:
        inset 0 1px 3px
        rgba(255,255,255,.5);
}

.brand h1 {

    font-size: 20px;

    font-weight: 900;

    text-shadow:
        2px 3px 5px
        rgba(0,0,0,.4);
}

.brand p {

    font-size: 11px;

    opacity: .8;

    margin-top: 3px;
}


/* Logout */

.logout {

    padding: 10px 15px;

    border: none;

    border-radius: 12px;

    color: white;

    text-decoration: none;

    font-size: 12px;

    font-weight: 900;

    background:
        rgba(0,0,0,.25);

    box-shadow:
        0 5px 15px
        rgba(0,0,0,.2);

    transition: .25s;
}

.logout:hover {

    background:
        rgba(255,255,255,.2);

    transform: translateY(-2px);
}


/* Welcome */

.welcome {

    padding: 25px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.08)
        );

    border:
        1px solid
        rgba(255,255,255,.3);

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.welcome h2 {

    font-size: 26px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.45);
}

.welcome p {

    margin-top: 6px;

    font-size: 13px;

    opacity: .85;
}


/* Stats */

.stats {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 12px;

    margin-bottom: 20px;
}

.stat {

    padding: 18px;

    text-align: center;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);

    transition: .3s;
}

.stat:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 15px 30px
        rgba(0,0,0,.3);
}

.stat-icon {

    font-size: 25px;

    margin-bottom: 7px;
}

.stat-number {

    font-size: 22px;

    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}

.stat-label {

    font-size: 10px;

    opacity: .75;

    margin-top: 3px;
}


/* Section */

.section {

    padding: 20px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.28);

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.section-title {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 15px;
}

.section-title h3 {

    font-size: 18px;

    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}


/* Driver grid */

.driver-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 14px;
}


/* Driver card */

.driver-card {

    padding: 18px;

    border-radius: 18px;

    background:
        linear-gradient(
            135deg,
            rgba(0,198,255,.25),
            rgba(123,44,255,.18)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,.2);

    transition: .3s;

    animation: cardEnter .6s ease;
}

.driver-card:hover {

    transform:
        translateY(-5px)
        scale(1.01);
}

.driver-top {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 12px;
}

.driver-icon {

    width: 48px;

    height: 48px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 15px;

    font-size: 23px;

    background:
        linear-gradient(
            135deg,
            #00c6ff,
            #7b2cff
        );

    box-shadow:
        0 7px 15px
        rgba(0,0,0,.3);
}

.driver-name {

    font-size: 15px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}

.available {

    display: inline-block;

    margin-top: 4px;

    font-size: 10px;

    font-weight: 900;

    color: #7cffb2;
}

.driver-info {

    font-size: 12px;

    line-height: 1.8;

    opacity: .9;

    margin-bottom: 12px;
}


/* Request button */

.request-btn {

    width: 100%;

    padding: 12px;

    border: none;

    border-radius: 12px;

    color: white;

    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    background-size: 200%;

    box-shadow:
        0 8px 18px
        rgba(0,0,0,.25);

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);

    animation:
        buttonGradient 4s linear infinite;

    transition: .25s;
}

.request-btn:active {

    transform:
        scale(.95);
}


/* Booking */

.booking {

    padding: 15px;

    margin-bottom: 10px;

    border-radius: 15px;

    background:
        rgba(255,255,255,.1);

    border:
        1px solid
        rgba(255,255,255,.18);
}

.booking strong {

    font-size: 14px;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}

.route {

    margin: 8px 0;

    font-size: 13px;

    line-height: 1.7;
}

.status {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 900;

    background:
        rgba(0,0,0,.2);
}


/* Empty */

.empty {

    padding: 25px;

    text-align: center;

    opacity: .75;

    font-size: 13px;
}


/* Modal */

.modal {

    position: fixed;

    inset: 0;

    display: none;

    align-items: center;

    justify-content: center;

    padding: 20px;

    background:
        rgba(0,0,0,.65);

    z-index: 100;
}

.modal.active {

    display: flex;
}

.modal-box {

    width: 100%;

    max-width: 420px;

    padding: 25px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            #ffffff,
            #e9edff
        );

    color: #222;

    box-shadow:
        0 25px 60px
        rgba(0,0,0,.45);

    animation:
        modalEnter .3s ease;
}

.modal-box h2 {

    color: #3a5bff;

    margin-bottom: 5px;

    font-weight: 900;
}

.modal-box p {

    font-size: 12px;

    margin-bottom: 15px;
}

.modal-box label {

    display: block;

    font-size: 11px;

    font-weight: 900;

    margin: 12px 0 5px;
}

.modal-box input {

    width: 100%;

    padding: 13px;

    border: 1px solid #ccd2e0;

    border-radius: 10px;

    outline: none;

    font-size: 13px;
}

.confirm {

    width: 100%;

    padding: 13px;

    margin-top: 15px;

    border: none;

    border-radius: 11px;

    color: white;

    font-weight: 900;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff
        );
}

.cancel {

    width: 100%;

    padding: 11px;

    margin-top: 8px;

    border: none;

    border-radius: 11px;

    color: #333;

    font-weight: bold;

    background: #ddd;
}


/* Animations */

@keyframes backgroundMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

@keyframes pageEnter {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes cardEnter {

    from {
        opacity: 0;
        transform: translateY(20px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes modalEnter {

    from {
        opacity: 0;
        transform: scale(.9);
    }

    to {
        opacity: 1;
        transform: scale(1);
    }
}

@keyframes buttonGradient {

    0% {
        background-position: 0%;
    }

    100% {
        background-position: 200%;
    }
}


/* Mobile */

@media (max-width: 650px) {

    body {
        padding: 10px;
    }

    .header {
        padding: 14px;
    }

    .brand h1 {
        font-size: 16px;
    }

    .stats {
        grid-template-columns:
            repeat(3, 1fr);
    }

    .stat {
        padding: 13px 5px;
    }

    .stat-number {
        font-size: 18px;
    }

    .driver-grid {
        grid-template-columns: 1fr;
    }

}

.settings-btn {
    padding: 10px 15px;
    min-height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    font-size: 12px;
    font-weight: 900;
    background: linear-gradient(135deg, #006eff, #7b2cff);
    border: 1px solid rgba(255,255,255,.3);
    box-shadow: 0 5px 15px rgba(0,0,0,.2), inset 0 1px 3px rgba(255,255,255,.35);
    transition: .25s;
}
.settings-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,.3);
}

/* USER APPEARANCE */
body.appearance-light {
    background: #f2f5fa !important;
    color: #222 !important;
    animation: none !important;
}

body.appearance-dark {
    background: #111827 !important;
    color: #ffffff !important;
    animation: none !important;
}

body.appearance-gradient {
    background: radial-gradient(circle at 5% 5%, #00e5ff, transparent 28%), radial-gradient(circle at 95% 95%, #e100ff, transparent 30%), linear-gradient(135deg, #071952, #088395, #5700b3) !important;
    background-size: 200% 200% !important;
    animation: backgroundMove 12s ease infinite !important;
}

body.appearance-light .header,
body.appearance-light .welcome,
body.appearance-light .section,
body.appearance-light .stat,
body.appearance-light .driver-card,
body.appearance-light .booking {
    background: #ffffff !important;
    color: #222 !important;
}

body.appearance-dark .header,
body.appearance-dark .welcome,
body.appearance-dark .section,
body.appearance-dark .stat,
body.appearance-dark .driver-card,
body.appearance-dark .booking {
    background: #1f2937 !important;
    color: #ffffff !important;
}

</style></head><body class="appearance-<?php echo strtolower(htmlspecialchars($appearance)); ?>"><div class="dashboard"><!-- HEADER --><header class="header"><div class="brand">

    <div class="brand-icon">
        🛵
    </div>

    <div>

        <h1>
            TransCalltation 2.0
        </h1>

        <p>
            SMART • SAFE • SIMPLE TRANSPORTATION
        </p>

    </div>

</div>


<a
  <a href="settings.php" class="settings-btn">
      ⚙️ Settings
  </a>

</header><!-- WELCOME --><div class="welcome"><h2>
    Welcome, <?php
    echo htmlspecialchars($user["full_name"]);
    ?>! 👋
</h2>

<p>
    Find an available driver and request your ride.
</p>

</div><!-- STATISTICS --><div class="stats"><div class="stat">

    <div class="stat-icon">
        🚕
    </div>

    <div class="stat-number">
        <?php echo count($drivers); ?>
    </div>

    <div class="stat-label">
        AVAILABLE DRIVERS
    </div>

</div>


<div class="stat">

    <div class="stat-icon">
        📋
    </div>

    <div class="stat-number">
        <?php echo count($bookings); ?>
    </div>

    <div class="stat-label">
        MY BOOKINGS
    </div>

</div>


<div class="stat">

    <div class="stat-icon">
        👨‍🎓
    </div>

    <div class="stat-number">
        STUDENT
    </div>

    <div class="stat-label">
        ACCOUNT TYPE
    </div>

</div>

</div><!-- AVAILABLE DRIVERS --><section class="section"><div class="section-title">

    <h3>
        🚕 Available Drivers
    </h3>

</div>


<?php if (count($drivers) > 0): ?>

    <div class="driver-grid">

        <?php foreach ($drivers as $driver): ?>

            <div class="driver-card">

                <div class="driver-top">

                    <div class="driver-icon">
                        🛵
                    </div>

                    <div>

                        <div class="driver-name">

                            <?php
                            echo htmlspecialchars(
                                $driver["full_name"]
                            );
                            ?>

                        </div>

                        <span class="available">

                            🟢 AVAILABLE

                        </span>

                    </div>

                </div>


                <div class="driver-info">

                    🛵 Vehicle:
                    <?php
                    echo htmlspecialchars(
                        $driver["vehicle"]
                    );
                    ?>

                    <br>

                    🔢 Plate:
                    <?php
                    echo htmlspecialchars(
                        $driver["plate"]
                    );
                    ?>

                </div>


                <button
                    class="request-btn"
                    onclick="openBooking(
                        <?php echo $driver['id']; ?>,
                        '<?php echo htmlspecialchars(
                            $driver['full_name'],
                            ENT_QUOTES
                        ); ?>'
                    )">

                    🚕 REQUEST RIDE

                </button>

            </div>

        <?php endforeach; ?>

    </div>


<?php else: ?>

    <div class="empty">

        🛵


        <strong>
            No drivers available right now.
        </strong>

        <br>

        Please check again later.

    </div>

<?php endif; ?>

</section><!-- BOOKING RECORDS --><section class="section"><div class="section-title">

    <h3>
        📋 My Booking Records
    </h3>

</div>


<?php if (count($bookings) > 0): ?>

    <?php foreach ($bookings as $booking): ?>

        <div class="booking">

            <strong>

                🛵
                <?php
                echo htmlspecialchars(
                    $booking["driver_name"] ?? "Driver"
                );
                ?>

            </strong>


            <div class="route">

                📍
                <?php
                echo htmlspecialchars(
                    $booking["pickup"]
                );
                ?>

                <br>

                🏁
                <?php
                echo htmlspecialchars(
                    $booking["dropoff"]
                );
                ?>

            </div>


            <span class="status">

                <?php
                echo htmlspecialchars(
                    $booking["status"]
                );
                ?>

            </span>

        </div>

    <?php endforeach; ?>


<?php else: ?>

    <div class="empty">

        📋

        <br><br>

        You don't have any bookings yet.

    </div>

<?php endif; ?>

</section></div><!-- BOOKING MODAL --><div
    class="modal"
    id="bookingModal"><div class="modal-box">

    <h2>
        🚕 Request Ride
    </h2>

    <p id="selectedDriver">
        Driver
    </p>


    <form
        action="book.php"
        method="POST">


        <input
            type="hidden"
            name="driver_id"
            id="driverId"
        >


        <label>
            📍 PICKUP LOCATION
        </label>

        <input
            type="text"
            name="pickup"
            placeholder="Example: Main Gate"
            required
        >


        <label>
            🏁 DROP-OFF LOCATION
        </label>

        <input
            type="text"
            name="dropoff"
            placeholder="Example: City Mall"
            required
        >


        <button
            type="submit"
            class="confirm">

            ✅ CONFIRM BOOKING

        </button>


        <button
            type="button"
            class="cancel"
            onclick="closeBooking()">

            CANCEL

        </button>

    </form>

</div>

</div><script>

function openBooking(id, name) {

    document.getElementById(
        "driverId"
    ).value = id;

    document.getElementById(
        "selectedDriver"
    ).textContent =
        "Driver: " + name;

    document.getElementById(
        "bookingModal"
    ).classList.add("active");

}


function closeBooking() {

    document.getElementById(
        "bookingModal"
    ).classList.remove("active");

}


/* Close when tapping outside */

document.getElementById(
    "bookingModal"
).addEventListener(
    "click",
    function(event) {

        if (event.target === this) {

            closeBooking();

        }

    }
);

</script></body></html>

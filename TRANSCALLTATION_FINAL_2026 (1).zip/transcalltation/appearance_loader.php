<?php

/* =====================================================
   TRANSCALLTATION APPEARANCE LOADER
   Reads the logged-in user's saved appearance
===================================================== */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($conn)) {
    include "config.php";
}

$appearance = "Gradient";

if (isset($_SESSION["user_id"])) {

    $user_id = $_SESSION["user_id"];

    $stmt = $conn->prepare(
        "SELECT appearance
         FROM users
         WHERE id = ?
         LIMIT 1"
    );

    if ($stmt) {

        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        $result = $stmt->get_result();
        $userAppearance = $result->fetch_assoc();

        if (!empty($userAppearance["appearance"])) {
            $appearance = $userAppearance["appearance"];
        }

        $stmt->close();
    }
}

/* Convert appearance to CSS class */
$appearance_class = strtolower($appearance);

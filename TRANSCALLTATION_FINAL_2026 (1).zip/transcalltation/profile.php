<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT full_name, email, role
     FROM users
     WHERE id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User account not found.");
}

/* Update profile */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $full_name = trim($_POST["full_name"] ?? "");
    $email = trim($_POST["email"] ?? "");

    if ($full_name === "" || $email === "") {

        $error = "Please fill in all required fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } else {

        $update = $conn->prepare(
            "UPDATE users
             SET full_name = ?, email = ?
             WHERE id = ?"
        );

        if (!$update) {

            $error = "Database error: " . $conn->error;

        } else {

            $update->bind_param(
                "ssi",
                $full_name,
                $email,
                $user_id
            );

            if ($update->execute()) {

                header("Location: profile.php?saved=1");
                exit();

            } else {

                $error = "Unable to save your profile: " . $update->error;
            }

            $update->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Profile - TransCalltation</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 20px;

    font-family: Arial, Helvetica, sans-serif;

    color: white;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #071a3d,
            #123b72,
            #0b6fa4
        );
}

.container {
    max-width: 600px;
    margin: auto;
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

.card {
    padding: 22px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);
}

label {
    display: block;
    margin-top: 15px;
    margin-bottom: 6px;

    font-weight: bold;
}

input {
    width: 100%;

    padding: 13px;

    border: none;
    border-radius: 12px;

    font-size: 15px;
}

input:focus {
    outline: 2px solid rgba(255,255,255,.5);
}

.role {
    padding: 13px;

    border-radius: 12px;

    background:
        rgba(0,0,0,.20);
}

button {
    width: 100%;

    margin-top: 20px;

    padding: 14px;

    border: none;
    border-radius: 12px;

    font-size: 15px;
    font-weight: bold;

    cursor: pointer;

    color: white;

    background:
        linear-gradient(
            135deg,
            #1472d4,
            #0b9bd7
        );
}

.saved {
    padding: 10px;

    margin-bottom: 15px;

    text-align: center;

    border-radius: 10px;

    background: rgba(0,180,100,.3);
}

.back {
    display: block;

    margin-top: 20px;

    text-align: center;

    color: white;

    text-decoration: none;
}
.role-not-editable {
    width: 100%;
    padding: 13px;

    text-align: center;

    border-radius: 12px;

    color: white;
    font-weight: bold;
    font-size: 14px;

    background:
        linear-gradient(
            135deg,
            #1769d1,
            #6a35c9,
            #8e44ad
        );

    border: 1px solid rgba(255,255,255,.25);

    box-shadow:
        0 6px 15px rgba(0,0,0,.25);
}
</style>

</head>

<body>

<div class="container">

<h1>👤 PROFILE</h1>

<div class="card">

<?php if (isset($_GET["saved"])): ?>

<div class="saved">
    ✅ Profile updated successfully!
</div>

<?php endif; ?>

<form method="POST">

<label>Full Name</label>

<input
    type="text"
    name="full_name"
    value="<?php echo htmlspecialchars($user["full_name"]); ?>"
    required
>

<label>Email</label>

<input
    type="email"
  name="email"
 value="<?php echo htmlspecialchars($user["email"]); ?>"
    required
>

<label>Role</label>

<div class="role-not-editable">
    🔒 ROLE NOT EDITABLE
</div>

</button>    <button type="submit">
    💾 SAVE CHANGES
</button>

</form>

</div>

<a href="settings.php" class="back">
    ← Back to Settings
</a>

</div>

</body>

</html>

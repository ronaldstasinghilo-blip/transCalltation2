<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About TransCalltation 2.0</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    font-family: Arial, sans-serif;
    color: white;

    background:
        linear-gradient(
            rgba(3, 8, 25, 0.70),
            rgba(3, 8, 25, 0.90)
        ),
        url("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=2560&q=90")
        center center / cover no-repeat fixed;

    display: flex;
    align-items: center;
    justify-content: center;
    padding: 25px;
}

.slides {
    width: 100%;
    max-width: 850px;

    background:
        linear-gradient(
            rgba(3, 8, 25, 0.42),
            rgba(3, 8, 25, 0.62)
        ),
        url("welcome_students.jpg")
        center center / cover no-repeat;

    border-radius: 30px;
    padding: 0;
}

.slide {
    display: none;
    text-align: center;
    padding: 45px 35px;
    border-radius: 30px;

    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.25);
    backdrop-filter: none;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.45),
        inset 0 1px 0 rgba(255,255,255,0.18);

    animation: fadeIn .45s ease;
}

.slide.active {
    display: block;
}

.icon {
    font-size: 65px;
    margin-bottom: 15px;
}

h1 {
    margin: 0 0 15px;
    font-size: 42px;
    font-weight: 900;
    color: #ffffff;
    text-shadow:
        0 0 8px rgba(0,234,255,.85),
        0 0 20px rgba(123,44,255,.65);
}

h1 span {
    background: linear-gradient(
        90deg,
        #00eaff,
        #ffffff,
        #b86cff,
        #ff4fd8
    );

    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

h2 {
    font-size: 30px;
    margin: 10px 0 15px;

    background: linear-gradient(
        90deg,
        #00eaff,
        #5d8bff,
        #b86cff,
        #ff4fd8
    );

    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;

    text-shadow:
        0 0 10px rgba(0,234,255,.35),
        0 0 20px rgba(255,79,216,.30);
}

p {
    max-width: 680px;
    margin: 0 auto;
    font-size: 18px;
    line-height: 1.7;
    color: #f5fbff;
    text-shadow:
        0 0 6px rgba(0,234,255,.35),
        0 1px 8px rgba(0,0,0,.75);
}

.progress {
    margin: 25px auto 20px;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 2px;
    color: #7df9ff;
    text-shadow:
        0 0 8px rgba(0,234,255,.75),
        0 0 16px rgba(123,44,255,.45);
}

.dots {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-bottom: 25px;
}

.dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: rgba(255,255,255,.35);
}

.dot.active {
    background: white;
    transform: scale(1.3);
}

button,
.final-button {
    display: inline-block;
    border: none;
    text-decoration: none;
    cursor: pointer;

    padding: 14px 32px;
    border-radius: 50px;

    font-size: 16px;
    font-weight: 800;
    color: white;

    background: linear-gradient(
        135deg,
        #00bfff,
        #7b2cff,
        #ff2fd0
    );

    box-shadow: 0 10px 30px rgba(0,0,0,.35);
    transition: .25s ease;
}

button:hover,
.final-button:hover {
    transform: translateY(-3px) scale(1.03);
}

.back {
    display: inline-block;
    margin-right: 10px;
    padding: 14px 25px;
    border-radius: 50px;

    color: white;
    text-decoration: none;
    font-weight: 700;

    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.25);
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(15px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 600px) {

    body {
        padding: 15px;
    }

    .slide {
        padding: 35px 22px;
        border-radius: 24px;
    }

    .icon {
        font-size: 52px;
    }

    h1 {
        font-size: 31px;
    }

    h2 {
        font-size: 24px;
    }

    p {
        font-size: 16px;
    }
}
</style>
</head>

<body>

<div class="slides">

    <!-- SLIDE 1 -->
    <section class="slide active">
        <div class="icon">🏍️</div>

        <h1>Welcome to<br><span>TransCalltation 2.0</span></h1>

        <p>
            Your smarter, safer, and simpler way to connect
            students with available transportation.
        </p>

        <div class="progress">1 / 5</div>

        <div class="dots">
            <div class="dot active"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>

        <button onclick="nextSlide()">NEXT →</button>
    </section>


    <!-- SLIDE 2 -->
    <section class="slide">
        <div class="icon">🚦</div>

        <h2>What is TransCalltation?</h2>

        <p>
            TransCalltation 2.0 is a student transportation
            booking system designed to make finding available
            transportation easier and more convenient.
        </p>

        <div class="progress">2 / 5</div>

        <div class="dots">
            <div class="dot"></div>
            <div class="dot active"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>

        <button onclick="nextSlide()">NEXT →</button>
    </section>


    <!-- SLIDE 3 -->
    <section class="slide">
        <div class="icon">📱</div>

        <h2>Simple & Convenient</h2>

        <p>
            Find available drivers, provide your pickup and
            destination details, and submit your ride request
            through a simple and easy-to-use system.
        </p>

        <div class="progress">3 / 5</div>

        <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot active"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>

        <button onclick="nextSlide()">NEXT →</button>
    </section>


    <!-- SLIDE 4 -->
    <section class="slide">
        <div class="icon">🛡️</div>

        <h2>Safety & Reliability</h2>

        <p>
            Drivers can be verified by the administrator,
            helping students identify approved drivers
            within the transportation system.
        </p>

        <div class="progress">4 / 5</div>

        <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot active"></div>
            <div class="dot"></div>
        </div>

        <button onclick="nextSlide()">NEXT →</button>
    </section>


    <!-- SLIDE 5 -->
    <section class="slide">
        <div class="icon">🎉</div>

        <h1>Thank You!</h1>

        <p>
            Welcome to the TransCalltation community!<br><br>

            Thank you for choosing TransCalltation 2.0.
            We appreciate your trust and hope you enjoy
            a smarter, safer, and simpler transportation
            experience.
        </p>

        <div class="progress">5 / 5</div>

        <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot active"></div>
        </div>

        <a href="login.php" class="final-button">
            GET STARTED 🏍️
        </a>
    </section>

</div>

<script>
let currentSlide = 0;

const slides = document.querySelectorAll(".slide");

function nextSlide() {
    slides[currentSlide].classList.remove("active");

    currentSlide++;

    if (currentSlide >= slides.length) {
        currentSlide = slides.length - 1;
    }

    slides[currentSlide].classList.add("active");
}
</script>

</body>
</html>

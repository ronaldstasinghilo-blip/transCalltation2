<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$user_id = $_SESSION["user_id"];

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $booking_notifications =
        isset($_POST["booking_notifications"]) ? 1 : 0;

    $update = $conn->prepare(
        "UPDATE users
         SET booking_notifications = ?
         WHERE id = ?"
    );

    if ($update) {

        $update->bind_param(
            "ii",
            $booking_notifications,
            $user_id
        );

        if ($update->execute()) {
            $message = "Notification settings saved.";
        }

        $update->close();
    }
}

$stmt = $conn->prepare(
    "SELECT booking_notifications
     FROM users
     WHERE id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();

$booking_notifications =
    $user["booking_notifications"] ?? 1;
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Notifications - TransCalltation</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 20px;

    font-family: Arial, Helvetica, sans-serif;

    color: white;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #071a3d,
            #123b72,
            #6a35c9
        );
}

.container {
    max-width: 600px;
    margin: auto;
}

h1 {
    text-align: center;
}

.card {
    padding: 22px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border: 1px solid rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px rgba(0,0,0,.2);
}

.notification-option {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 16px;

    border-radius: 15px;

    background: rgba(0,0,0,.18);
}

.notification-text {
    flex: 1;
}

.notification-title {
    font-weight: bold;
}

.notification-description {
    margin-top: 5px;

    font-size: 12px;

    opacity: .75;
}

/* SWITCH */

.switch {
    position: relative;

    width: 52px;
    height: 30px;

    flex-shrink: 0;
}

.switch input {
    display: none;
}

.slider {
    position: absolute;

    inset: 0;

    cursor: pointer;

    border-radius: 30px;

    background: rgba(0,0,0,.35);

    transition: .3s;
}

.slider:before {
    content: "";

    position: absolute;

    width: 22px;
    height: 22px;

    left: 4px;
    top: 4px;

    border-radius: 50%;

    background: white;

    transition: .3s;
}

.switch input:checked + .slider {
    background:
        linear-gradient(
            135deg,
            #1769d1,
            #6a35c9
        );
}

.switch input:checked + .slider:before {
    transform: translateX(22px);
}

button {
    width: 100%;

    margin-top: 20px;

    padding: 14px;

    border: none;

    border-radius: 12px;

    color: white;

    font-weight: bold;

    background:
        linear-gradient(
            135deg,
            #1769d1,
            #6a35c9
        );
}

.message {
    margin-bottom: 15px;

    padding: 12px;

    text-align: center;

    border-radius: 10px;

    background: rgba(0,180,100,.3);
}

.back {
    display: block;

    margin-top: 20px;

    text-align: center;

    color: white;

    text-decoration: none;
}

</style>

</head>

<body>

<div class="container">

<h1>🔔 NOTIFICATIONS</h1>

<div class="card">

<?php if ($message !== ""): ?>

<div class="message">
    ✅ <?php echo htmlspecialchars($message); ?>
</div>

<?php endif; ?>

<form method="POST">

<div class="notification-option">

<div class="notification-text">

<div class="notification-title">
    🔔 Booking Notifications
</div>

<div class="notification-description">
    Receive notifications about your bookings.
</div>

</div>

<label class="switch">

<input
    type="checkbox"
    name="booking_notifications"
    <?php echo $booking_notifications ? "checked" : ""; ?>
>

<span class="slider"></span>

</label>

</div>

<button type="submit">
    💾 SAVE SETTINGS
</button>

</form>

</div>

<a href="settings.php" class="back">
    ← Back to Settings
</a>

</div>

</body>

</html>

<?php
session_start();
include "config.php";

$user_id = 4;

$stmt = $conn->prepare("SELECT appearance FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

$appearance = $user["appearance"] ?? "Gradient";

echo "Database value: ";
var_dump($user["appearance"]);

echo "<br>PHP appearance: ";
var_dump($appearance);

echo '<br>Expected body class: appearance-' . strtolower(htmlspecialchars($appearance));
?>

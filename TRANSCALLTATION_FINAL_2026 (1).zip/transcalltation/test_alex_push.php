<?php

include "config.php";
include "send_push_notification.php";

header("Content-Type: text/plain");

$result = sendPushNotification(
    14,
    "🏍️ TransCalltation 2.0",
    "🔔 Alex driver push notification test!"
);

if ($result) {
    echo "SUCCESS: Alex push notification sent.\n";
} else {
    echo "FAILED: Alex has no active push subscription.\n";
}

$conn->close();
?>

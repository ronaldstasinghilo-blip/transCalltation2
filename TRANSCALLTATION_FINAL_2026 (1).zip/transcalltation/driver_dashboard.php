<?php

session_start();
include "config.php";
include "appearance_loader.php";

/* Make sure user is logged in */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

/* Get driver information */
$stmt = $conn->prepare(
    "SELECT id, full_name, email, phone, role, status, vehicle, plate, driver_verified,
           driver_license_photo, government_id_photo, profile_photo, vehicle_photo
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$driver = $result->fetch_assoc();

$stmt->close();

/* Only drivers can access this page */
if (!$driver || $driver["role"] !== "driver") {
    header("Location: dashboard.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Driver Dashboard | TransCalltation 2.0</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    font-family: Arial, sans-serif;

    color: white;

    padding: 15px;

    background:
        radial-gradient(
            circle at 10% 10%,
            #00e5ff,
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 90%,
            #e100ff,
            transparent 35%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

    background-size: 200% 200%;

    animation: backgroundMove 10s ease infinite;
}

.dashboard {

    width: 100%;

    max-width: 950px;

    margin: auto;

    animation: enter .8s ease;
}


/* HEADER */

.header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 18px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.9),
            rgba(142,45,226,.9)
        );

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.3),

        inset 0 1px 3px
        rgba(255,255,255,.5);
}

.brand {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 52px;

    height: 52px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 15px;

    font-size: 25px;

    background:
        rgba(255,255,255,.2);
}

.header h1 {

    font-size: 19px;

    font-weight: 900;

    text-shadow:
        2px 3px 5px
        rgba(0,0,0,.4);
}

.header p {

    font-size: 10px;

    opacity: .8;
}

.logout {

    color: white;

    text-decoration: none;

    padding: 10px 14px;

    border-radius: 11px;

    font-size: 11px;

    font-weight: 900;

    background:
        rgba(0,0,0,.25);
}


/* WELCOME */

.welcome {

    padding: 24px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.07)
        );

    backdrop-filter: blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.welcome h2 {

    font-size: 25px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.4);
}

.welcome p {

    margin-top: 7px;

    font-size: 13px;

    opacity: .8;
}


/* CARDS */

.grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px;
}

.card {

    padding: 20px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    backdrop-filter: blur(12px);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);

    animation: cardEnter .7s ease;
}

.card h3 {

    font-size: 15px;

    margin-bottom: 12px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}

.info {

    font-size: 13px;

    line-height: 2;
}


/* STATUS */

.status {

    margin-top: 15px;

    padding: 15px;

    border-radius: 15px;

    background:
        rgba(0,0,0,.18);
}

.status-title {

    font-size: 11px;

    font-weight: 900;

    margin-bottom: 8px;
}

.status-value {

    font-size: 18px;

    font-weight: 900;
}

.available {

    color: #72ffad;
}

.unavailable {

    color: #ff8080;
}


/* VERIFICATION */

.verified {

    padding: 15px;

    border-radius: 15px;

    font-weight: 900;

    background:
        rgba(0,255,120,.18);

    border:
        1px solid
        rgba(0,255,120,.3);
}

.pending {

    padding: 15px;

    border-radius: 15px;

    font-weight: 900;

    background:
        rgba(255,200,0,.18);

    border:
        1px solid
        rgba(255,200,0,.3);
}


/* BUTTON */

.button {

    display: block;

    width: 100%;

    margin-top: 15px;

    padding: 13px;

    border: none;

    border-radius: 12px;

    color: white;

    text-align: center;

    text-decoration: none;

    font-weight: 900;

    background:
        linear-gradient(
            90deg,
            #006eff,
            #7b2cff,
            #e000ff
        );

    background-size: 200%;

    animation: gradient 4s linear infinite;
}


/* ANIMATIONS */

@keyframes backgroundMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

@keyframes enter {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes cardEnter {

    from {
        opacity: 0;
        transform: translateY(20px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes gradient {

    0% {
        background-position: 0%;
    }

    100% {
        background-position: 200%;
    }
}


/* MOBILE */

@media(max-width:600px) {

    .grid {
        grid-template-columns: 1fr;
    }

    .header h1 {
        font-size: 16px;
    }

    .welcome h2 {
        font-size: 21px;
    }

}

/* =====================================================
   APPEARANCE SETTINGS
===================================================== */

body.appearance-light {
    background: #f4f7fb !important;
    color: #222 !important;
}

body.appearance-dark {
    background: #121826 !important;
    color: #ffffff !important;
}

body.appearance-gradient {
    background: linear-gradient(135deg, #667eea, #764ba2) !important;
    color: #ffffff !important;
}

.delete-history-button {
    width: 100%;
    margin-top: 12px;
    padding: 13px 18px;
    border: none;
    border-radius: 12px;
    background: linear-gradient(135deg, #ff4b4b, #c62828);
    color: #ffffff;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
    box-shadow: 0 6px 15px rgba(0,0,0,.25);
    transition: .2s ease;
}

.delete-history-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 9px 20px rgba(0,0,0,.3);
}

.delete-history-button:active {
    transform: scale(.97);
}
.history-card-full {
    grid-column: 1 / -1;
    width: 100%;
}
.about-btn {
    width: 100%;
    padding: 14px 18px;
    border: none;
    border-radius: 12px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
    box-shadow: 0 6px 15px rgba(0,0,0,.25);
}

.about-modal {
    display: none;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    z-index: 999999 !important;
    background: rgba(0,0,0,.75);
    padding: 20px;
    overflow-y: auto;
}

.about-modal.active {
    display: block !important;
}


.about-modal.active {
    display: block;
}

.about-box {
    position: relative;
    max-width: 900px;
    margin: 30px auto;
    padding: 25px;
    border-radius: 20px;
    background: linear-gradient(145deg, #667eea, #764ba2);
    color: #fff;
    box-shadow: 0 15px 40px rgba(0,0,0,.4);
}

.about-box h1,
.about-box h2,
.about-box h3 {
    margin-top: 18px;
}

.about-box p,
.about-box li {
    line-height: 1.6;
}

.about-close {
    position: absolute;
    top: 15px;
    right: 15px;
    border: none;
    background: rgba(255,255,255,.2);
    color: #fff;
    border-radius: 50%;
    width: 38px;
    height: 38px;
    font-size: 20px;
    cursor: pointer;
}

.about-welcome {
    text-align: center;
    padding: 10px 40px 20px;
}

.about-tagline {
    margin-top: 25px;
    padding: 20px;
    border-radius: 15px;
    background: rgba(255,255,255,.15);
    text-align: center;
    font-weight: bold;
}

.about-section-full {
    grid-column: 1 / -1;
    width: 100%;
    padding: 20px;
    margin-top: 0;
    border-radius: 18px;
    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.25);
    box-shadow: 0 8px 25px rgba(0,0,0,.20);
}

.about-section-full h3 {
    margin-top: 0;
    margin-bottom: 15px;
}

.about-section-full .about-btn {
    width: 100%;
    display: block;
    padding: 14px 18px;
    border: none;
    border-radius: 12px;
    background: linear-gradient(135deg, #2563eb, #4f46e5);
    color: #ffffff;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
    box-shadow: 0 6px 15px rgba(0,0,0,.25);
}
</style>


<style>

/* =====================================================
   PROFESSIONAL DRIVER INFORMATION BUTTON
===================================================== */

.driver-info-card {
    padding: 14px !important;
}

.driver-info-button {
    width: 100%;
    border: 0;
    border-radius: 16px;
    padding: 16px;
    display: flex;
    align-items: center;
    gap: 14px;
    text-align: left;
    cursor: pointer;
    color: white;
    background: linear-gradient(135deg, #315bea, #7b2ff7);
    box-shadow: 0 8px 20px rgba(0,0,0,0.18);
    transition: transform .2s ease, box-shadow .2s ease;
}

.driver-info-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 25px rgba(0,0,0,0.25);
}

.driver-info-button:active {
    transform: scale(.98);
}

.driver-info-button-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255,255,255,.18);
    font-size: 24px;
    flex-shrink: 0;
}

.driver-info-button-text {
    flex: 1;
}

.driver-info-button-text strong {
    display: block;
    font-size: 16px;
    letter-spacing: .5px;
}

.driver-info-button-text span {
    display: block;
    margin-top: 4px;
    font-size: 12px;
    opacity: .82;
}

.driver-info-button-arrow {
    font-size: 30px;
    font-weight: 300;
}

/* =====================================================
   DRIVER INFORMATION MODAL
===================================================== */

.driver-info-modal {
    display: none;
    position: fixed;
    z-index: 99999;
    inset: 0;
    padding: 20px;
    background: rgba(4, 8, 25, .72);
    backdrop-filter: blur(8px);
    overflow-y: auto;
}

.driver-info-modal-content {
    position: relative;
    width: min(720px, 100%);
    margin: 30px auto;
    padding: 24px;
    border-radius: 24px;
    color: white;
    background: linear-gradient(
        145deg,
        rgba(55, 65, 110, .98),
        rgba(95, 72, 170, .98)
    );
    box-shadow: 0 25px 70px rgba(0,0,0,.45);
}

.driver-info-close {
    position: absolute;
    top: 14px;
    right: 14px;
    width: 40px;
    height: 40px;
    border: 0;
    border-radius: 50%;
    cursor: pointer;
    color: white;
    background: rgba(255,255,255,.14);
    font-size: 18px;
}

.driver-info-close:hover {
    background: rgba(255,255,255,.25);
}

.driver-info-modal-header {
    display: flex;
    align-items: center;
    gap: 14px;
    padding-right: 45px;
    margin-bottom: 22px;
}

.driver-info-modal-icon {
    width: 58px;
    height: 58px;
    border-radius: 17px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #00a8ff, #7b2ff7);
    font-size: 28px;
}

.driver-info-modal-header h2 {
    margin: 0;
    font-size: 22px;
}

.driver-info-modal-header p {
    margin: 5px 0 0;
    opacity: .75;
    font-size: 13px;
}

/* DRIVER DETAILS */

.driver-details {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
}

.driver-detail {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px;
    border-radius: 14px;
    background: rgba(255,255,255,.10);
    border: 1px solid rgba(255,255,255,.12);
}

.driver-detail > span {
    font-size: 21px;
}

.driver-detail small {
    display: block;
    font-size: 9px;
    opacity: .65;
    letter-spacing: .7px;
}

.driver-detail strong {
    display: block;
    margin-top: 3px;
    font-size: 13px;
    word-break: break-word;
}

.status-verified {
    color: #55f6a8;
}

.status-pending {
    color: #ffd166;
}

/* DOCUMENTS */

.driver-documents {
    margin-top: 24px;
}

.driver-documents > h3 {
    margin: 0 0 14px;
    font-size: 15px;
}

.document-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
}

.document-card {
    padding: 12px;
    border-radius: 16px;
    background: rgba(255,255,255,.09);
    border: 1px solid rgba(255,255,255,.12);
}

.document-title {
    margin-bottom: 10px;
    font-weight: bold;
    font-size: 13px;
}

.document-card img {
    display: block;
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 11px;
    background: rgba(0,0,0,.2);
}

.photo-placeholder {
    height: 180px;
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
    background: rgba(0,0,0,.18);
    color: rgba(255,255,255,.65);
    font-size: 13px;
    gap: 5px;
}

/* MOBILE */

@media (max-width: 600px) {

    .driver-info-button {
        padding: 13px;
    }

    .driver-info-button-icon {
        width: 43px;
        height: 43px;
    }

    .driver-info-button-text strong {
        font-size: 14px;
    }

    .driver-info-modal {
        padding: 10px;
    }

    .driver-info-modal-content {
        margin: 10px auto;
        padding: 18px;
        border-radius: 20px;
    }

    .driver-details,
    .document-grid {
        grid-template-columns: 1fr;
    }

    .document-card img,
    .photo-placeholder {
        height: 210px;
    }
}


/* =====================================================
   DRIVER MESSAGES & COMPLAINTS BOX
===================================================== */

.driver-messages-box {
    grid-column: 1 / -1;
    position: relative;
    display: flex;
    align-items: center;
    gap: 18px;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    margin: 24px 0;
    padding: 20px 22px;
    border-radius: 24px;
    background: linear-gradient(145deg, rgba(0,234,255,.94), rgba(0,140,255,.92) 45%, rgba(123,44,255,.96));
    border: 1px solid rgba(255,255,255,.45);
    box-shadow: 0 10px 25px rgba(0,0,0,.30), 0 0 22px rgba(0,234,255,.45), 0 0 42px rgba(123,44,255,.35);
    overflow: hidden;
}

.driver-messages-box::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 45%;
    background: linear-gradient(to bottom, rgba(255,255,255,.42), rgba(255,255,255,0));
    pointer-events: none;
}

.driver-messages-icon {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 58px;
    height: 58px;
    flex-shrink: 0;
    border-radius: 18px;
    background: rgba(255,255,255,.18);
    border: 1px solid rgba(255,255,255,.40);
    font-size: 30px;
    box-shadow: inset 0 1px 8px rgba(255,255,255,.20), 0 0 15px rgba(255,255,255,.18);
}

.driver-messages-content {
    position: relative;
    z-index: 1;
    flex: 1;
}

.driver-messages-content h3 {
    margin: 0 0 5px;
    color: #ffffff;
    font-size: 18px;
    font-weight: 900;
    letter-spacing: .7px;
    text-shadow: 0 2px 8px rgba(0,0,0,.35);
}

.driver-messages-content p {
    margin: 0;
    color: rgba(255,255,255,.92);
    font-size: 14px;
    line-height: 1.45;
}

.driver-messages-button {
    position: relative;
    z-index: 1;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-width: 170px;
    padding: 13px 18px;
    border-radius: 16px;
    text-decoration: none;
    color: #ffffff;
    background: rgba(0,0,0,.20);
    border: 1px solid rgba(255,255,255,.48);
    font-size: 14px;
    font-weight: 900;
    letter-spacing: .5px;
    box-shadow: 0 5px 14px rgba(0,0,0,.25), 0 0 12px rgba(255,255,255,.12);
    transition: transform .2s ease, box-shadow .2s ease;
}

.driver-messages-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,.32), 0 0 20px rgba(255,255,255,.30);
}

.driver-messages-button:active {
    transform: scale(.97);
}

@media (max-width: 700px) {
    .driver-messages-box {
    grid-column: 1 / -1;
        flex-direction: column;
        align-items: stretch;
        text-align: center;
    }

    .driver-messages-icon {
        margin: 0 auto;
    }

    .driver-messages-button {
        width: 100%;
    }
}
</style>

</head>

<body class="appearance-<?php echo strtolower(htmlspecialchars($appearance)); ?>">

<div class="dashboard">


<!-- HEADER -->

<div class="header">

    <div class="brand">

        <div class="logo">
            🛵
        </div>

        <div>

            <h1>
                TransCalltation 2.0
            </h1>

            <p>
                DRIVER PANEL
            </p>

        </div>

    </div>


      <a href="settings.php" class="logout">
          ⚙️ SETTINGS
      </a>

</div>


<!-- WELCOME -->

<div class="welcome">

    <h2>

        Welcome,
        <?php
        echo htmlspecialchars(
            $driver["full_name"]
        );
        ?>! 👋

    </h2>

    <p>
        Manage your driver account and ride requests.
    </p>

</div>


<!-- INFORMATION -->

<div class="grid">


    <!-- DRIVER PROFILE -->
<div class="card driver-info-card">

    <button type="button"
            class="driver-info-button"
            onclick="openDriverInformation()">

        <div class="driver-info-button-icon">👤</div>

        <div class="driver-info-button-text">
            <strong>DRIVER INFORMATION</strong>
            <span>View your complete driver details</span>
        </div>

        <div class="driver-info-button-arrow">›</div>

    </button>

</div>

<!-- DRIVER INFORMATION MODAL -->
<div id="driverInfoModal" class="driver-info-modal">

    <div class="driver-info-modal-content">

        <button type="button"
                class="driver-info-close"
                onclick="closeDriverInformation()">
            ✕
        </button>

        <div class="driver-info-modal-header">
            <div class="driver-info-modal-icon">👤</div>

            <div>
                <h2>Driver Information</h2>
                <p>Your complete driver account information</p>
            </div>
        </div>

        <div class="driver-details">

            <div class="driver-detail">
                <span>👤</span>
                <div>
                    <small>FULL NAME</small>
                    <strong><?= htmlspecialchars($driver["full_name"]) ?></strong>
                </div>
            </div>

            <div class="driver-detail">
                <span>📧</span>
                <div>
                    <small>EMAIL</small>
                    <strong><?= htmlspecialchars($driver["email"]) ?></strong>
                </div>
            </div>

            <div class="driver-detail">
                <span>📱</span>
                <div>
                    <small>PHONE NUMBER</small>
                    <strong><?= htmlspecialchars($driver["phone"]) ?></strong>
                </div>
            </div>

            <div class="driver-detail">
                <span>🛵</span>
                <div>
                    <small>VEHICLE</small>
                    <strong><?= htmlspecialchars($driver["vehicle"]) ?></strong>
                </div>
            </div>

            <div class="driver-detail">
                <span>🔢</span>
                <div>
                    <small>PLATE NUMBER</small>
                    <strong><?= htmlspecialchars($driver["plate"]) ?></strong>
                </div>
            </div>

            <div class="driver-detail">
                <span>🛡️</span>
                <div>
                    <small>VERIFICATION STATUS</small>

                    <?php if ($driver["driver_verified"]): ?>
                        <strong class="status-verified">✅ VERIFIED DRIVER</strong>
                    <?php else: ?>
                        <strong class="status-pending">⏳ PENDING VERIFICATION</strong>
                    <?php endif; ?>

                </div>
            </div>

        </div>

        <div class="driver-documents">

            <h3>📷 DOCUMENTS & PHOTOS</h3>

            <div class="document-grid">

                <div class="document-card">
                    <div class="document-title">🪪 Driver's License</div>

                    <?php if (!empty($driver["driver_license_photo"])): ?>
                        <img src="driver_photo.php?file=<?= urlencode($driver["driver_license_photo"]) ?>"
                             alt="Driver's License">
                    <?php else: ?>
                        <div class="photo-placeholder">📷<br>Photo not uploaded</div>
                    <?php endif; ?>
                </div>

                <div class="document-card">
                    <div class="document-title">🆔 Government ID</div>

                    <?php if (!empty($driver["government_id_photo"])): ?>
                        <img src="driver_photo.php?file=<?= urlencode($driver["government_id_photo"]) ?>"
                             alt="Government ID">
                    <?php else: ?>
                        <div class="photo-placeholder">📷<br>Photo not uploaded</div>
                    <?php endif; ?>
                </div>

                <div class="document-card">
                    <div class="document-title">👤 Profile Photo</div>

                    <?php if (!empty($driver["profile_photo"])): ?>
                        <img src="driver_photo.php?file=<?= urlencode($driver["profile_photo"]) ?>"
                             alt="Driver Profile">
                    <?php else: ?>
                        <div class="photo-placeholder">📷<br>Photo not uploaded</div>
                    <?php endif; ?>
                </div>

                <div class="document-card">
                    <div class="document-title">🛵 Vehicle Photo</div>

                    <?php if (!empty($driver["vehicle_photo"])): ?>
                        <img src="driver_photo.php?file=<?= urlencode($driver["vehicle_photo"]) ?>"
                             alt="Vehicle">
                    <?php else: ?>
                        <div class="photo-placeholder">📷<br>Photo not uploaded</div>
                    <?php endif; ?>
                </div>

            </div>

        </div>

    </div>

</div>

<!-- VERIFICATION -->

    <div class="card">

        <h3>
            🛡️ Driver Verification
        </h3>


        <?php if ($driver["driver_verified"]): ?>

            <div class="verified">

                ✅ VERIFIED DRIVER

                <br>

                <small>
                    Your account has been verified by Admin.
                </small>

            </div>

        <?php else: ?>

            <div class="pending">

                ⏳ VERIFICATION PENDING

                <br>

                <small>
                    Please wait for Admin approval.
                </small>

            </div>

        <?php endif; ?>

    </div>


    <!-- AVAILABILITY -->

    <div class="card">

        <h3>
            🟢 Driver Availability
        </h3>

        <div class="status">
<!-- ABOUT US MODAL -->
<div id="aboutUsModal" class="about-modal">
    <div class="about-box">

        <div class="about-welcome">
            <h1 class="about-welcome-title">✨ Thank you for Choosing TransCalltation ✨</h1>
            <p class="about-welcome-text">Please read below for more information about TransCalltation, its purpose, features, and benefits.</p>
        </div>

        <button type="button" class="about-close" onclick="closeAboutUs()">
            ✕
        </button>

        <h2>🛵 About TransCalltation</h2>
        <p class="about-subtitle">
            A Web-Based Transportation Assistance and Ride Booking System
        </p>

        <h3>1. Introduction</h3>
        <p>
            TransCalltation is a proposed web-based system designed to help students find available transportation more conveniently. It focuses on reducing long waiting times and helping students manage their schedules when looking for motorcycle or other available transportation.
        </p>

        <h3>2. Main Problem</h3>
        <p>
            Many students have difficulty finding available transportation, especially during busy hours. They may spend a long time waiting for a motorcycle or vehicle, which can cause delays and make it difficult to arrive at school or other destinations on time.
        </p>

        <h3>3. Why Transportation Is Important</h3>
        <p>
            Reliable transportation is important for students because it allows them to travel to school, go home, attend activities, and manage their daily responsibilities.
        </p>

        <h3>4. Reasons Why It Is a Problem</h3>
        <ul>
            <li>Long waiting times during peak hours.</li>
            <li>Limited available drivers near schools.</li>
            <li>Difficulty identifying available drivers.</li>
            <li>Students may arrive late to class.</li>
            <li>Transportation problems can affect students daily schedules.</li>
        </ul>

        <h3>5. Effects on Students</h3>
        <p>
            Transportation problems can result in wasted time, delays, stress, and difficulty managing school activities. Students may also spend additional time searching for an available driver instead of focusing on their academic responsibilities.
        </p>

        <h3>6. Evidence of the Problem</h3>
        <p>The project can use photos and videos as evidence, such as:</p>
        <ul>
            <li>Students waiting for motorcycles.</li>
            <li>Long lines of commuters.</li>
            <li>Crowded roads near schools.</li>
            <li>Students waiting during peak hours.</li>
            <li>Areas with limited transportation.</li>
        </ul>

        <p>
            <strong>Note:</strong> Always ask permission when taking identifiable photos or videos of people.
        </p>

        <h3>7. Proposed Solution</h3>
        <p>
            TransCalltation provides a centralized website where students can find available drivers and request rides. Drivers can manage their availability, while administrators can manage users, drivers, and bookings.
        </p>

        <h3>8. User Registration & Login</h3>
        <p>
            Students can create accounts and securely log in to the system. Their accounts can contain basic information needed for transportation booking and account management.
        </p>

        <h3>9. Driver Registration & Verification</h3>
        <p>
            Drivers can register through the website and provide the required information. An administrator can review and verify driver accounts before they are allowed to accept ride requests.
        </p>

        <h3>10. Driver Availability</h3>
        <p>Drivers can set their status to:</p>
        <ul>
            <li>🟢 Available – Ready to receive ride requests.</li>
            <li>🔴 Unavailable – Not currently accepting requests.</li>
        </ul>

        <h3>11. Ride Booking</h3>
        <p>
            Students can select an available driver and submit a ride request. The booking can include the pickup location, destination, date, time, selected driver, and booking status.
        </p>

        <h3>12. Booking Records & Ride History</h3>
        <p>
            Students and drivers can view previous ride information. Records can include the place, date, time, driver/student, and booking status. This creates an organized history of transportation activities.
        </p>

        <h3>13. Administrator Dashboard</h3>
        <p>The administrator can manage important system information, including:</p>
        <ul>
            <li>Student accounts</li>
            <li>Driver accounts</li>
            <li>Driver verification</li>
            <li>Ride bookings</li>
            <li>Booking records</li>
            <li>User management</li>
        </ul>

        <h3>14. Beneficiaries & Benefits</h3>
        <ul>
            <li>🎓 <strong>Students</strong> – Easier access to available transportation.</li>
            <li>🛵 <strong>Drivers</strong> – More organized ride requests and availability management.</li>
            <li>🏫 <strong>Schools</strong> – Better transportation coordination for students.</li>
            <li>🚶 <strong>Commuters</strong> – A more organized way of connecting transportation needs with available drivers.</li>
        </ul>

        <h3>15. Goal & Expected Outcome</h3>
        <p>
            The goal of TransCalltation is to make student transportation easier, faster, and more organized. Through the web application, students can find available drivers, request rides, and view their ride history, while drivers can manage availability and bookings.
        </p>

        <div class="about-tagline">
            <div class="about-thankyou">
                <h2 class="about-thankyou-title">🙏 Thank you!</h2>
                <p class="about-contact">Please contact the administrator for more information, questions, assistance, or support regarding TransCalltation.</p>
            </div>
            🏍️ “TransCalltation: Connecting Students with Transportation — Faster, Easier, and More Organized.”
        </div>

    </div>
</div>


            <div class="status-title">
                CURRENT STATUS
            </div>

            <div class="status-value
                <?php
                echo $driver["status"] === "Available"
                    ? "available"
                    : "unavailable";
                ?>">

                <?php
                echo htmlspecialchars(
                    $driver["status"]
                );
                ?>

            </div>

        </div>


        <a
            href="driver_status.php"
            class="button">

            ⚙️ MANAGE AVAILABILITY

        </a>

    </div>


    <!-- RIDE REQUESTS -->
<div class="card">
    <h3>
        🚕 Ride Requests
    </h3>

    <p class="info">
        Your student ride requests will appear here.
    </p>

    <a href="driver_bookings.php" class="button">
        📋 VIEW RIDE REQUESTS
    </a>

</div>
<!-- REQUEST RIDE HISTORY -->
<div class="card history-card-full">
    <h3>
        📜 Request Ride History
    </h3>

    <p class="info">
        View your completed, accepted, cancelled, and previous ride records.
    </p>

    <a href="driver_ride_history.php" class="button">
        📜 VIEW RIDE HISTORY
    </a>

    <form method="POST" action="delete_driver_ride_history.php"
          onsubmit="return confirm('Are you sure you want to delete all of your ride history?');">
        <button type="submit" class="delete-history-button">
            🗑️ DELETE ALL RIDE HISTORY
        </button>
    </form>
</div>

<!-- MESSAGES & COMPLAINTS -->
<div class="driver-messages-box">
    <div class="driver-messages-icon">💬</div>
    <div class="driver-messages-content">
        <h3>MESSAGES &amp; COMPLAINTS</h3>
        <p>Chat with Admin or your Students and send messages, photos, or complaints.</p>
    </div>
    <a href="messages.php" class="driver-messages-button">
        OPEN MESSAGES <span>→</span>
    </a>
</div>

<!-- ABOUT US -->
<section class="section about-section-full">
    <h3>🛵 About TransCalltation</h3>
    <button type="button" class="about-btn" onclick="openAboutUs()">
        ℹ️ ABOUT US
    </button>
</section>



</div>


</div>

<script>
function openAboutUs() {
    const modal = document.getElementById("aboutUsModal");

    if (modal.parentElement !== document.body) {
        document.body.appendChild(modal);
    }

    modal.classList.add("active");
    document.body.style.overflow = "hidden";
}

function closeAboutUs() {
    document.getElementById("aboutUsModal").classList.remove("active");
    document.body.style.overflow = "";
}

document.getElementById("aboutUsModal").addEventListener("click", function(event) {
    if (event.target === this) {
        closeAboutUs();
    }
});
</script>

<script>
function openDriverInformation() {
    const modal = document.getElementById("driverInfoModal");

    if (modal) {
        modal.style.display = "block";
        document.body.style.overflow = "hidden";
    }
}

function closeDriverInformation() {
    const modal = document.getElementById("driverInfoModal");

    if (modal) {
        modal.style.display = "none";
        document.body.style.overflow = "";
    }
}

document.addEventListener("click", function(event) {
    const modal = document.getElementById("driverInfoModal");

    if (modal && event.target === modal) {
        closeDriverInformation();
    }
});
</script>

</body>

</html>
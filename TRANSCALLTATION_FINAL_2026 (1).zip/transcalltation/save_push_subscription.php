<?php

session_start();
include "config.php";

header("Content-Type: application/json");

if (!isset($_SESSION["user_id"])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Not logged in."
    ]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "POST request required."
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Invalid subscription data."
    ]);
    exit();
}

$endpoint = trim($data["endpoint"] ?? "");
$p256dh = trim($data["p256dh"] ?? "");
$auth = trim($data["auth"] ?? "");
$device_name = trim($data["device_name"] ?? "");

if ($endpoint === "" || $p256dh === "" || $auth === "") {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Incomplete push subscription."
    ]);
    exit();
}

$user_id = (int) $_SESSION["user_id"];

if (strlen($device_name) > 100) {
    $device_name = substr($device_name, 0, 100);
}

/* Check whether this browser subscription already exists */
$stmt = $conn->prepare(
    "SELECT id FROM push_subscriptions WHERE endpoint = ? LIMIT 1"
);

$stmt->bind_param("s", $endpoint);
$stmt->execute();

$result = $stmt->get_result();
$existing = $result->fetch_assoc();

$stmt->close();

if ($existing) {

    $subscription_id = (int) $existing["id"];

    $stmt = $conn->prepare(
        "UPDATE push_subscriptions
         SET user_id = ?, p256dh = ?, auth = ?, device_name = ?
         WHERE id = ?"
    );

    $stmt->bind_param(
        "isssi",
        $user_id,
        $p256dh,
        $auth,
        $device_name,
        $subscription_id
    );

} else {

    $stmt = $conn->prepare(
        "INSERT INTO push_subscriptions
         (user_id, endpoint, p256dh, auth, device_name)
         VALUES (?, ?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "issss",
        $user_id,
        $endpoint,
        $p256dh,
        $auth,
        $device_name
    );
}

if ($stmt->execute()) {

    echo json_encode([
        "success" => true,
        "message" => "Push subscription saved."
    ]);

} else {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Unable to save push subscription."
    ]);
}

$stmt->close();
$conn->close();
?>

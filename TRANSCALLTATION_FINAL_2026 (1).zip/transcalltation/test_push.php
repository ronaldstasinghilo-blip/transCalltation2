<?php
session_start();

include "config.php";
include "push_config.php";

require_once __DIR__ . "/vendor/autoload.php";

use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

header("Content-Type: text/plain");

$auth = [
    "VAPID" => [
        "subject" => $VAPID_SUBJECT,
        "publicKey" => $VAPID_PUBLIC_KEY,
        "privateKey" => $VAPID_PRIVATE_KEY
    ]
];

$webPush = new WebPush($auth);

$stmt = $conn->prepare(
    "SELECT id, endpoint, p256dh, auth
     FROM push_subscriptions
     WHERE user_id = ?
     ORDER BY id DESC"
);

$user_id = 3;
$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

$count = 0;

while ($row = $result->fetch_assoc()) {

    $subscription = Subscription::create([
        "endpoint" => $row["endpoint"],
        "keys" => [
            "p256dh" => $row["p256dh"],
            "auth" => $row["auth"]
        ]
    ]);

    $payload = json_encode([
        "title" => "TransCalltation 2.0",
        "body" => "🔔 This is a REAL push notification test!",
    ]);

    $webPush->queueNotification($subscription, $payload);
    $count++;
}

$stmt->close();

if ($count === 0) {
    echo "No push subscription found for user 16.";
    exit;
}

foreach ($webPush->flush() as $report) {

    if ($report->isSuccess()) {
        echo "SUCCESS: Push notification sent!\n";
    } else {
        $reason = $report->getReason();
        echo "FAILED: " . $reason . "\n";

        if (stripos($reason, "Gone") !== false) {
            $delete = $conn->prepare(
                "DELETE FROM push_subscriptions WHERE id = ?"
            );
            $delete->bind_param("i", $subscription_id);
            $delete->execute();
            $delete->close();

            echo "EXPIRED SUBSCRIPTION REMOVED: ID " . $subscription_id . "\n";
        }
    }
}

$conn->close();
?>

<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,
        u.full_name AS student_name
     FROM bookings b
     LEFT JOIN users u
        ON b.student_id = u.id
     WHERE b.driver_id = ?
     ORDER BY b.id DESC"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

$history = [];

while ($row = $result->fetch_assoc()) {
    $history[] = $row;
}

$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Request Ride History</title>

    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .container {
            max-width: 900px;
            margin: auto;
        }

        h1 {
            text-align: center;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 16px;
            border-radius: 10px;
            background: rgba(255,255,255,.18);
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .history-card {
            background: rgba(255,255,255,.12);
            padding: 18px;
            margin-bottom: 15px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,.2);
        }

        .history-card p {
            margin: 8px 0;
        }

        .status {
            font-weight: bold;
        }

        .empty {
            text-align: center;
            padding: 30px;
            background: rgba(255,255,255,.12);
            border-radius: 16px;
        }
    </style>
</head>

<body>

<div class="container">

    <a href="driver_dashboard.php" class="back">
        ← DASHBOARD
    </a>

    <h1>📋 REQUEST RIDE HISTORY</h1>

    <?php if (count($history) > 0): ?>

        <?php foreach ($history as $ride): ?>

            <div class="history-card">

                <p>
                    <strong>Ride #<?php echo (int)$ride["id"]; ?></strong>
                </p>

                <p>
                    👤 Student:
                    <?php echo htmlspecialchars($ride["student_name"] ?? "Unknown"); ?>
                </p>

                <p>
                    📍 Pickup:
                    <?php echo htmlspecialchars($ride["pickup"]); ?>
                </p>

                <p>
                    🏁 Drop-off:
                    <?php echo htmlspecialchars($ride["dropoff"]); ?>
                </p>

                <p class="status">
                    📌 Status:
                    <?php echo htmlspecialchars($ride["status"]); ?>
                </p>

                <p>
                    🕒 Date:
                    <?php echo htmlspecialchars($ride["created_at"]); ?>
                </p>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">
            📭 No ride history yet.
        </div>

    <?php endif; ?>

</div>

</body>
</html>

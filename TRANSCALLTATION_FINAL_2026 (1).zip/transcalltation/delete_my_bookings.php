<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "DELETE FROM bookings
     WHERE student_id = ?"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$stmt->close();

header("Location: dashboard.php");
exit();
?>

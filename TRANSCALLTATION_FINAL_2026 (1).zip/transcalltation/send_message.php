<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$sender_id = (int)$_SESSION["user_id"];

$receiver_id = isset($_POST["receiver_id"])
    ? (int)$_POST["receiver_id"]
    : 0;

$message = trim($_POST["message"] ?? "");

$message_type = $_POST["message_type"] ?? "message";

$allowed_types = ["message", "complaint"];

if (!in_array($message_type, $allowed_types, true)) {
    $message_type = "message";
}

/* Validate receiver */
if ($receiver_id <= 0 || $receiver_id === $sender_id) {
    header("Location: messages.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT id
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $receiver_id);
$stmt->execute();

$receiver = $stmt->get_result()->fetch_assoc();

if (!$receiver) {
    header("Location: messages.php");
    exit();
}

/* =====================================================
   PHOTO UPLOAD
===================================================== */

$photo_path = null;

if (
    isset($_FILES["photo"]) &&
    $_FILES["photo"]["error"] !== UPLOAD_ERR_NO_FILE
) {

    if ($_FILES["photo"]["error"] !== UPLOAD_ERR_OK) {
        die("Photo upload failed.");
    }

    /* Maximum 5 MB */
    if ($_FILES["photo"]["size"] > 5 * 1024 * 1024) {
        die("Photo is too large. Maximum size is 5 MB.");
    }

    $tmp_name = $_FILES["photo"]["tmp_name"];

    /* Verify that the file is actually an image */
    $image_info = getimagesize($tmp_name);

    if ($image_info === false) {
        die("Only valid image files are allowed.");
    }

    $allowed_mimes = [
        "image/jpeg" => "jpg",
        "image/png"  => "png",
        "image/gif"  => "gif",
        "image/webp" => "webp"
    ];

    $mime = $image_info["mime"];

    if (!isset($allowed_mimes[$mime])) {
        die("Unsupported image type.");
    }

    $extension = $allowed_mimes[$mime];

    /*
     * Generate a random filename so users
     * cannot choose dangerous filenames.
     */
    $filename =
        bin2hex(random_bytes(16))
        . "."
        . $extension;

    $private_directory =
        dirname(__DIR__) . "/transcalltation_private/message_photos";

    /*
     * The project is normally located at:
     * ~/transcalltation
     *
     * So use the absolute Termux home path
     * when available.
     */
    $private_directory =
        getenv("HOME") . "/transcalltation_private/message_photos";

    if (!is_dir($private_directory)) {
        mkdir($private_directory, 0700, true);
    }

    $destination =
        $private_directory . "/" . $filename;

    if (!move_uploaded_file($tmp_name, $destination)) {
        die("Unable to save uploaded photo.");
    }

    chmod($destination, 0600);

    /*
     * Store only the filename in the database.
     * The actual photo remains outside the web folder.
     */
    $photo_path = $filename;
}

/* Require either text or photo */
if ($message === "" && $photo_path === null) {
    header(
        "Location: messages.php?user="
        . $receiver_id
    );
    exit();
}

/* =====================================================
   SAVE MESSAGE
===================================================== */

$stmt = $conn->prepare("
    INSERT INTO messages
    (
        sender_id,
        receiver_id,
        message,
        photo,
        message_type,
        is_read
    )
    VALUES (?, ?, ?, ?, ?, 0)
");

$stmt->bind_param(
    "iisss",
    $sender_id,
    $receiver_id,
    $message,
    $photo_path,
    $message_type
);

$stmt->execute();

/* Return to conversation */
header(
    "Location: messages.php?user="
    . $receiver_id
);

exit();
?>

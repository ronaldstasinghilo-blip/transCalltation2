<?php

session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT id, full_name, email, role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$stmt->close();

if (!$admin || strtolower($admin["role"]) !== "admin") {
    header("Location: dashboard.php");
    exit();
}


/* Get all booking history */

$bookings = [];

$result = $conn->query(
    "SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,

        s.full_name AS student_name,

        d.full_name AS driver_name

     FROM bookings b

     LEFT JOIN users s
        ON b.student_id = s.id

     LEFT JOIN users d
        ON b.driver_id = d.id

     ORDER BY b.id DESC"
);

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Booking History | TransCalltation</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    padding: 15px;

    font-family: Arial, sans-serif;

    color: white;

    background:
        radial-gradient(
            circle at 10% 10%,
            #00e5ff,
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 90%,
            #e100ff,
            transparent 35%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );
}

.container {

    width: 100%;

    max-width: 900px;

    margin: auto;
}

.header {

    padding: 20px;

    margin-bottom: 18px;

    border-radius: 20px;

    background:
        rgba(255,255,255,.13);

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 12px 30px
        rgba(0,0,0,.25);
}

.header h1 {

    font-size: 22px;

    margin-bottom: 5px;
}

.header p {

    font-size: 12px;

    opacity: .8;
}

.back {

    display: inline-block;

    margin-top: 15px;

    padding: 10px 14px;

    border-radius: 10px;

    color: white;

    text-decoration: none;

    background:
        rgba(0,0,0,.25);

    font-weight: bold;
}

.booking {

    padding: 18px;

    margin-bottom: 12px;

    border-radius: 18px;

    background:
        rgba(255,255,255,.12);

    border:
        1px solid
        rgba(255,255,255,.2);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,.2);

    line-height: 1.8;

    font-size: 12px;
}

.booking-title {

    font-size: 16px;

    font-weight: bold;

    margin-bottom: 8px;
}

.status {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 20px;

    background:
        rgba(0,0,0,.25);

    font-size: 10px;

    font-weight: bold;
}

.empty {

    padding: 30px;

    text-align: center;

    border-radius: 20px;

    background:
        rgba(255,255,255,.1);
}

</style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>📋 Booking History</h1>

        <p>
            Complete history of TransCalltation ride bookings.
        </p>

        <a
            href="admin_dashboard.php"
            class="back">

            ← Back to Dashboard

        </a>

    </div>


    <?php if (count($bookings) > 0): ?>

        <?php foreach ($bookings as $booking): ?>

            <div class="booking">

                <div class="booking-title">

                    👨‍🎓
                    <?php
                    echo htmlspecialchars(
                        $booking["student_name"]
                        ?? "Student"
                    );
                    ?>

                    →

                    🛵
                    <?php
                    echo htmlspecialchars(
                        $booking["driver_name"]
                        ?? "Driver"
                    );
                    ?>

                </div>

                📍 Pickup:
                <?php
                echo htmlspecialchars(
                    $booking["pickup"]
                    ?? "N/A"
                );
                ?>

                <br>

                🏁 Drop-off:
                <?php
                echo htmlspecialchars(
                    $booking["dropoff"]
                    ?? "N/A"
                );
                ?>

                <br>

                🕒 Requested:
                <?php
                echo htmlspecialchars(
                    $booking["created_at"]
                    ?? "N/A"
                );
                ?>

                <br>

                Status:

                <span class="status">

                    <?php
                    echo htmlspecialchars(
                        $booking["status"]
                        ?? "Pending"
                    );
                    ?>

                </span>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">

            📋

            <br><br>

            No bookings yet.

        </div>

    <?php endif; ?>

</div>

</body>

</html>

<?php

include "config.php";

$my_password = "01Enterpassword";

$hash = password_hash($my_password, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "UPDATE users
     SET password = ?
     WHERE email = 'ronaldstasinghilo@gmail.com'"
);

$stmt->bind_param("s", $hash);
$stmt->execute();

echo "Admin password updated successfully.";

$stmt->close();
$conn->close();

?>
<?php
session_start();
include "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: dashboard.php");
    exit();
}

/* =====================================================
   ADMIN MANAGEMENT ACTION HANDLER
===================================================== */

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";
    $driver_id = isset($_POST["driver_id"]) ? (int)$_POST["driver_id"] : 0;

    if ($driver_id <= 0) {
        $message = "Invalid driver ID.";
    } else {

        /* Make sure the selected account is actually a driver */
        $check = $conn->prepare(
            "SELECT id, full_name FROM users WHERE id = ? AND role = 'driver' LIMIT 1"
        );
        $check->bind_param("i", $driver_id);
        $check->execute();
        $driver = $check->get_result()->fetch_assoc();
        $check->close();

        if (!$driver) {
            $message = "Driver account not found.";
        } else {

            /* BLOCK DRIVER */
            if ($action === "block") {

                $stmt = $conn->prepare(
                    "UPDATE users
                     SET status = 'Blocked'
                     WHERE id = ? AND role = 'driver'"
                );
                $stmt->bind_param("i", $driver_id);
                $stmt->execute();

                $message = "Driver blocked successfully.";
                $stmt->close();

            }

            /* UNBLOCK DRIVER */
            elseif ($action === "unblock") {

                $stmt = $conn->prepare(
                    "UPDATE users
                     SET status = 'Available',
                         suspended_until = NULL,
                         suspension_reason = NULL
                     WHERE id = ? AND role = 'driver'"
                );
                $stmt->bind_param("i", $driver_id);
                $stmt->execute();

                $message = "Driver unblocked successfully.";
                $stmt->close();

            }

            /* SUSPEND DRIVER */
            elseif ($action === "suspend") {

                $duration = $_POST["duration"] ?? "";
                $reason = trim($_POST["reason"] ?? "");

                $allowed_durations = [
                    "day",
                    "week",
                    "month",
                    "year"
                ];

                if (!in_array($duration, $allowed_durations, true)) {

                    $message = "Invalid suspension duration.";

                } else {

                    $interval = match ($duration) {
                        "day"   => "+1 day",
                        "week"  => "+1 week",
                        "month" => "+1 month",
                        "year"  => "+1 year",
                    };

                    $suspended_until = date(
                        "Y-m-d H:i:s",
                        strtotime($interval)
                    );

                    $stmt = $conn->prepare(
                        "UPDATE users
                         SET status = 'Suspended',
                             suspended_until = ?,
                             suspension_reason = ?
                         WHERE id = ? AND role = 'driver'"
                    );

                    $stmt->bind_param(
                        "ssi",
                        $suspended_until,
                        $reason,
                        $driver_id
                    );

                    $stmt->execute();

                    $message = "Driver suspended successfully.";
                    $stmt->close();
                }

            }

            /* DELETE ALL RIDING HISTORY */
            elseif ($action === "delete_history") {

                $stmt = $conn->prepare(
                    "DELETE FROM bookings WHERE driver_id = ?"
                );
                $stmt->bind_param("i", $driver_id);
                $stmt->execute();

                $message = "Driver riding history deleted successfully.";
                $stmt->close();

            }

            /* PERMANENTLY DELETE DRIVER */
            elseif ($action === "delete_driver") {

                /* Delete the driver's booking history first */
                $stmt = $conn->prepare(
                    "DELETE FROM bookings WHERE driver_id = ?"
                );
                $stmt->bind_param("i", $driver_id);
                $stmt->execute();
                $stmt->close();

                /* Then delete the driver account */
                $stmt = $conn->prepare(
                    "DELETE FROM users
                     WHERE id = ? AND role = 'driver'"
                );
                $stmt->bind_param("i", $driver_id);
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $message = "Driver deleted permanently.";
                } else {
                    $message = "Driver could not be deleted.";
                }

                $stmt->close();

            }

            else {
                $message = "Unknown admin action.";
            }
        }
    }
}

$drivers = [];

$result = $conn->query(
    "SELECT
        id,
        full_name,
        email,
        phone,
        status,
        vehicle,
        plate,
        driver_verified,
        suspended_until,
        suspension_reason
     FROM users
     WHERE role = 'driver'
     ORDER BY id DESC"
);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Admin Management - TransCalltation 2.0</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 20px;

            min-height: 100vh;

            font-family: Arial, Helvetica, sans-serif;

            color: white;

            background:
                radial-gradient(
                    circle at top left,
                    rgba(0, 234, 255, 0.18),
                    transparent 35%
                ),
                radial-gradient(
                    circle at bottom right,
                    rgba(123, 44, 255, 0.20),
                    transparent 35%
                ),
                linear-gradient(
                    135deg,
                    #050816,
                    #10152f,
                    #090d20
                );
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;

            gap: 15px;

            margin-bottom: 25px;
        }

        h1 {
            margin: 0;

            font-size: 32px;
            font-weight: 900;

            background:
                linear-gradient(
                    90deg,
                    #00eaff,
                    #ffffff,
                    #b86cff,
                    #ff4fd8
                );

            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .back-btn {
            display: inline-block;

            padding: 12px 18px;

            border-radius: 14px;

            color: white;

            text-decoration: none;

            font-weight: 800;

            background:
                linear-gradient(
                    135deg,
                    rgba(0,234,255,.25),
                    rgba(123,44,255,.35)
                );
        }

        .message {
            margin-bottom: 20px;
            padding: 14px 18px;
            border-radius: 14px;

            background: rgba(0, 234, 255, 0.12);

            border: 1px solid rgba(0, 234, 255, 0.30);

            font-weight: 800;
        }

        .driver-card {
            margin-bottom: 20px;
            padding: 22px;

            border-radius: 22px;

            background:
                linear-gradient(
                    145deg,
                    rgba(255,255,255,.13),
                    rgba(255,255,255,.05)
                );

            border: 1px solid rgba(255,255,255,.12);

            box-shadow:
                0 15px 40px rgba(0,0,0,.30);
        }

        .driver-name {
            margin: 0 0 8px;

            font-size: 23px;
            font-weight: 900;
        }

        .email {
            color: #c9d7ff;
        }

        .info-grid {
            display: grid;

            grid-template-columns:
                repeat(3, minmax(0, 1fr));

            gap: 12px;

            margin-top: 18px;
        }

        .info-box {
            padding: 13px;

            border-radius: 14px;

            background: rgba(0,0,0,.18);
        }

        .label {
            display: block;

            margin-bottom: 5px;

            color: #91a4d4;

            font-size: 12px;
            font-weight: 700;
        }

        .value {
            font-weight: 800;
        }

        .status {
            margin-top: 18px;

            padding: 10px 14px;

            border-radius: 12px;

            background: rgba(0,234,255,.10);

            font-weight: 800;
        }

        .actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 18px;
        }

        .actions form {
            margin: 0;
        }

        .action-btn {
            border: none;
            padding: 11px 15px;
            border-radius: 12px;
            color: white;
            font-weight: 800;
            cursor: pointer;
        }

        .block-btn {
            background: linear-gradient(
                135deg,
                #8d1837,
                #c42c58
            );
        }

        .unblock-btn {
            background: linear-gradient(
                135deg,
                #087f5b,
                #13a879
            );
        }

        .suspend-form {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 18px;
            padding: 13px;

            border-radius: 15px;

            background: rgba(0, 0, 0, .16);
        }

        .suspend-form select,
        .suspend-form input {
            min-height: 42px;
            padding: 9px 12px;

            border-radius: 10px;

            border: 1px solid rgba(255,255,255,.14);

            color: white;
            background: #171d38;

            outline: none;
        }

        .suspend-form input {
            flex: 1;
            min-width: 180px;
        }

        .suspend-form select option {
            color: white;
            background: #171d38;
        }

        .suspend-btn {
            background: linear-gradient(
                135deg,
                #a56b00,
                #e09b20
            );
        }

        .history-btn {
            background: linear-gradient(
                135deg,
                #57408f,
                #805fc9
            );
        }

        .delete-btn {
            background: linear-gradient(
                135deg,
                #8b1727,
                #e03b4e
            );
        }

        .empty {
            padding: 35px;

            text-align: center;

            border-radius: 20px;

            background: rgba(255,255,255,.07);

            color: #b9c5e5;
        }

        @media (max-width: 700px) {

            .header {
                flex-direction: column;
                align-items: stretch;
            }

            .back-btn {
                text-align: center;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <div class="header">

        <h1>
            🛠️ ADMIN MANAGEMENT
        </h1>

        <a
            href="admin_dashboard.php"
            class="back-btn"
        >
            ← BACK TO DASHBOARD
        </a>

    </div>


    <?php if ($message !== ""): ?>

        <div class="message">
            <?php echo htmlspecialchars($message); ?>
        </div>

    <?php endif; ?>


    <?php if (count($drivers) === 0): ?>

        <div class="empty">
            🛵 No driver accounts found.
        </div>

    <?php else: ?>

        <?php foreach ($drivers as $driver): ?>

            <div class="driver-card">

                <h2 class="driver-name">
                    🛵
                    <?php
                    echo htmlspecialchars(
                        $driver["full_name"]
                    );
                    ?>
                </h2>

                <div class="email">
                    <?php
                    echo htmlspecialchars(
                        $driver["email"]
                    );
                    ?>
                </div>


                <div class="info-grid">

                    <div class="info-box">
                        <span class="label">
                            PHONE
                        </span>

                        <span class="value">
                            <?php
                            echo htmlspecialchars(
                                $driver["phone"] ?? "N/A"
                            );
                            ?>
                        </span>
                    </div>


                    <div class="info-box">
                        <span class="label">
                            VEHICLE
                        </span>

                        <span class="value">
                            <?php
                            echo htmlspecialchars(
                                $driver["vehicle"] ?? "N/A"
                            );
                            ?>
                        </span>
                    </div>


                    <div class="info-box">
                        <span class="label">
                            PLATE
                        </span>

                        <span class="value">
                            <?php
                            echo htmlspecialchars(
                                $driver["plate"] ?? "N/A"
                            );
                            ?>
                        </span>
                    </div>

                </div>


                <div class="actions">

                    <?php if (strtolower(trim($driver["status"] ?? "")) === "blocked"): ?>

                        <form method="POST">
                            <input type="hidden" name="action" value="unblock">
                            <input type="hidden" name="driver_id" value="<?php echo (int)$driver["id"]; ?>">

                            <button type="submit" class="action-btn unblock-btn">
                                🔓 UNBLOCK DRIVER
                            </button>
                        </form>

                    <?php else: ?>

                        <form method="POST"
                              onsubmit="return confirm('Block this driver?');">

                            <input type="hidden" name="action" value="block">
                            <input type="hidden" name="driver_id" value="<?php echo (int)$driver["id"]; ?>">

                            <button type="submit" class="action-btn block-btn">
                                🚫 BLOCK DRIVER
                            </button>

                        </form>

                    <?php endif; ?>

                </div>


                <form method="POST" class="suspend-form">

                    <input type="hidden" name="action" value="suspend">

                    <input
                        type="hidden"
                        name="driver_id"
                        value="<?php echo (int)$driver["id"]; ?>"
                    >

                    <select name="duration" required>
                        <option value="">⏱️ SUSPENSION DURATION</option>
                        <option value="day">1 Day</option>
                        <option value="week">1 Week</option>
                        <option value="month">1 Month</option>
                        <option value="year">1 Year</option>
                    </select>

                    <input
                        type="text"
                        name="reason"
                        placeholder="Reason (optional)"
                        maxlength="255"
                    >

                    <button
                        type="submit"
                        class="action-btn suspend-btn"
                        onclick="return confirm('Suspend this driver?');"
                    >
                        ⏸️ SUSPEND DRIVER
                    </button>

                </form>


                <form method="POST"
                      onsubmit="return confirm('DELETE ALL HISTORY for this driver? This cannot be undone.');">

                    <input type="hidden" name="action" value="delete_history">

                    <input
                        type="hidden"
                        name="driver_id"
                        value="<?php echo (int)$driver["id"]; ?>"
                    >

                    <button type="submit" class="action-btn history-btn">
                        🧹 DELETE HISTORY
                    </button>

                </form>


                <form method="POST"
                      onsubmit="return confirm('PERMANENTLY DELETE this driver and ALL of their history? This cannot be undone.');">

                    <input type="hidden" name="action" value="delete_driver">

                    <input
                        type="hidden"
                        name="driver_id"
                        value="<?php echo (int)$driver["id"]; ?>"
                    >

                    <button type="submit" class="action-btn delete-btn">
                        🗑️ DELETE DRIVER
                    </button>

                </form>


                <div class="status">

                    <?php if ((int)$driver["driver_verified"] === 1): ?>

                        ✓ VERIFIED DRIVER

                    <?php else: ?>

                        ⚠ NOT VERIFIED

                    <?php endif; ?>


                    —
                    <?php
                    echo htmlspecialchars(
                        $driver["status"] ?? "Unknown"
                    );
                    ?>

                </div>

            </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>

</body>
</html>

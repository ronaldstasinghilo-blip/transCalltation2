<?php

session_start();
include "config.php";

/* Protect page */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];


/* Get admin information */

$stmt = $conn->prepare(
    "SELECT id, full_name, email, role
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$stmt->close();


/* Only admin can access */

if (!$admin || $admin["role"] !== "admin") {
    header("Location: dashboard.php");
    exit();
}


/* Get drivers */

$drivers = [];

$result = $conn->query(
    "SELECT id, full_name, email, vehicle, plate,
            status, driver_verified
     FROM users
     WHERE role = 'driver'
     ORDER BY id DESC"
);

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }

}


/* Get all Wbookings */

$bookings = [];

$result = $conn->query(
    "SELECT
        b.id,
        b.pickup,
        b.dropoff,
        b.status,
        b.created_at,

        s.full_name AS student_name,

        d.full_name AS driver_name

     FROM bookings b

     LEFT JOIN users s
        ON b.student_id = s.id

     LEFT JOIN users d
        ON b.driver_id = d.id

     ORDER BY b.id DESC"
);

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    Admin Dashboard | TransCalltation 2.0
</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    padding: 15px;

    font-family: Arial, sans-serif;

    color: white;

    background:

        radial-gradient(
            circle at 10% 10%,
            #00e5ff,
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 90%,
            #e100ff,
            transparent 35%
        ),

        linear-gradient(
            135deg,
            #071952,
            #088395,
            #5700b3
        );

    background-size: 200% 200%;

    animation:
        backgroundMove 12s ease infinite;
}


/* MAIN */

.dashboard {

    width: 100%;

    max-width: 1100px;

    margin: auto;

    animation:
        pageEnter .8s ease;
}


/* HEADER */

.header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 18px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            rgba(0,114,255,.9),
            rgba(142,45,226,.9)
        );

    border:
        1px solid
        rgba(255,255,255,.3);

    box-shadow:

        0 15px 35px
        rgba(0,0,0,.3),

        inset 0 1px 3px
        rgba(255,255,255,.5);
}


/* BRAND */

.brand {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 55px;

    height: 55px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 16px;

    font-size: 27px;

    background:
        rgba(255,255,255,.2);

    box-shadow:
        inset 0 1px 4px
        rgba(255,255,255,.5);
}

.brand h1 {

    font-size: 20px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.4);
}

.brand p {

    font-size: 10px;

    opacity: .8;
}


/* LOGOUT */

.logout {

    color: white;

    text-decoration: none;

    padding: 10px 15px;

    border-radius: 12px;

    font-size: 11px;

    font-weight: 900;

    background:
        rgba(0,0,0,.25);

    transition: .25s;
}

.logout:hover {

    transform:
        translateY(-2px);

    background:
        rgba(255,255,255,.2);
}


/* WELCOME */

.welcome {

    padding: 25px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.25),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    backdrop-filter:
        blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.welcome h2 {

    font-size: 25px;

    font-weight: 900;

    text-shadow:
        2px 3px 6px
        rgba(0,0,0,.45);
}

.welcome p {

    margin-top: 7px;
    font-size: 13px;
    opacity: .8;
}


/* STATISTICS */

.stats {
    display: grid;
grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 13px;
    width: 100%;
    margin-bottom: 20px;
    align-items: stretch;
}

.stat {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    width: 100%;
    min-width: 0;

    text-decoration: none;
    color: white;

    padding: 18px;
    text-align: center;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.23),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    box-shadow:
        0 10px 25px
        rgba(0,0,0,.2);

    transition: .3s;
}

.stat:hover {
    transform: translateY(-5px);
}

.stat-icon {
    font-size: 25px;
    margin-bottom: 6px;
}

.stat-number {
    font-size: 22px;
    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}

.stat-label {
    margin-top: 4px;
    font-size: 10px;
    opacity: .75;
}


/* SECTION */

.section {

    padding: 20px;

    margin-bottom: 18px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.22),
            rgba(255,255,255,.07)
        );

    border:
        1px solid
        rgba(255,255,255,.25);

    backdrop-filter:
        blur(15px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,.25);
}

.section h3 {

    margin-bottom: 15px;

    font-size: 18px;

    font-weight: 900;

    text-shadow:
        2px 2px 5px
        rgba(0,0,0,.4);
}


/* DRIVER CARD */

.driver-card {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding: 16px;

    margin-bottom: 10px;

    border-radius: 17px;

    background:
        linear-gradient(
            135deg,
            rgba(0,198,255,.2),
            rgba(123,44,255,.18)
        );

    border:
        1px solid
        rgba(255,255,255,.2);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,.2);

    animation:
        cardEnter .5s ease;
}

.driver-info {

    flex: 1;

    font-size: 12px;

    line-height: 1.8;
}

.driver-name {

    font-size: 15px;

    font-weight: 900;

    text-shadow:
        1px 2px 4px
        rgba(0,0,0,.4);
}


/* BUTTON */

.verify-btn {

    padding: 11px 16px;

    border: none;

    border-radius: 11px;

    color: white;

    font-weight: 900;

    cursor: pointer;

    background:
        linear-gradient(
            90deg,
            #00a86b,
            #00d4ff
        );

    box-shadow:
        0 7px 16px
        rgba(0,0,0,.25);

    transition: .25s;
}

.verify-btn:active {

    transform:
        scale(.95);
}


/* VERIFIED */

.verified {

    padding: 8px 12px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 900;

    background:
        rgba(0,255,120,.18);

    color: #7cffb2;
}


/* UNVERIFIED */

.not-verified {

    padding: 8px 12px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 900;

    background:
        rgba(255,70,70,.2);

    color: #ff9999;
}


/* BOOKING */

.booking {

    padding: 15px;

    margin-bottom: 10px;

    border-radius: 15px;

    background:
        rgba(255,255,255,.1);

    border:
        1px solid
        rgba(255,255,255,.18);

    font-size: 12px;

    line-height: 1.8;
}

.booking strong {

    font-size: 14px;

    font-weight: 900;
}

.status {

    display: inline-block;

    padding: 5px 10px;

    border-radius: 20px;

    background:
        rgba(0,0,0,.2);

    font-size: 10px;

    font-weight: 900;
}


/* EMPTY */

.empty {

    padding: 25px;

    text-align: center;

    font-size: 13px;

    opacity: .7;
}


/* ANIMATIONS */

@keyframes backgroundMove {

    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

@keyframes pageEnter {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes cardEnter {

    from {
        opacity: 0;
        transform: translateY(15px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}


/* MOBILE */

@media(max-width:650px) {

    .stats {

        grid-template-columns:
            repeat(3, 1fr);

    }

    .stat {

        padding: 12px 5px;

    }

    .stat-number {

        font-size: 17px;

    }

    .driver-card {

        flex-direction: column;

        align-items: stretch;

    }

    .verify-btn {

        width: 100%;

    }

    .header h1 {

        font-size: 16px;

    }

    .welcome h2 {

        font-size: 21px;

    }

}

</style>

</head>

<body>


<div class="dashboard">


<!-- HEADER -->

<div class="header">

    <div class="brand">

        <div class="logo">
            🛡️
        </div>

        <div>

            <h1>
                TransCalltation 2.0
            </h1>

            <p>
                ADMIN CONTROL PANEL
            </p>

        </div>

    </div>

<a
    href="settings.php"
    class="logout">

    ⚙️ SETTINGS

</a>

</div>


<!-- WELCOME -->

<div class="welcome">

    <h2>

        Welcome,
        <?php
        echo htmlspecialchars(
            $admin["full_name"]
        );
        ?>! 👋

    </h2>

    <p>
        Manage drivers and monitor transportation bookings.
    </p>

</div>


<!-- STATISTICS -->

<div class="stats">
<a href="admin_drivers.php" class="stat">

        <div class="stat-icon">
            🛵
        </div>
        <div class="stat-number">
            <?php echo count($drivers); ?>
        </div>

        <div class="stat-label">
            TOTAL DRIVERS
        </div>

    </a>


    <a href="admin_verified.php" class="stat">

        <div class="stat-icon">
            🛡️
        </div>

        <div class="stat-number">

            <?php

            $verified = 0;

            foreach ($drivers as $d) {

                if ($d["driver_verified"]) {
                    $verified++;
                }

            }

            echo $verified;

            ?>

        </div>

        <div class="stat-label">
            VERIFIED
        </div>

    </a>


    <a href="admin_bookings.php" class="stat">

        <div class="stat-icon">
            📋
        </div>

        <div class="stat-number">
            <?php echo count($bookings); ?>
        </div>

        <div class="stat-label">
            BOOKINGS
        </div>

    </a>

</div>


<!-- DRIVERS -->

<section class="section">

    <h3>
        🛵 Driver Verification
    </h3>


    <?php if (count($drivers) > 0): ?>


        <?php foreach ($drivers as $driver): ?>

            <div class="driver-card">


                <div class="driver-info">

                    <div class="driver-name">

                        👤
                        <?php
                        echo htmlspecialchars(
                            $driver["full_name"]
                        );
                        ?>

                    </div>


                    📧
                    <?php
                    echo htmlspecialchars(
                        $driver["email"]
                    );
                    ?>

                    <br>


                    🛵 Vehicle:
                    <?php
                    echo htmlspecialchars(
                        $driver["vehicle"]
                    );
                    ?>

                    <br>


                    🔢 Plate:
                    <?php
                    echo htmlspecialchars(
                        $driver["plate"]
                    );
                    ?>

                    <br>


                    🟢 Status:
                    <?php
                    echo htmlspecialchars(
                        $driver["status"]
                    );
                    ?>

                </div>


                <?php if ($driver["driver_verified"]): ?>

                    <span class="verified">

                        ✅ VERIFIED

                    </span>

                <?php else: ?>

                    <form
                        action="verify_driver.php"
                        method="POST">

                        <input
                            type="hidden"
                            name="driver_id"
                            value="<?php
                            echo $driver["id"];
                            ?>">

                        <button
                            type="submit"
                            class="verify-btn">

                            🛡️ VERIFY DRIVER

                        </button>

                    </form>

                <?php endif; ?>


            </div>

        <?php endforeach; ?>


    <?php else: ?>

        <div class="empty">

            🛵

            <br><br>

            No drivers registered yet.

        </div>

    <?php endif; ?>

</section>


<!-- BOOKINGS -->

<section class="section">

    <h3>
        📋 All Ride Bookings
    </h3>


    <?php if (count($bookings) > 0): ?>


        <?php foreach ($bookings as $booking): ?>

            <div class="booking">

                <strong>

                    👨‍🎓
                    <?php
                    echo htmlspecialchars(
                        $booking["student_name"]
                        ?? "Student"
                    );
                    ?>

                    →

                    🛵
                    <?php
                    echo htmlspecialchars(
                        $booking["driver_name"]
                        ?? "Driver"
                    );
                    ?>

                </strong>


                <br>

                📍 Pickup:
                <?php
                echo htmlspecialchars(
                    $booking["pickup"]
                );
                ?>

                <br>

                🏁 Drop-off:
                <?php
                echo htmlspecialchars(
                    $booking["dropoff"]
                );
                ?>

                <br>

                Status:

                <span class="status">

                    <?php
                    echo htmlspecialchars(
                        $booking["status"]
                    );
                    ?>

                </span>

            </div>

        <?php endforeach; ?>


    <?php else: ?>

        <div class="empty">

            📋

            <br><br>

            No bookings yet.

        </div>

    <?php endif; ?>


</section>


</div>

</body>

</html>

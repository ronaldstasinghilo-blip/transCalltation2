<?php

session_start();

include "config.php";
include "send_push_notification.php";

header("Content-Type: text/plain");

$result = sendPushNotification(
    3,
    "TransCalltation 2.0",
    "🔔 Reusable push notification test is working!"
);

if ($result) {
    echo "SUCCESS: Reusable push sender completed.\n";
} else {
    echo "FAILED: No active push subscription or push error.\n";
}

$conn->close();
?>
